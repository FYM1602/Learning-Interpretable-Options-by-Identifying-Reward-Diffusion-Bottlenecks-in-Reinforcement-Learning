#!/usr/bin/env python
"""Visualize saved Taxi-v3 VPS options by writing per-option GIFs.

Run from this directory after training::

    python taxi-v3.py
    python visualization_taxi-v3.py --option_path option_results/taxi_VPS_option_Q_test.npy
"""
from __future__ import annotations

import argparse
import os
import time

import gymnasium as gym
import imageio.v2 as imageio
import numpy as np


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Roll out saved Taxi-v3 VPS Q-tables and save GIFs.")
    default_q = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "option_results",
        "taxi_VPS_option_Q_test.npy",
    )
    parser.add_argument("--env_id", default="Taxi-v3")
    parser.add_argument("--option_path", default=default_q, help="Saved option Q-table (.npy).")
    parser.add_argument("--save_dir", default=None, help="Output directory for GIFs (default: ./rollouts).")
    parser.add_argument("--n_steps", type=int, default=50, help="Max steps per option rollout.")
    parser.add_argument("--sleep_sec", type=float, default=0.1, help="Delay between frames when recording.")
    parser.add_argument("--fps", type=int, default=2, help="GIF frame rate.")
    parser.add_argument("--option_id", type=int, default=None, help="Visualize one option only (default: all).")
    return parser


def play_single_option(
    *,
    opt_id: int,
    option_Q: np.ndarray,
    opt_policy: np.ndarray,
    env_id: str,
    save_dir: str,
    n_steps: int,
    sleep_sec: float,
    fps: int,
) -> None:
    env = gym.make(env_id, render_mode="rgb_array")
    try:
        obs, _ = env.reset(seed=int(np.random.randint(1_000_000)))
        state = int(obs)
        frames: list[np.ndarray] = []
        steps = 0
        while steps < n_steps:
            frame = env.render()
            frames.append(frame)
            time.sleep(sleep_sec)

            if option_Q[opt_id, state].max() <= 0:
                break

            action = int(opt_policy[opt_id, state])
            next_obs, _, terminated, truncated, _ = env.step(action)
            state = int(next_obs)
            steps += 1
            if terminated or truncated:
                break

        gif_path = os.path.join(save_dir, f"option_{opt_id:02d}.gif")
        imageio.mimsave(gif_path, frames, fps=max(int(fps), 1))
        print(f"[✓] option {opt_id} rollout saved → {gif_path} ({steps} frames)")
    finally:
        env.close()


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    option_path = os.path.abspath(args.option_path)
    if not os.path.isfile(option_path):
        raise FileNotFoundError(
            f"No Q-table at {option_path!r}. Train first, e.g.:\n"
            f"  cd {os.path.dirname(option_path) or '.'}\n"
            f"  python taxi-v3.py"
        )

    base_dir = os.path.dirname(os.path.abspath(__file__))
    save_dir = args.save_dir or os.path.join(base_dir, "rollouts")
    os.makedirs(save_dir, exist_ok=True)

    option_Q = np.load(option_path)
    n_opts, n_states, n_actions = option_Q.shape
    print(f"Loaded {n_opts} options (states={n_states}, actions={n_actions}) from {option_path}")
    opt_policy = np.argmax(option_Q, axis=2)

    option_ids = range(n_opts) if args.option_id is None else [int(args.option_id)]
    for opt_id in option_ids:
        if not (0 <= opt_id < n_opts):
            raise ValueError(f"option_id={opt_id} out of range [0, {n_opts})")
        play_single_option(
            opt_id=opt_id,
            option_Q=option_Q,
            opt_policy=opt_policy,
            env_id=args.env_id,
            save_dir=save_dir,
            n_steps=int(args.n_steps),
            sleep_sec=float(args.sleep_sec),
            fps=int(args.fps),
        )


if __name__ == "__main__":
    main()
