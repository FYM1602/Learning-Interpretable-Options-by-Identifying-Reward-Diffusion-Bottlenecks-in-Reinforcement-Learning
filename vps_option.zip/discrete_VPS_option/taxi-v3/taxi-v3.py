#!/usr/bin/env python
"""Train and visualize VPS options on Taxi-v3.

Run from this directory::

    python taxi-v3.py
    python taxi-v3.py --help
"""
from __future__ import annotations

import argparse
import os

import gymnasium as gym
import numpy as np
from discrete_options import VPSOptionAgent
from PIL import Image, ImageDraw, ImageFont


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Train VPS options on Taxi-v3 and save Q-tables.")
    parser.add_argument("--env_id", default="Taxi-v3")
    parser.add_argument("--num_options", type=int, default=50)
    parser.add_argument("--phase1_eps", type=int, default=10_000, help="Phase-1 SR collection episodes.")
    parser.add_argument("--phase2_epochs", type=int, default=10, help="Phase-2 Q-learning passes over the buffer.")
    parser.add_argument("--max_episode_steps", type=int, default=200)
    parser.add_argument("--gamma_v", type=float, default=0.999, help="Discount for successor-representation / value phase.")
    parser.add_argument("--gamma_q", type=float, default=0.99, help="Discount for option Q-learning.")
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--sign", action="store_true", help="Train +/- paired options per VPS head.")
    parser.add_argument(
        "--output",
        default=None,
        help="Path for saved Q-table (.npy). Default: option_results/taxi_VPS_option_Q_test.npy",
    )
    parser.add_argument("--top_states", type=int, default=0, help="If >0, export this many bottleneck state PNGs.")
    return parser


def taxi_decode(env, idx: int) -> str:
    taxi_row, taxi_col, pass_loc, dest = env.unwrapped.decode(idx)
    return f"(taxi=({taxi_row},{taxi_col}), pass={pass_loc}, dest={dest})"


def taxi_render(env, idx: int) -> np.ndarray:
    backup = env.unwrapped.s
    env.unwrapped.s = idx
    frame = env.render()
    env.unwrapped.s = backup

    if isinstance(frame, np.ndarray) and frame.dtype != object:
        return frame

    if isinstance(frame, (list, tuple)):
        frame = np.asarray(frame, dtype=str)

    if frame.dtype == object or frame.dtype.kind in {"U", "S"}:
        text_lines = frame.astype(str).tolist()
        font = ImageFont.load_default()
        h = (len(text_lines) + 1) * 10
        w = (max(len(line) for line in text_lines) + 1) * 6
        img = Image.new("L", (w, h), color=255)
        draw = ImageDraw.Draw(img)
        for row, line in enumerate(text_lines):
            draw.text((2, row * 10), line, fill=0, font=font)
        return np.array(img.convert("RGB"), dtype=np.uint8)

    raise ValueError("Unknown frame format from env.render()")


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    save_path = args.output or os.path.join(base_dir, "option_results", "taxi_VPS_option_Q_test.npy")
    os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)

    env = gym.make(args.env_id, render_mode="rgb_array")
    try:
        agent = VPSOptionAgent(
            env,
            k=int(args.num_options),
            sign=bool(args.sign),
            gamma_v=float(args.gamma_v),
            gamma_q=float(args.gamma_q),
            seed=int(args.seed),
        )
        print(">>> Training VPS options on Taxi-v3 …")
        agent.train(
            phase1_eps=int(args.phase1_eps),
            phase2_epochs=int(args.phase2_epochs),
            max_ep_len=int(args.max_episode_steps),
        )
        agent.save_option_Q(save_path)
        print(f"[✓] option_Q saved to {save_path}")

        if int(args.top_states) > 0:
            print("\n=== Top bottleneck states ===")
            agent.get_top_states(
                decode_fn=lambda idx: taxi_decode(env, idx),
                render_fn=lambda idx: taxi_render(env, idx),
                save_dir=os.path.join(base_dir, "vps_max_states"),
            )
    finally:
        env.close()


if __name__ == "__main__":
    main()
