# Discrete VPS option discovery (tabular)

Tabular **Value → VPS → options** on MiniGrid **Key-Lock** and **Rooms**, plus a separate **Taxi-v3** script bundle for classic Gymnasium discrete control.

| Area | Entry point | Notes |
|------|-------------|--------|
| Gridworld (Key-Lock, Rooms) | `python -m gridworld …` from this directory | Requires [MiniGrid](https://github.com/Farama-Foundation/MiniGrid) |
| Taxi-v3 | Scripts under [`taxi-v3/`](taxi-v3/) | Gymnasium `Taxi-v3` only; run with `cd taxi-v3` (flat imports) |

Shared heatmaps for Rooms: [`gridworld/plotting.py`](gridworld/plotting.py) (`GridworldHeatmapPlotter`).

---

## Gridworld (`gridworld/`)

**Dependency:** MiniGrid is required for any command that runs Key-Lock or Rooms environments (not for top-level `--help`):

```bash
pip install minigrid
```

Unified CLI (same pattern as [`atari_vps`](../atari_vps/README.md)). All commands below assume:

```bash
cd discrete_VPS_option
```

### Key-Lock

**Typical paper pipeline:** train options → exact V/VPS → phase heatmaps → boxplots → coverage curves.

| Command | Module | Purpose |
|---------|--------|---------|
| `keylock train` | `key_lock/train_options.py` | Train Random / Eigen / VPS tabular options → `key_lock/option_results/` |
| `keylock exact` | `key_lock/exact_vps.py` | Exact V, VPS, Laplacian eigenvectors + heatmaps (uniform random walk) |
| `keylock plot phase-heatmaps` | `key_lock/figures.py` | Phase-conditioned VPS heatmaps from a saved exact run |
| `keylock plot boxplot` | `key_lock/figures.py` | Option random-walk success-count boxplots |
| `keylock plot coverage` | `key_lock/figures.py` | Eigen vs VPS coverage vs termination horizon N |
| `keylock viz fields` | `key_lock/visualize_learned.py` | Helpers for per-configuration V / φ figures |
| `keylock viz rollout` | `key_lock/visualize_learned.py` | Roll out saved option Q-tables |

```bash
python -m gridworld keylock train --num_options 8 --sign
python -m gridworld keylock exact
python -m gridworld keylock plot phase-heatmaps --results_dir <exact_run_dir>
python -m gridworld keylock plot boxplot --save_dir gridworld/key_lock/option_results
python -m gridworld keylock plot coverage --save_dir gridworld/key_lock/option_results
```

Use `python -m gridworld keylock train --help` (and likewise for other subcommands) for full flags.

**Package layout:** `key_lock/env.py`, `transitions.py`, `state_codec.py`, `train_options.py`, `exact_vps.py`, `figures.py`, `visualize_learned.py`, `plotting_utils.py`.

### Rooms

**Typical pipeline:** train VPS options → exact xy-RFF V/VPS → compare against graph centralities.

| Command | Module | Purpose |
|---------|--------|---------|
| `rooms train` | `rooms/train_options.py` | Train Random / Eigen / VPS tabular options |
| `rooms exact` | `rooms/exact_vps.py` | Exact V/VPS from xy-based RFF rewards |
| `rooms compare` | `rooms/compare_centrality.py` | VPS maps vs Brandes / connectivity baselines |
| `rooms centrality` | `rooms/centrality.py` | Centrality-only baseline plots |

```bash
python -m gridworld rooms train --only vps
python -m gridworld rooms exact --size 15
python -m gridworld rooms compare
```

**Package layout:** `rooms/env.py`, `transitions.py`, `train_options.py`, `exact_vps.py`, `centrality.py`, `compare_centrality.py`.

---

## Taxi-v3 (`taxi-v3/`)

Classic **500-state** Gymnasium `Taxi-v3`: tabular VPS / Eigen / Random options, downstream control experiments, and rollouts. This folder was **not** folded into `python -m gridworld`; keep using standalone scripts from `taxi-v3/`:

```bash
cd discrete_VPS_option/taxi-v3
```

### Workflow

1. **Train options** — random walk buffer, SR-based values, VPS features, offline Q-learning; saves Q-tables under `option_results/<Env>/`.
2. **Evaluate control** — SMDP Q-learning with primitive vs option policies, or options used only during ε-greedy exploration.
3. **Analyze / visualize** — random-walk success statistics, interactive rollouts, or GIFs.

### Scripts

| Script | Purpose |
|--------|---------|
| [`discrete_options.py`](taxi-v3/discrete_options.py) | **Main trainer:** `VPSOptionAgent` / `DiscreteOption` for Random, Eigen, and VPS options; optional rollout GIFs. CLI: `--env`, `--num`, `--only {random,eigen,vps,all}`, `--outer`, `--out_dir`, `--collect`, `--steps`, … |
| [`discrete_option_test.py`](taxi-v3/discrete_option_test.py) | **SMDP evaluation:** load saved Q-tables and run episodic control; plot reward curves (primitive vs Random / Eigen / VPS option sets). |
| [`option_exploration_qlearning.py`](taxi-v3/option_exploration_qlearning.py) | **Exploration-only options:** flat Q-learning where options appear only in ε-greedy exploration (not in backups); compares exploration strategies over a fixed step budget. |
| [`option_random_walk.py`](taxi-v3/option_random_walk.py) | **Random-walk analysis:** success counts (pickup + drop-off) under mixtures of primitives and options; boxplot-style summaries across outer training runs. |
| [`option_visualization.py`](taxi-v3/option_visualization.py) | **Interactive rollout:** load `option_results` and render human-window trajectories until option termination or `--max_len`. |
| [`taxi-v3.py`](taxi-v3/taxi-v3.py) | **Minimal VPS trainer:** CLI (`--help`); trains `VPSOptionAgent` and saves `option_results/taxi_VPS_option_Q_test.npy` by default. |
| [`visualization_taxi-v3.py`](taxi-v3/visualization_taxi-v3.py) | **GIF export:** load a saved Q-table (`--option_path`) and write per-option GIFs under `rollouts/`. |

### Example commands

```bash
cd discrete_VPS_option/taxi-v3

# Train 8 VPS options (5 independent outer runs), with sign-doubling
python discrete_options.py --env Taxi-v3 --num 8 --only vps --sign true --outer 5

# SMDP Q-learning comparison using saved options
python discrete_option_test.py --env Taxi-v3 --outer 5 --inner 5

# Options for exploration only (not in Q-updates)
python option_exploration_qlearning.py --env Taxi-v3 --outer 5

# Success counts under option random walk
python option_random_walk.py --env Taxi-v3 --opt_type vps --outer 5

# Interactive rollout of one VPS option set
python option_visualization.py --env Taxi-v3 --opt_type vps --outer 0

# Minimal train → visualize pipeline
python taxi-v3.py --help
python taxi-v3.py --num_options 8
python visualization_taxi-v3.py --option_path option_results/taxi_VPS_option_Q_test.npy
```

**Outputs:** `option_results/Taxi-v3/` (naming like `{env}_{k}_{RandomOption|EigenOpt|VPSOpt}_{outer}.npy`), plus plots/GIFs next to the scripts when enabled.

**Dependencies:** `gymnasium`, `numpy`, `scipy`; `matplotlib` / `imageio` for plots and GIFs. No MiniGrid required for Taxi-v3.

---

## Maintenance scripts (do not run)

`gridworld/_patch_train.py` and `gridworld/_finish_refactor.py` are one-off migration utilities from the package refactor, not experiment entry points.

---

## Quick checks

```bash
cd discrete_VPS_option
python -c "from gridworld.plotting import GridworldHeatmapPlotter; print('ok')"
python -m gridworld --help
python -m gridworld keylock train --help    # needs: pip install minigrid
python -m gridworld rooms exact --help
cd taxi-v3
python taxi-v3.py --help
python visualization_taxi-v3.py --help
```

Top-level `gridworld --help` works without MiniGrid. Key-Lock / Rooms **training** requires `pip install minigrid`.
