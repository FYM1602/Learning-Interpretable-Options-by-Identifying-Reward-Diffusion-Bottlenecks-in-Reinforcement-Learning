#!/usr/bin/env python
"""Compute exact KeyLock value, VPS-value, and Laplacian eigenvector distributions.

This script uses the deterministic state transition matrix of KeyLockEnv and
computes exact value functions for orthogonal random rewards under a uniform
primitive random-walk policy:

    V = (I - gamma * P_pi)^(-1) r

It then derives the exact VPS-value distribution

    phi(s) = E[(V(s') - V(s))^2 | s, a ~ Uniform(primitive actions)]

with terminal transitions using V(s') = 0, matching the current VPS code path.

Outputs:
- saved reward weights
- saved exact value arrays
- saved exact VPS-value arrays
- saved exact Laplacian eigenvector arrays
- heatmap visualizations for both V and phi
"""

from __future__ import annotations

import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .transitions import build_keylock_transition_matrix
from .env import KeyLockEnv
from .plotting_utils import (
    add_object_overlay,
    aggregate_heatmap,
    enumerate_reachable_configs,
    get_wall_positions,
    parse_option_ids,
)


def build_arg_parser() -> argparse.ArgumentParser:
    """Create the CLI parser."""
    parser = argparse.ArgumentParser(
        description="Compute exact V and VPS value for QR random rewards under uniform random walk."
    )
    parser.add_argument("--num_rewards", type=int, default=8,
                        help="Number of orthogonal random rewards to generate.")
    parser.add_argument("--gamma", type=float, default=0.999,
                        help="Discount factor.")
    parser.add_argument("--seed", type=int, default=999,
                        help="Random seed used to generate QR reward weights.")
    parser.add_argument("--size", type=int, default=15, help="Grid size.")
    parser.add_argument("--yellow_key_pos", type=int, nargs=2, default=[12, 3], help="Yellow key position (x, y).")
    parser.add_argument("--yellow_door_pos", type=int, nargs=2, default=[3, 8], help="Yellow door position (x, y).")
    parser.add_argument("--blue_key_pos", type=int, nargs=2, default=[12, 12], help="Blue key position (x, y).")
    parser.add_argument("--blue_door_pos", type=int, nargs=2, default=[9, 3], help="Blue door position (x, y).")
    parser.add_argument("--goal_pos", type=int, nargs=2, default=[3, 12], help="Goal position (x, y).") # [3, 12] is the goal position
    parser.add_argument("--transition_matrix_dir", default="keylock_transition_matrix",
                        help="Directory containing or storing T_next/T_done/valid_states.")
    parser.add_argument("--use_cached_transition_matrix", action="store_true",
                        help="Reuse cached transition matrix files instead of rebuilding them.")
    parser.add_argument("--save_dir", default="keylock_option_results/exact_uniform_random_walk_vps",
                        help="Directory used to save arrays and heatmaps.")
    parser.add_argument("--option_ids", default=None,
                        help="Comma-separated ids or ranges to visualize. Default: all.")
    parser.add_argument("--dpi", type=int, default=200, help="DPI for saved heatmaps.")
    parser.add_argument("--skip_plots", action="store_true",
                        help="Only save arrays; skip heatmap generation.")
    return parser


def make_env(args: argparse.Namespace) -> KeyLockEnv:
    """Create KeyLockEnv with CLI positions."""
    return KeyLockEnv(
        size=args.size,
        agent_start_pos=(1, 1),
        agent_start_dir=0,
        yellow_key_pos=tuple(args.yellow_key_pos),
        yellow_door_pos=tuple(args.yellow_door_pos),
        blue_key_pos=tuple(args.blue_key_pos),
        blue_door_pos=tuple(args.blue_door_pos),
        goal_pos=tuple(args.goal_pos),
        render_mode=None,
    )


def load_or_build_transition_data(
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load saved transition data or regenerate it.

    By default this script rebuilds the transition matrix every run to avoid
    stale caches after environment/terminal-state logic changes.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    transition_dir = (
        os.path.abspath(args.transition_matrix_dir)
        if os.path.isabs(args.transition_matrix_dir)
        else os.path.abspath(os.path.join(script_dir, args.transition_matrix_dir))
    )
    os.makedirs(transition_dir, exist_ok=True)

    t_next_path = os.path.join(transition_dir, "T_next.npy")
    t_done_path = os.path.join(transition_dir, "T_done.npy")
    valid_states_path = os.path.join(transition_dir, "valid_states.npy")

    if (
        args.use_cached_transition_matrix
        and os.path.exists(t_next_path)
        and os.path.exists(t_done_path)
        and os.path.exists(valid_states_path)
    ):
        print(f"[Transition Matrix] Loading from {transition_dir}...")
        t_next = np.load(t_next_path)
        t_done = np.load(t_done_path)
        valid_states = np.load(valid_states_path)
        print(f"[Transition Matrix] Loaded: T_next shape {t_next.shape}, {len(valid_states)} reachable states")
        return t_next, t_done, valid_states

    print("[Transition Matrix] Rebuilding matrix...")
    env = make_env(args)
    env.reset()
    t_next, t_done, reachable_states = build_keylock_transition_matrix(
        env,
        args.size,
        tuple(args.yellow_key_pos),
        tuple(args.yellow_door_pos),
        tuple(args.blue_key_pos),
        tuple(args.blue_door_pos),
        tuple(args.goal_pos),
    )
    env.close()

    valid_states = np.array(sorted(int(s) for s in reachable_states), dtype=np.int32)
    np.save(t_next_path, t_next)
    np.save(t_done_path, t_done)
    np.save(valid_states_path, valid_states)
    print(f"[Transition Matrix] Saved to {transition_dir}")
    return t_next, t_done, valid_states


def build_state_mappings(valid_states: np.ndarray) -> tuple[dict[int, int], np.ndarray]:
    """Create full-index <-> compressed-index mappings."""
    sorted_states = np.array(sorted(int(s) for s in valid_states), dtype=np.int32)
    state_to_compressed = {int(full_idx): idx for idx, full_idx in enumerate(sorted_states)}
    compressed_to_state = sorted_states.copy()
    return state_to_compressed, compressed_to_state


def get_terminal_state_mask(t_done: np.ndarray, compressed_to_state: np.ndarray) -> np.ndarray:
    """Return a boolean mask marking absorbing terminal states."""
    mask = np.zeros(len(compressed_to_state), dtype=bool)
    for idx, s_full in enumerate(compressed_to_state):
        s_full = int(s_full)
        mask[idx] = bool(np.all(t_done[s_full, :] == 1))
    return mask


def sample_orthogonal_rewards(
    num_rewards: int,
    num_states: int,
    seed: int,
    terminal_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Generate orthonormal reward vectors using QR decomposition.

    Terminal states receive zero reward so that their exact value remains zero.
    """
    if terminal_mask is None:
        terminal_mask = np.zeros(num_states, dtype=bool)
    nonterminal_idx = np.flatnonzero(~terminal_mask)
    if num_rewards > len(nonterminal_idx):
        raise ValueError(
            f"num_rewards={num_rewards} exceeds nonterminal reachable states={len(nonterminal_idx)}"
        )
    rng = np.random.default_rng(seed)
    rand_rewards = rng.standard_normal((num_rewards, len(nonterminal_idx))).astype(np.float64)
    q_mat, _ = np.linalg.qr(rand_rewards.T)
    rewards = np.zeros((num_rewards, num_states), dtype=np.float64)
    rewards[:, nonterminal_idx] = q_mat.T.astype(np.float64)
    return rewards


def build_uniform_random_walk_matrix(
    t_next: np.ndarray,
    t_done: np.ndarray,
    compressed_to_state: np.ndarray,
    state_to_compressed: dict[int, int],
) -> sp.csr_matrix:
    """Construct P_pi for uniform random walk over primitive actions."""
    num_states = len(compressed_to_state)
    num_actions = t_next.shape[1]
    prob = 1.0 / float(num_actions)

    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []

    for row_idx, s_full in enumerate(compressed_to_state):
        s_full = int(s_full)
        for action in range(num_actions):
            if int(t_done[s_full, action]) == 1:
                continue
            sn_full = int(t_next[s_full, action])
            col_idx = state_to_compressed.get(sn_full)
            if col_idx is None:
                continue
            rows.append(row_idx)
            cols.append(col_idx)
            data.append(prob)

    return sp.csr_matrix((data, (rows, cols)), shape=(num_states, num_states), dtype=np.float64)


def solve_exact_values(
    rewards: np.ndarray,
    p_pi: sp.csr_matrix,
    gamma: float,
) -> np.ndarray:
    """Solve (I - gamma P_pi) V = r for each reward vector."""
    num_states = p_pi.shape[0]
    a_mat = sp.eye(num_states, format="csc", dtype=np.float64) - gamma * p_pi.tocsc()
    solver = spla.factorized(a_mat)

    values = np.zeros_like(rewards, dtype=np.float64)
    for idx in range(rewards.shape[0]):
        values[idx] = solver(rewards[idx])
    return values


def build_symmetric_normalized_laplacian(p_pi: sp.csr_matrix) -> sp.csr_matrix:
    """Build a symmetric normalized Laplacian from a directed transition operator.

    Since the policy-induced transition matrix is generally asymmetric, we first
    symmetrize it into an undirected weighted adjacency:

        A = 0.5 * (P_pi + P_pi^T)

    and then construct the symmetric normalized Laplacian

        L = I - D^{-1/2} A D^{-1/2}.
    """
    adjacency = 0.5 * (p_pi + p_pi.T)
    adjacency = adjacency.tocsr()
    adjacency.setdiag(0.0)
    adjacency.eliminate_zeros()

    degree = np.asarray(adjacency.sum(axis=1)).ravel().astype(np.float64)
    degree = np.maximum(degree, 1e-12)
    d_inv_sqrt = sp.diags(1.0 / np.sqrt(degree), dtype=np.float64)
    return sp.eye(adjacency.shape[0], dtype=np.float64) - (d_inv_sqrt @ adjacency @ d_inv_sqrt)


def compute_laplacian_eigenvectors(
    p_pi: sp.csr_matrix,
    num_vectors: int,
) -> np.ndarray:
    """Compute the smallest non-trivial eigenvectors of the symmetrized graph Laplacian."""
    num_states = p_pi.shape[0]
    if num_states <= 1:
        raise ValueError("Need at least two states to compute non-trivial Laplacian eigenvectors.")

    laplacian = build_symmetric_normalized_laplacian(p_pi).tocsr()
    k_need = min(num_vectors + 1, num_states - 1)
    _, eigvecs = spla.eigsh(laplacian, k=k_need, which="SM")

    nontrivial = eigvecs[:, 1:]
    if nontrivial.shape[1] < num_vectors:
        raise ValueError(
            f"Only {nontrivial.shape[1]} non-trivial eigenvectors available, "
            f"but num_vectors={num_vectors} was requested."
        )
    return nontrivial[:, :num_vectors].T.astype(np.float64)


def compute_exact_phi(
    values: np.ndarray,
    t_next: np.ndarray,
    t_done: np.ndarray,
    compressed_to_state: np.ndarray,
    state_to_compressed: dict[int, int],
) -> np.ndarray:
    """Compute exact VPS value = E[(V(sn)-V(s))^2 | s, a uniform]."""
    num_rewards = values.shape[0]
    num_states = values.shape[1]
    num_actions = t_next.shape[1]
    phi = np.zeros((num_rewards, num_states), dtype=np.float64)

    for state_idx, s_full in enumerate(compressed_to_state):
        s_full = int(s_full)
        current_v = values[:, state_idx]
        accum = np.zeros(num_rewards, dtype=np.float64)
        for action in range(num_actions):
            if int(t_done[s_full, action]) == 1:
                next_v = np.zeros(num_rewards, dtype=np.float64)
            else:
                sn_full = int(t_next[s_full, action])
                next_idx = state_to_compressed.get(sn_full)
                if next_idx is None:
                    next_v = np.zeros(num_rewards, dtype=np.float64)
                else:
                    next_v = values[:, next_idx]
            diff = next_v - current_v
            accum += diff * diff
        phi[:, state_idx] = accum / float(num_actions)
    return phi


def expand_to_full(features: np.ndarray, compressed_to_state: np.ndarray, full_state_count: int) -> np.ndarray:
    """Expand compressed features (K, N_valid) to full state space (K, N_full)."""
    num_features = features.shape[0]
    full = np.zeros((num_features, full_state_count), dtype=np.float32)
    for comp_idx, full_idx in enumerate(compressed_to_state):
        full[:, int(full_idx)] = features[:, comp_idx].astype(np.float32)
    return full


def save_arrays(
    save_dir: str,
    num_rewards: int,
    seed: int,
    reward_weights: np.ndarray,
    value_full: np.ndarray,
    phi_full: np.ndarray,
) -> tuple[str, str]:
    """Save computed arrays and return value/VPS-value paths."""
    os.makedirs(save_dir, exist_ok=True)
    reward_path = os.path.join(save_dir, f"keylock_{num_rewards}_ExactRWReward_{seed}.npy")
    value_path = os.path.join(save_dir, f"keylock_{num_rewards}_VPSValue_exact_rw_{seed}.npy")
    phi_path = os.path.join(save_dir, f"keylock_{num_rewards}_VPSPhi_exact_rw_{seed}.npy")

    np.save(reward_path, reward_weights.astype(np.float32))
    np.save(value_path, value_full.astype(np.float32))
    np.save(phi_path, phi_full.astype(np.float32))

    print(f"[Save] {reward_path}")
    print(f"[Save] {value_path}")
    print(f"[Save] {phi_path}")
    return value_path, phi_path


def save_eigenvector_array(
    save_dir: str,
    num_vectors: int,
    seed: int,
    eigenvectors_full: np.ndarray,
) -> str:
    """Save exact Laplacian eigenvectors to disk."""
    os.makedirs(save_dir, exist_ok=True)
    eigen_path = os.path.join(save_dir, f"keylock_{num_vectors}_LaplacianEigenvectors_exact_rw_{seed}.npy")
    np.save(eigen_path, eigenvectors_full.astype(np.float32))
    print(f"[Save] {eigen_path}")
    return eigen_path


def render_heatmaps(
    features: np.ndarray,
    args: argparse.Namespace,
    feature_label: str,
    output_prefix: str,
    output_dir: str,
    reachable_states: set[int],
    cmap_name: str = "viridis",
) -> None:
    """Render exact-distribution heatmaps with an initialization panel."""
    env = make_env(args)
    env.reset()
    wall_positions = get_wall_positions(env, args.size)
    configs = enumerate_reachable_configs(reachable_states, args.size)
    option_ids = parse_option_ids(args.option_ids, features.shape[0])

    plot_args = argparse.Namespace(**vars(args))
    plot_args.feature_label = feature_label
    plot_args.output_prefix = output_prefix

    init_tuple = (0, 0, 1, 1)
    configs = sorted(
        configs,
        key=lambda cfg: (
            (cfg["yellow_door_open"], cfg["blue_door_open"], cfg["yellow_key_on_map"], cfg["blue_key_on_map"]) != init_tuple,
            cfg["name"],
        ),
    )

    init_render_env = KeyLockEnv(
        size=args.size,
        agent_start_pos=(1, 1),
        agent_start_dir=0,
        yellow_key_pos=tuple(args.yellow_key_pos),
        yellow_door_pos=tuple(args.yellow_door_pos),
        blue_key_pos=tuple(args.blue_key_pos),
        blue_door_pos=tuple(args.blue_door_pos),
        goal_pos=tuple(args.goal_pos),
        render_mode="rgb_array",
        highlight=False,
    )
    init_render_env.reset()
    init_frame = None
    if hasattr(init_render_env, "get_frame"):
        init_frame = init_render_env.get_frame(highlight=False)
    if init_frame is None:
        init_frame = init_render_env.render()

    def _display_config_name(config: dict) -> str:
        return str((
            config["blue_door_open"],
            config["yellow_door_open"],
            config["blue_key_on_map"],
            config["yellow_key_on_map"],
        ))

    try:
        for option_id in option_ids:
            heatmaps = [
                aggregate_heatmap(features[option_id], args.size, config, reachable_states, wall_positions)
                for config in configs
            ]

            fig, axes = plt.subplots(2, 4, figsize=(18, 9))
            axes = axes.ravel()

            # Panel 0: environment initialization rendering
            ax0 = axes[0]
            if init_frame is not None:
                ax0.imshow(init_frame)
            ax0.set_title("Initialization: (0,0,1,1)", fontsize=11, pad=8)
            ax0.axis("off")

            for ax, config, heatmap in zip(axes[1:], configs, heatmaps):
                finite_vals = heatmap[np.isfinite(heatmap)]
                if finite_vals.size == 0:
                    vmin, vmax = 0.0, 1.0
                else:
                    vmin = float(finite_vals.min())
                    vmax = float(finite_vals.max())
                    if np.isclose(vmin, vmax):
                        vmax = vmin + 1e-6

                masked = np.ma.masked_invalid(heatmap)
                image = ax.imshow(masked, origin="upper", cmap=cmap_name, vmin=vmin, vmax=vmax)
                add_object_overlay(ax, plot_args, config)

                if not np.isfinite(heatmap).any():
                    ax.text(
                        0.5, 0.5, "No reachable\nstates",
                        ha="center", va="center", transform=ax.transAxes,
                        fontsize=11, color="black",
                        bbox=dict(facecolor="white", alpha=0.8, edgecolor="none"),
                    )

                ax.set_title(_display_config_name(config), fontsize=11, pad=8)
                ax.set_xticks(range(0, args.size, max(1, args.size // 5)))
                ax.set_yticks(range(0, args.size, max(1, args.size // 5)))
                ax.set_xlabel("x")
                ax.set_ylabel("y")
                ax.set_xlim(-0.5, args.size - 0.5)
                ax.set_ylim(args.size - 0.5, -0.5)
                cbar = fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
                cbar_label = "VPS value" if "VPS value" in feature_label else feature_label
                cbar.set_label(cbar_label, fontsize=9)

            # Hide any unused axes if the reachable config count is not 7
            for ax in axes[1 + len(configs):]:
                ax.set_visible(False)

            handles = [
                plt.Line2D([0], [0], marker="P", color="w", markerfacecolor="gold",
                           markeredgecolor="black", markersize=12, label="Yellow key present"),
                plt.Line2D([0], [0], marker="x", color="goldenrod", linestyle="None",
                           markersize=12, markeredgewidth=2.2, label="Yellow key absent"),
                plt.Line2D([0], [0], marker="P", color="w", markerfacecolor="deepskyblue",
                           markeredgecolor="black", markersize=12, label="Blue key present"),
                plt.Line2D([0], [0], marker="x", color="royalblue", linestyle="None",
                           markersize=12, markeredgewidth=2.2, label="Blue key absent"),
                plt.Rectangle((0, 0), 1, 1, facecolor="gold", edgecolor="black", label="Yellow door closed"),
                plt.Rectangle((0, 0), 1, 1, facecolor="deepskyblue", edgecolor="black", label="Blue door closed"),
                plt.Rectangle((0, 0), 1, 1, facecolor="limegreen", edgecolor="black", label="Door open"),
                plt.Line2D([0], [0], marker="*", color="w", markerfacecolor="red",
                           markeredgecolor="black", markersize=14, label="Goal"),
            ]
            fig.legend(
                handles=handles,
                loc="upper center",
                bbox_to_anchor=(0.5, 0.985),
                ncol=8,
                fontsize=10,
                frameon=False,
                columnspacing=1.0,
                handletextpad=0.35,
            )

            bottom_title = (
                f"{feature_label} for option {option_id}. Top-left panel: initialization rendering.\n"
                "The remaining 7 panels are phase-conditioned heatmaps titled by their (a,b,c,d) configuration,\n"
                "where (a,b,c,d) = (blue_door_open, yellow_door_open, blue_key_on_map, yellow_key_on_map).\n"
                "Each heatmap value at (x,y) is obtained by averaging the values of all reachable "
                "(x,y,direction) states and projecting that mean onto the corresponding (x,y) position."
            )
            if "VPS value" in feature_label:
                bottom_title += (
                    "\nFor the irreversible MDP induced by MiniGrid Key-Lock, "
                    "the VPS value highlights not only room-to-room connections, but also door structures "
                    "between rooms and the locations of keys/goals."
                )
            fig.text(0.5, 0.02, bottom_title, ha="center", va="bottom", fontsize=13, wrap=True)
            fig.subplots_adjust(left=0.04, right=0.98, bottom=0.19, top=0.82, wspace=0.45, hspace=0.35)

            os.makedirs(output_dir, exist_ok=True)
            save_path = os.path.join(output_dir, f"{output_prefix}_opt{option_id:02d}.png")
            fig.savefig(save_path, dpi=args.dpi, bbox_inches="tight")
            plt.close(fig)
            print(f"[Save] {save_path}")
    finally:
        env.close()
        init_render_env.close()


def main() -> None:
    args = build_arg_parser().parse_args()

    t_next, t_done, valid_states = load_or_build_transition_data(args)
    state_to_compressed, compressed_to_state = build_state_mappings(valid_states)
    terminal_mask = get_terminal_state_mask(t_done, compressed_to_state)

    num_full_states = args.size * args.size * 4 * 2 * 2 * 2 * 2
    reward_weights = sample_orthogonal_rewards(
        args.num_rewards,
        len(compressed_to_state),
        args.seed,
        terminal_mask=terminal_mask,
    )
    p_pi = build_uniform_random_walk_matrix(t_next, t_done, compressed_to_state, state_to_compressed)
    exact_value = solve_exact_values(reward_weights, p_pi, args.gamma)
    exact_phi = compute_exact_phi(exact_value, t_next, t_done, compressed_to_state, state_to_compressed)
    exact_eigenvectors = compute_laplacian_eigenvectors(p_pi, args.num_rewards)

    value_full = expand_to_full(exact_value, compressed_to_state, num_full_states)
    phi_full = expand_to_full(exact_phi, compressed_to_state, num_full_states)
    eigenvectors_full = expand_to_full(exact_eigenvectors, compressed_to_state, num_full_states)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    save_dir = (
        os.path.abspath(args.save_dir)
        if os.path.isabs(args.save_dir)
        else os.path.abspath(os.path.join(script_dir, args.save_dir))
    )
    value_path, phi_path = save_arrays(
        save_dir,
        args.num_rewards,
        args.seed,
        reward_weights,
        value_full,
        phi_full,
    )
    eigen_path = save_eigenvector_array(
        save_dir,
        args.num_rewards,
        args.seed,
        eigenvectors_full,
    )

    reachable_states = set(int(s) for s in valid_states.tolist())
    print(f"[Info] Uniform random walk matrix shape: {p_pi.shape}")
    print(f"[Info] Reachable states: {len(reachable_states)}")
    print(f"[Info] Terminal states: {int(terminal_mask.sum())}")
    print(f"[Info] Saved exact arrays under: {save_dir}")

    if not args.skip_plots:
        value_heatmap_dir = os.path.join(save_dir, "value_heatmaps")
        phi_heatmap_dir = os.path.join(save_dir, "phi_heatmaps")
        eigen_heatmap_dir = os.path.join(save_dir, "eigen_heatmaps")
        render_heatmaps(
            value_full,
            args,
            feature_label="Exact V(s) under uniform random walk",
            output_prefix=f"exact_rw_value_k{args.num_rewards}_seed{args.seed}",
            output_dir=value_heatmap_dir,
            reachable_states=reachable_states,
            cmap_name="viridis",
        )
        render_heatmaps(
            phi_full,
            args,
            feature_label="Exact VPS value under uniform random walk",
            output_prefix=f"exact_rw_phi_k{args.num_rewards}_seed{args.seed}",
            output_dir=phi_heatmap_dir,
            reachable_states=reachable_states,
            cmap_name="viridis",
        )
        render_heatmaps(
            eigenvectors_full,
            args,
            feature_label="Exact Laplacian eigenvector under symmetrized random-walk graph",
            output_prefix=f"exact_rw_eigen_k{args.num_rewards}_seed{args.seed}",
            output_dir=eigen_heatmap_dir,
            reachable_states=reachable_states,
            cmap_name="coolwarm",
        )
        print(f"[Info] Value heatmaps saved to: {value_heatmap_dir}")
        print(f"[Info] VPS-value heatmaps saved to: {phi_heatmap_dir}")
        print(f"[Info] Laplacian eigenvector heatmaps saved to: {eigen_heatmap_dir}")
        print(f"[Info] Value array path: {value_path}")
        print(f"[Info] VPS-value array path: {phi_path}")
        print(f"[Info] Laplacian eigenvector array path: {eigen_path}")


if __name__ == "__main__":
    main()
