#!/usr/bin/env python
"""State-coverage curves for KeyLock options under different termination horizons.

This script reads already-trained Eigenoption and VPS-option Q tables, fixes the
option count to a requested base-k (default: 16), and compares option-driven
random walks under option termination probability 1/N for several N values.

By default it plots six curves:
  - Eigenoption, N=5
  - Eigenoption, N=15
  - Eigenoption, N=50
  - VPS Option, N=5
  - VPS Option, N=15
  - VPS Option, N=50

The y-axis is the cumulative number of unique states visited up to each time
step, matching the coverage-curve convention already used elsewhere in this
codebase.
"""

from __future__ import annotations

import argparse
import ast
import glob
import os
import random
from typing import TYPE_CHECKING

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

if TYPE_CHECKING:
    from .env import KeyLockEnv

def option_terminated(q_row: np.ndarray, termination_horizon: int) -> bool:
    """Terminate an option if its local Q-max is non-positive or with probability 1/N."""
    return q_row.max() <= 0 or random.random() < 1.0 / float(termination_horizon)


def available_options(Q: np.ndarray, s: int) -> list[int]:
    """Indices of options that can start at state s."""
    return [oid for oid in range(Q.shape[0]) if Q[oid, s].max() > 0]


def set_seed(seed: int | None) -> None:
    """Seed NumPy and Python RNGs."""
    if seed is not None:
        np.random.seed(seed)
        random.seed(seed)


def state_to_index(
    x: int,
    y: int,
    direction: int,
    yellow_door_open: int,
    blue_door_open: int,
    yellow_key_on_map: int,
    blue_key_on_map: int,
    size: int = 15,
) -> int:
    """Map KeyLock state factors to a flat integer index."""
    index = x
    index = index * size + y
    index = index * 4 + direction
    index = index * 2 + yellow_door_open
    index = index * 2 + blue_door_open
    index = index * 2 + yellow_key_on_map
    index = index * 2 + blue_key_on_map
    return int(index)


def random_walk_cover(
    env: "KeyLockEnv",
    size: int,
    state_space_size: int,
    max_steps: int,
) -> tuple[list[int], np.ndarray]:
    """Pure primitive random walk coverage curve and visit counts."""
    visited = np.zeros(state_space_size, dtype=bool)
    visit_counts = np.zeros(state_space_size, dtype=np.int32)
    curve: list[int] = []

    obs, _ = env.reset()
    s = state_to_index(obs[0], obs[1], obs[2], obs[3], obs[4], obs[5], obs[6], size)

    for _ in range(max_steps):
        visited[s] = True
        visit_counts[s] += 1
        curve.append(int(visited.sum()))

        primitive_action = random.randint(0, 5)
        next_obs, _, terminated, truncated, _ = env.step(primitive_action)
        s = state_to_index(
            next_obs[0], next_obs[1], next_obs[2], next_obs[3], next_obs[4], next_obs[5], next_obs[6], size
        )

        if terminated or truncated:
            obs, _ = env.reset()
            s = state_to_index(obs[0], obs[1], obs[2], obs[3], obs[4], obs[5], obs[6], size)

    return curve, visit_counts


def mixed_walk_cover(
    env: "KeyLockEnv",
    size: int,
    state_space_size: int,
    Q: np.ndarray,
    max_steps: int,
    termination_horizon: int,
) -> tuple[list[int], np.ndarray]:
    """Coverage curve for random primitive/option mixtures with configurable option termination."""
    num_primitive_actions = 6
    visited = np.zeros(state_space_size, dtype=bool)
    visit_counts = np.zeros(state_space_size, dtype=np.int32)
    curve: list[int] = []
    option_policy = np.argmax(Q, axis=2)

    obs, _ = env.reset()
    s = state_to_index(obs[0], obs[1], obs[2], obs[3], obs[4], obs[5], obs[6], size)

    while len(curve) < max_steps:
        visited[s] = True
        visit_counts[s] += 1
        curve.append(int(visited.sum()))

        startable_opts = available_options(Q, s)
        candidates = list(range(num_primitive_actions)) + [num_primitive_actions + oid for oid in startable_opts]
        chosen = random.choice(candidates)

        if chosen < num_primitive_actions:
            next_obs, _, terminated, truncated, _ = env.step(chosen)
            s = state_to_index(
                next_obs[0], next_obs[1], next_obs[2], next_obs[3], next_obs[4], next_obs[5], next_obs[6], size
            )
            if terminated or truncated:
                obs, _ = env.reset()
                s = state_to_index(obs[0], obs[1], obs[2], obs[3], obs[4], obs[5], obs[6], size)
            continue

        oid = chosen - num_primitive_actions
        while len(curve) < max_steps and not option_terminated(Q[oid, s], termination_horizon):
            visited[s] = True
            visit_counts[s] += 1
            curve.append(int(visited.sum()))

            primitive_action = int(option_policy[oid, s])
            next_obs, _, terminated, truncated, _ = env.step(primitive_action)
            s = state_to_index(
                next_obs[0], next_obs[1], next_obs[2], next_obs[3], next_obs[4], next_obs[5], next_obs[6], size
            )
            if terminated or truncated:
                obs, _ = env.reset()
                s = state_to_index(obs[0], obs[1], obs[2], obs[3], obs[4], obs[5], obs[6], size)
                break

    return curve, visit_counts


def pad_curve(curve: list[int], length: int) -> np.ndarray:
    """Pad or truncate a curve so multiple runs can be stacked."""
    if len(curve) >= length:
        return np.asarray(curve[:length], dtype=np.float32)
    if not curve:
        return np.zeros(length, dtype=np.float32)
    return np.concatenate([np.asarray(curve, dtype=np.float32), np.full(length - len(curve), curve[-1], dtype=np.float32)])


def parse_termination_values(spec: str) -> list[int]:
    """Parse a CLI list like '5,15,50' or '[5,15,50]'."""
    text = str(spec).strip()
    if not text:
        raise ValueError("--termination_values is empty")
    if "," in text and not (text.startswith("[") or text.startswith("(")):
        values = [int(part.strip()) for part in text.split(",") if part.strip()]
    else:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, int):
            values = [int(parsed)]
        elif isinstance(parsed, (list, tuple)):
            values = [int(v) for v in parsed]
        else:
            raise ValueError(f"Unsupported termination spec: {spec!r}")
    if any(v <= 0 for v in values):
        raise ValueError("All termination horizons must be positive integers.")
    return values


def _k_from_filename(path: str) -> int | None:
    """Extract saved total K from `keylock_{K}_{Method}_{outer}.npy`."""
    stem = os.path.splitext(os.path.basename(path))[0]
    parts = stem.split("_")
    if len(parts) < 4 or parts[0] != "keylock":
        return None
    try:
        return int(parts[1])
    except ValueError:
        return None


def _find_saved_k(requested_base_k: int, available_total_ks: set[int]) -> int | None:
    """Map requested base-k to the saved total K on disk, preferring sign-doubled files."""
    if (2 * requested_base_k) in available_total_ks:
        return 2 * requested_base_k
    if requested_base_k in available_total_ks:
        return requested_base_k
    return None


def get_saved_option_sets(method: str, out_dir: str, saved_total_k: int) -> list[np.ndarray]:
    """Load all saved Q-tables for one method and one saved total K."""
    pattern = os.path.join(out_dir, f"keylock_{saved_total_k}_{method}_*.npy")
    files = sorted(glob.glob(pattern))
    if not files:
        raise FileNotFoundError(f"No saved {method} files found for K={saved_total_k} under {out_dir}")
    print(f"[Load] {method} K={saved_total_k}: {len(files)} group(s)")
    return [np.load(path) for path in files]


def build_env(args: argparse.Namespace) -> "KeyLockEnv":
    """Construct the KeyLock environment with CLI geometry."""
    from .env import KeyLockEnv

    return KeyLockEnv(
        size=args.size,
        agent_start_pos=(1, 1),
        agent_start_dir=0,
        yellow_key_pos=tuple(args.yellow_key_pos),
        yellow_door_pos=tuple(args.yellow_door_pos),
        blue_key_pos=tuple(args.blue_key_pos),
        blue_door_pos=tuple(args.blue_door_pos),
        goal_pos=tuple(args.goal_pos),
        render_mode=None,
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Plot KeyLock state-coverage curves for pretrained Eigenoption and VPS-option "
            "families under several option termination probabilities 1/N."
        )
    )
    parser.add_argument("--out_dir", default="keylock_option_results", help="Directory containing saved option Q-tables.")
    parser.add_argument("--save_dir", default=None, help="Directory for the output plot and raw arrays. Defaults to out_dir.")
    parser.add_argument("--num_options", type=int, default=16, help="Base number of options to evaluate.")
    parser.add_argument(
        "--termination_values",
        type=str,
        default="3,15,100",
        help='Termination horizons N. Examples: "5,15,50" or "[5,15,50]".',
    )
    parser.add_argument("--inner", type=int, default=5, help="Number of random-walk runs per saved option group.")
    parser.add_argument("--max_steps", type=int, default=2000, help="Maximum time steps per run.")
    parser.add_argument("--dpi", type=int, default=300, help="Figure DPI.")
    parser.add_argument("--size", type=int, default=15, help="Grid size.")
    parser.add_argument("--yellow_key_pos", type=int, nargs=2, default=[12, 3], help="Yellow key position (x, y).")
    parser.add_argument("--yellow_door_pos", type=int, nargs=2, default=[3, 8], help="Yellow door position (x, y).")
    parser.add_argument("--blue_key_pos", type=int, nargs=2, default=[12, 12], help="Blue key position (x, y).")
    parser.add_argument("--blue_door_pos", type=int, nargs=2, default=[9, 3], help="Blue door position (x, y).")
    parser.add_argument("--goal_pos", type=int, nargs=2, default=[3, 12], help="Goal position (x, y).")
    args = parser.parse_args()

    termination_values = parse_termination_values(args.termination_values)
    methods = ["EigenOpt", "VPSOpt"]
    label_map = {"EigenOpt": "Eigenoption", "VPSOpt": "VPS Option"}

    script_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir = args.out_dir if os.path.isabs(args.out_dir) else os.path.join(script_dir, args.out_dir)
    out_dir = os.path.abspath(out_dir)
    save_dir = out_dir if args.save_dir is None else (
        args.save_dir if os.path.isabs(args.save_dir) else os.path.join(script_dir, args.save_dir)
    )
    save_dir = os.path.abspath(save_dir)
    os.makedirs(save_dir, exist_ok=True)

    env = build_env(args)
    env.reset()
    state_space_size = args.size * args.size * 4 * 2 * 2 * 2 * 2

    available_total_ks: set[int] = set()
    for method in methods:
        pattern = os.path.join(out_dir, f"keylock_*_{method}_*.npy")
        for path in glob.glob(pattern):
            k = _k_from_filename(path)
            if k is not None:
                available_total_ks.add(int(k))
    saved_total_k = _find_saved_k(int(args.num_options), available_total_ks)
    if saved_total_k is None:
        raise FileNotFoundError(
            f"Could not find saved option files for base num_options={args.num_options}. "
            f"Available total-K values in {out_dir}: {sorted(available_total_ks)}"
        )

    q_sets_by_method = {method: get_saved_option_sets(method, out_dir, saved_total_k) for method in methods}
    curves_by_key: dict[tuple[str, int] | tuple[str, None], list[list[int]]] = {}
    visits_by_key: dict[tuple[str, int] | tuple[str, None], np.ndarray] = {}

    curves_by_key[("Random", None)] = []
    visits_by_key[("Random", None)] = np.zeros(state_space_size, dtype=np.int64)

    for method in methods:
        for termination_horizon in termination_values:
            curves_by_key[(method, termination_horizon)] = []
            visits_by_key[(method, termination_horizon)] = np.zeros(state_space_size, dtype=np.int64)

    primitive_outer = max(len(q_sets_by_method[method]) for method in methods)
    for outer_idx in range(primitive_outer):
        set_seed(outer_idx)
        for inner_idx in range(int(args.inner)):
            random.seed((outer_idx + 1) * 10_000 + inner_idx)
            np.random.seed((outer_idx + 1) * 10_000 + inner_idx)
            curve, visits = random_walk_cover(
                env=env,
                size=args.size,
                state_space_size=state_space_size,
                max_steps=args.max_steps,
            )
            curves_by_key[("Random", None)].append(curve)
            visits_by_key[("Random", None)] += visits
        print(f"[Run] method=Random group={outer_idx} runs={args.inner}")

    for method in methods:
        for outer_idx, Q in enumerate(q_sets_by_method[method]):
            set_seed(outer_idx)
            for termination_horizon in termination_values:
                for inner_idx in range(int(args.inner)):
                    random.seed((outer_idx + 1) * 100_000 + termination_horizon * 1_000 + inner_idx)
                    np.random.seed((outer_idx + 1) * 100_000 + termination_horizon * 1_000 + inner_idx)
                    curve, visits = mixed_walk_cover(
                        env=env,
                        size=args.size,
                        state_space_size=state_space_size,
                        Q=Q,
                        max_steps=args.max_steps,
                        termination_horizon=termination_horizon,
                    )
                    curves_by_key[(method, termination_horizon)].append(curve)
                    visits_by_key[(method, termination_horizon)] += visits
                print(
                    f"[Run] method={method} group={outer_idx} termination_N={termination_horizon} "
                    f"runs={args.inner}"
                )

    env.close()

    x = np.arange(int(args.max_steps))
    color_map = {"Random": "tab:blue", "EigenOpt": "tab:orange", "VPSOpt": "tab:green"}
    if len(termination_values) == 3:
        line_styles = ["-", (0, (6, 3)), ":"]
    else:
        line_styles = ["-", (0, (6, 3)), ":", "-."]
    linestyle_map = {
        termination_horizon: line_styles[idx % len(line_styles)]
        for idx, termination_horizon in enumerate(termination_values)
    }
    plt.figure(figsize=(9.8, 4.8))
    random_runs = curves_by_key[("Random", None)]
    if random_runs:
        random_mat = np.vstack([pad_curve(curve, int(args.max_steps)) for curve in random_runs])
        random_mu = random_mat.mean(axis=0)
        random_sig = random_mat.std(axis=0)
        plt.plot(x, random_mu, color=color_map["Random"], linestyle="-", linewidth=1.9, label="Random Walk")
        plt.fill_between(x, random_mu - random_sig, random_mu + random_sig, color=color_map["Random"], alpha=0.12)

    for method in methods:
        for termination_horizon in termination_values:
            runs = curves_by_key[(method, termination_horizon)]
            if not runs:
                continue
            mat = np.vstack([pad_curve(curve, int(args.max_steps)) for curve in runs])
            mu = mat.mean(axis=0)
            sig = mat.std(axis=0)
            label = f"{label_map[method]} (N={termination_horizon})"
            plt.plot(
                x,
                mu,
                color=color_map[method],
                linestyle=linestyle_map[termination_horizon],
                linewidth=1.9,
                label=label,
            )
            plt.fill_between(x, mu - sig, mu + sig, color=color_map[method], alpha=0.10)

    plt.xlabel("Time Steps", fontsize=16)
    plt.ylabel("Number of Visited States", fontsize=16)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.title(f"KeyLock State Coverage Curves (num_options={args.num_options})", fontsize=16)
    plt.grid(alpha=0.3)
    plt.xlim(-5, int(args.max_steps))
    legend_handles = [
        Line2D([0], [0], color=color_map["Random"], linestyle="-", linewidth=1.9, label="Random Walk")
    ]
    for method in methods:
        for termination_horizon in termination_values:
            legend_handles.append(
                Line2D(
                    [0],
                    [0],
                    color=color_map[method],
                    linestyle=linestyle_map[termination_horizon],
                    linewidth=1.9,
                    label=f"{label_map[method]} (N={termination_horizon})",
                )
            )
    plt.legend(handles=legend_handles, fontsize=11, ncol=2)
    plt.tight_layout()

    plot_path = os.path.join(save_dir, f"keylock_option_termination_coverage_k{args.num_options}.png")
    plt.savefig(plot_path, dpi=int(args.dpi), bbox_inches="tight")
    plt.show()
    print(f"[Save] Coverage curves saved to {plot_path}")

    payload: dict[str, np.ndarray] = {}
    summary_lines: list[str] = []
    random_mat = np.vstack([pad_curve(curve, int(args.max_steps)) for curve in random_runs]).astype(np.float32)
    random_visits = visits_by_key[("Random", None)].astype(np.int64)
    payload["Random_curves"] = random_mat
    payload["Random_visit_counts"] = random_visits
    random_unique_states = int((random_visits > 0).sum())
    random_coverage_pct = 100.0 * random_unique_states / float(state_space_size)
    summary_lines.append(
        f"Random Walk: runs={random_mat.shape[0]}, final_mean={random_mat[:, -1].mean():.2f}, "
        f"unique_states={random_unique_states}/{state_space_size} ({random_coverage_pct:.2f}%)"
    )
    for method in methods:
        for termination_horizon in termination_values:
            runs = curves_by_key[(method, termination_horizon)]
            mat = np.vstack([pad_curve(curve, int(args.max_steps)) for curve in runs]).astype(np.float32)
            visits = visits_by_key[(method, termination_horizon)].astype(np.int64)
            key = f"{method}_N{termination_horizon}"
            payload[f"{key}_curves"] = mat
            payload[f"{key}_visit_counts"] = visits
            unique_states = int((visits > 0).sum())
            coverage_pct = 100.0 * unique_states / float(state_space_size)
            summary_lines.append(
                f"{label_map[method]} N={termination_horizon}: "
                f"runs={mat.shape[0]}, final_mean={mat[:, -1].mean():.2f}, "
                f"unique_states={unique_states}/{state_space_size} ({coverage_pct:.2f}%)"
            )

    npz_path = os.path.join(save_dir, f"keylock_option_termination_coverage_k{args.num_options}.npz")
    np.savez_compressed(
        npz_path,
        num_options=np.asarray(int(args.num_options), dtype=np.int32),
        saved_total_k=np.asarray(int(saved_total_k), dtype=np.int32),
        max_steps=np.asarray(int(args.max_steps), dtype=np.int32),
        inner=np.asarray(int(args.inner), dtype=np.int32),
        termination_values=np.asarray(termination_values, dtype=np.int32),
        **payload,
    )
    print(f"[Save] Raw curve arrays saved to {npz_path}")

    print("\n[Summary]")
    for line in summary_lines:
        print(f"  {line}")


if __name__ == "__main__":
    main()
