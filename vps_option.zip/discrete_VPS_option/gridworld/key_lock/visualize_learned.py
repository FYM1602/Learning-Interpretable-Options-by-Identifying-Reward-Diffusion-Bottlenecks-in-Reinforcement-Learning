"""Visualize trained KeyLock options (CLI: ``python -m gridworld keylock viz ...``).

Subcommands: ``fields`` (V/φ per-configuration plots), ``rollout`` (interactive Q-table demo).
"""

from __future__ import annotations

import argparse
import sys


def run_rollout(argv: list[str] | None = None) -> None:
    from .viz_rollout import main

    old = sys.argv
    try:
        sys.argv = ["viz_rollout", *(argv or [])]
        main()
    finally:
        sys.argv = old


def run_fields(argv: list[str] | None = None) -> None:
    """Library helpers for comprehensive V/φ figures (import from this module)."""
    parser = argparse.ArgumentParser(
        description=(
            "KeyLock learned V/φ visualization helpers. "
            "Import visualize_vps_option_comprehensive / visualize_eigenvector_comprehensive "
            "from gridworld.key_lock.visualize_learned after training, or enable --visualize in keylock train."
        )
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List exported visualization functions and exit.",
    )
    args = parser.parse_args(argv)
    if args.list or True:
        from . import viz_fields as vf

        names = [
            n
            for n in dir(vf)
            if n.startswith("visualize_") and callable(getattr(vf, n))
        ]
        print("Available functions in gridworld.key_lock.visualize_learned (viz_fields):")
        for n in sorted(names):
            print(f"  - {n}")


def build_viz_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Visualize trained KeyLock options")
    sub = parser.add_subparsers(dest="viz_cmd", metavar="VIZ_CMD")
    sub.add_parser("fields", help="V/φ per-configuration plot helpers (library API)")
    sub.add_parser("rollout", help="Roll out saved option Q-tables in the environment")
    return parser


def _parse_viz_argv(argv: list[str] | None) -> tuple[str, list[str]]:
    if not argv:
        return "", []
    if argv[0] in ("fields", "rollout"):
        return argv[0], argv[1:]
    return "", argv


def main(argv: list[str] | None = None) -> None:
    viz_cmd, rest = _parse_viz_argv(argv)
    if not viz_cmd:
        build_viz_parser().parse_args(rest if rest else ["--help"])
        return
    if viz_cmd == "rollout":
        run_rollout(rest)
    else:
        run_fields(rest)


if __name__ == "__main__":
    main()
