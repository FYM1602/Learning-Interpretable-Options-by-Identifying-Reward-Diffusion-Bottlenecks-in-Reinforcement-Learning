"""KeyLock state index encoding and env reset helpers."""
import numpy as np

def state_to_index(
    x, y, dir,
    yellow_door_open, blue_door_open,
    yellow_key_on_map, blue_key_on_map,
    size=15,
):
    index = x
    index = index * size + y
    index = index * 4 + dir
    index = index * 2 + yellow_door_open
    index = index * 2 + blue_door_open
    index = index * 2 + yellow_key_on_map
    index = index * 2 + blue_key_on_map
    return int(index)


def index_to_state(state_index, size=15):
    total = size * size * 4 * 2 * 2 * 2 * 2
    state_index = state_index % total

    blue_key_on_map = state_index % 2
    state_index //= 2

    yellow_key_on_map = state_index % 2
    state_index //= 2

    blue_door_open = state_index % 2
    state_index //= 2

    yellow_door_open = state_index % 2
    state_index //= 2

    dir = state_index % 4
    state_index //= 4

    y = state_index % size
    state_index //= size

    x = state_index % size

    return (
        x, y, dir,
        yellow_door_open, blue_door_open,
        yellow_key_on_map, blue_key_on_map,
    )


def set_seed(sd):
    if sd is not None:
        np.random.seed(sd)
        random.seed(sd)


def _parse_num_opts_list(x) -> list[int]:
    if isinstance(x, int):
        return [int(x)]
    if isinstance(x, (list, tuple)):
        return [int(v) for v in x]
    s = str(x).strip()
    if not s:
        raise ValueError("--num_opts is empty")
    if "," in s and not (s.startswith("[") or s.startswith("(")):
        return [int(p.strip()) for p in s.split(",") if p.strip()]
    try:
        val = ast.literal_eval(s)
    except Exception:
        return [int(s)]
    if isinstance(val, int):
        return [int(val)]
    if isinstance(val, (list, tuple)):
        return [int(v) for v in val]
    raise ValueError(f"Unsupported --num_opts format: {x!r}")


def option_rows_dup(arr, sign):
    """Duplicate positive/negative rows when sign=True."""
    return np.vstack([arr, arr]) if sign else arr


def build_state_index_mapping(valid_states, N_full):
    valid_states = np.array(valid_states, dtype=np.int32)
    valid_states = np.sort(valid_states)  # Sort for consistent ordering
    
    N_valid = len(valid_states)
    
    # Create mapping: full_index -> compressed_index
    state_to_compressed = {}
    for compressed_idx, full_idx in enumerate(valid_states):
        state_to_compressed[int(full_idx)] = compressed_idx
    
    # Create reverse mapping: compressed_index -> full_index
    compressed_to_state = valid_states.copy()
    
    print(f"[State Mapping] Created mapping: {N_valid} valid states out of {N_full} total states")
    print(f"[State Mapping] Compression ratio: {N_valid / N_full * 100:.2f}%")
    
    return state_to_compressed, compressed_to_state, N_valid


def convert_buffer_to_compressed(buffer, state_to_compressed):
    compressed_buffer = []
    for s, a, sn, done in buffer:
        s_full = int(s)
        sn_full = int(sn)
        
        # Convert to compressed indices
        s_compressed = state_to_compressed.get(s_full)
        sn_compressed = state_to_compressed.get(sn_full)
        
        # Skip if state not in mapping (shouldn't happen, but safety check)
        if s_compressed is None or sn_compressed is None:
            continue
        
        compressed_buffer.append((s_compressed, a, sn_compressed, done))
    
    return compressed_buffer


def expand_compressed_features(features_compressed, compressed_to_state, N_full):
    is_1d = features_compressed.ndim == 1
    if is_1d:
        features_compressed = features_compressed[np.newaxis, :]
    
    k, N_valid = features_compressed.shape
    
    # Initialize full feature array with zeros
    features_full = np.zeros((k, N_full), dtype=features_compressed.dtype)
    
    # Map compressed indices to full indices
    for compressed_idx in range(N_valid):
        full_idx = int(compressed_to_state[compressed_idx])
        features_full[:, full_idx] = features_compressed[:, compressed_idx]
    
    if is_1d:
        features_full = features_full[0]
    
    return features_full


def get_wall_positions(env, size):
    wall_positions = []
    from minigrid.core.world_object import Wall
    
    for x in range(size):
        for y in range(size):
            cell = env.grid.get(x, y)
            if cell is not None and isinstance(cell, Wall):
                wall_positions.append((x, y))
    
    return wall_positions


def visualize_feature_distribution(
    features, size: int, save_dir: str, prefix: str,
    iteration: int = 0, max_options_to_plot: int = 4, env=None
):
    # Handle both 1D (eigenvector) and 2D (VPS features) cases
    is_single_feature = features.ndim == 1
    if is_single_feature:
        features = features[np.newaxis, :]  # (1, N)
    
    k, N = features.shape
    num_to_plot = min(k, max_options_to_plot)
    
    state_configs = [
        {
            "name": "No keys",
            "yellow_door_open": 0,
            "blue_door_open": 0,
            "yellow_key_on_map": 1,
            "blue_key_on_map": 1,
        },
        {
            "name": "Blue key picked",
            "yellow_door_open": 0,
            "blue_door_open": 0,
            "yellow_key_on_map": 1,  # Yellow key still on map
            "blue_key_on_map": 0,     # Blue key removed from map when picked
        },
        {
            "name": "Blue door open",
            "yellow_door_open": 0,
            "blue_door_open": 1,
            "yellow_key_on_map": 1,  # Yellow key still on map
            "blue_key_on_map": 0,     # Blue key was consumed, not on map
        },
        {
            "name": "Yellow key picked",
            "yellow_door_open": 0,
            "blue_door_open": 1,  # Blue door must be open to reach yellow key
            "yellow_key_on_map": 0,  # Yellow key removed from map when picked
            "blue_key_on_map": 0,     # Blue key was consumed, not on map
        },
        {
            "name": "Both doors open",
            "yellow_door_open": 1,
            "blue_door_open": 1,
            "yellow_key_on_map": 0,  # Both keys consumed, not on map
            "blue_key_on_map": 0,
        },
    ]
    
    # Create figure with subplots
    if num_to_plot == 1 and len(state_configs) == 1:
        fig, axes = plt.subplots(1, 1, figsize=(6, 6))
        axes = np.array([[axes]])
    elif num_to_plot == 1:
        fig, axes = plt.subplots(1, len(state_configs), figsize=(4 * len(state_configs), 4))
        axes = axes[np.newaxis, :] if len(state_configs) > 1 else np.array([[axes]])
    elif len(state_configs) == 1:
        fig, axes = plt.subplots(num_to_plot, 1, figsize=(6, 4 * num_to_plot))
        axes = axes[:, np.newaxis]
    else:
        fig, axes = plt.subplots(
            num_to_plot, len(state_configs), 
            figsize=(4 * len(state_configs), 4 * num_to_plot)
        )
    
    # Get wall positions if env is provided
    wall_positions = []
    if env is not None:
        wall_positions = get_wall_positions(env, size)
    
    for opt_idx in range(num_to_plot):
        for config_idx, config in enumerate(state_configs):
            heatmap = np.zeros((size, size))
            heatmap.fill(np.nan)
            
            for x in range(size):
                for y in range(size):
                    if (x, y) in wall_positions:
                        continue
                    vals = []
                    for dir_fixed in range(4):
                        s = state_to_index(
                            x, y, dir_fixed,
                            config["yellow_door_open"],
                            config["blue_door_open"],
                            config.get("yellow_key_on_map", 1),
                            config.get("blue_key_on_map", 1),
                            size
                        )
                        vals.append(features[opt_idx, s])
                    if len(vals) > 0:
                        heatmap[y, x] = np.mean(vals)
            
            ax = axes[opt_idx, config_idx]
            masked_heatmap = np.ma.masked_invalid(heatmap)
            cmap = plt.cm.viridis.copy()
            cmap.set_bad(color='gray', alpha=0.5)
            im = ax.imshow(masked_heatmap, origin='upper', cmap=cmap, aspect='auto', 
                          extent=[0, size, 0, size])
            
            ax.set_title(f"{prefix} opt {opt_idx}\n{config['name']}", fontsize=10)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    
    plt.tight_layout()
    
    # Save figure
    os.makedirs(save_dir, exist_ok=True)
    filename = os.path.join(save_dir, f"{prefix}_distribution_iter{iteration:04d}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  [Viz] Saved {filename}")


def reset_env_to_state(env, x, y, dir,
                      yellow_door_open, blue_door_open,
                      yellow_key_on_map=1, blue_key_on_map=1):
    env.reset()
    env.yellow_key_on_map = int(yellow_key_on_map)
    env.blue_key_on_map = int(blue_key_on_map)
    env._place_keys_doors_goal()
    env.agent_pos = (x, y)
    env.agent_dir = dir
    
    from minigrid.core.world_object import Key, Door
    env.carrying = None
    
    if yellow_key_on_map == 0 and yellow_door_open == 0:
        env.carrying = Key('yellow')
    elif blue_key_on_map == 0 and blue_door_open == 0:
        env.carrying = Key('blue')
    
    yellow_door_cell = env.grid.get(*env.yellow_door_pos)
    if yellow_door_cell is not None and isinstance(yellow_door_cell, Door):
        yellow_door_cell.is_open = bool(yellow_door_open)
        yellow_door_cell.is_locked = False if yellow_key_on_map == 0 else not yellow_door_open
        if yellow_door_open:
            env.yellow_key_on_map = 0
            env.grid.set(*env.yellow_key_pos, None)
    
    blue_door_cell = env.grid.get(*env.blue_door_pos)
    if blue_door_cell is not None and isinstance(blue_door_cell, Door):
        blue_door_cell.is_open = bool(blue_door_open)
        blue_door_cell.is_locked = False if blue_key_on_map == 0 else not blue_door_open
        if blue_door_open:
            env.blue_key_on_map = 0
            env.grid.set(*env.blue_key_pos, None)


