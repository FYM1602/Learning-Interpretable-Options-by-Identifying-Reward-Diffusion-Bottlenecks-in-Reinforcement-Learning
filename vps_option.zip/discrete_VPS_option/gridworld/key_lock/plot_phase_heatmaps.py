#!/usr/bin/env python
"""Plot phase-conditioned KeyLock VPS heatmaps from saved distributions.

This script visualizes a saved VPS distribution array (typically V or phi)
for the KeyLock environment under all logically possible object-state
configurations that are reachable from the initial state.

For each reachable configuration and each (x, y), the heatmap value is the
mean of all reachable states (x, y, direction) that match the configuration.
Unreachable positions are masked. The true object state for that configuration
is drawn on top of the heatmap using door/key/goal markers.

Notes
-----
- The input array must be a saved VPS distribution such as V or phi with shape
  (K, N), (N, K), or (N,) for a single option.
- This script does not interpret a Q-table of shape (K, N, A) as a VPS
  distribution. If you only saved Q, you need to save V/phi separately.
- By default, when ``--feature_path`` is omitted, the script searches
  ``keylock_option_results`` next to this file for saved ``VPSValue`` or
  ``VPSPhi`` arrays using ``--feature_kind``, ``--k`` and ``--group``.
"""

from __future__ import annotations

import argparse
import glob
import os
from math import ceil

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from .transitions import build_keylock_transition_matrix
from .env import KeyLockEnv
from .state_codec import index_to_state, state_to_index
from .plotting_utils import (
    add_object_overlay,
    add_shared_legend,
    aggregate_heatmap,
    build_reachable_state_set,
    enumerate_reachable_configs,
    get_wall_positions,
    parse_option_ids,
    OBJECT_STATE_LEVELS,
)

FEATURE_TYPE_TO_TAG = {
    "value": "VPSValue",
    "phi": "VPSPhi",
}


def plot_option(
    feature: np.ndarray,
    option_id: int,
    args: argparse.Namespace,
    configs: list[dict],
    reachable_states: set[int],
    wall_positions: set[tuple[int, int]],
    output_dir: str,
) -> None:
    """Plot one option over all configured object-state panels."""
    heatmaps = [
        aggregate_heatmap(feature, args.size, config, reachable_states, wall_positions)
        for config in configs
    ]

    n_configs = len(configs)
    ncols = min(3, n_configs)
    nrows = ceil(n_configs / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(4.4 * ncols, 4.2 * nrows))
    axes = np.atleast_1d(axes).ravel()

    cmap = plt.cm.viridis.copy()
    cmap.set_bad(color="lightgray", alpha=0.9)

    for ax, config, heatmap in zip(axes, configs, heatmaps):
        finite_vals = heatmap[np.isfinite(heatmap)]
        if finite_vals.size == 0:
            vmin, vmax = 0.0, 1.0
        else:
            vmin = float(finite_vals.min())
            vmax = float(finite_vals.max())
            if np.isclose(vmin, vmax):
                vmax = vmin + 1e-6

        masked = np.ma.masked_invalid(heatmap)
        image = ax.imshow(masked, origin="upper", cmap=cmap, vmin=vmin, vmax=vmax)
        add_object_overlay(ax, args, config)

        if not np.isfinite(heatmap).any():
            ax.text(
                0.5, 0.5, "No reachable\nstates",
                ha="center", va="center", transform=ax.transAxes,
                fontsize=11, color="black",
                bbox=dict(facecolor="white", alpha=0.8, edgecolor="none"),
            )

        ax.set_title(
            f"{config['name']}\nreachable states: {config['reachable_state_count']}",
            fontsize=11,
            pad=8,
        )
        ax.set_xticks(range(0, args.size, max(1, args.size // 5)))
        ax.set_yticks(range(0, args.size, max(1, args.size // 5)))
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_xlim(-0.5, args.size - 0.5)
        ax.set_ylim(args.size - 0.5, -0.5)
        cbar = fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label(args.feature_label, fontsize=10)

    for ax in axes[n_configs:]:
        ax.set_visible(False)

    fig.suptitle(
        f"{args.feature_label} heatmaps for VPS option {option_id}\n"
        "Mean over reachable (x, y, direction) states for each reachable object-state configuration",
        fontsize=14,
        y=0.98,
    )
    add_shared_legend(fig)

    fig.subplots_adjust(left=0.05, right=0.97, bottom=0.14, top=0.86, wspace=0.55, hspace=0.45)

    os.makedirs(output_dir, exist_ok=True)
    save_path = os.path.join(output_dir, f"{args.output_prefix}_opt{option_id:02d}.png")
    fig.savefig(save_path, dpi=args.dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"[Save] {save_path}")


def build_arg_parser() -> argparse.ArgumentParser:
    """Create the CLI parser."""
    parser = argparse.ArgumentParser(
        description="Plot phase-conditioned KeyLock VPS heatmaps from saved V/phi arrays."
    )
    parser.add_argument("--feature_path", default=None,
                        help="Path to a saved VPS distribution array (.npy or .npz). "
                             "If omitted, auto-load from --result_dir.")
    parser.add_argument("--feature_kind", choices=["value", "phi"], default="value",
                        help="Which saved VPS distribution to auto-load when --feature_path is omitted.")
    parser.add_argument("--result_dir", default="keylock_option_results",
                        help="Directory containing saved VPS result files.")
    parser.add_argument("--k", type=int, default=None,
                        help="Total number of saved options K in the filename, e.g. 8.")
    parser.add_argument("--group", type=int, default=0,
                        help="Outer-index file to load when multiple matching files exist.")
    parser.add_argument("--array_key", default=None,
                        help="Array key inside .npz file (required if the file contains multiple arrays).")
    parser.add_argument("--feature_label", default=None,
                        help="Label shown in titles/colorbar, e.g. 'V(s)' or 'phi(s)'. "
                             "Default depends on --feature_kind.")
    parser.add_argument("--option_ids", default=None,
                        help="Comma-separated option ids or ranges, e.g. '0,2,4-7'. Default: all.")
    parser.add_argument("--size", type=int, default=15, help="Grid size.")
    parser.add_argument("--yellow_key_pos", type=int, nargs=2, default=[12, 3], help="Yellow key position (x, y).")
    parser.add_argument("--yellow_door_pos", type=int, nargs=2, default=[3, 8], help="Yellow door position (x, y).")
    parser.add_argument("--blue_key_pos", type=int, nargs=2, default=[12, 12], help="Blue key position (x, y).")
    parser.add_argument("--blue_door_pos", type=int, nargs=2, default=[9, 3], help="Blue door position (x, y).")
    parser.add_argument("--goal_pos", type=int, nargs=2, default=[3, 12], help="Goal position (x, y).")
    parser.add_argument("--output_dir", default=None,
                        help="Directory for saved figures. Default: sibling folder named 'vps_phase_heatmaps'.")
    parser.add_argument("--output_prefix", default="keylock_vps_phase",
                        help="Filename prefix for saved figures.")
    parser.add_argument("--dpi", type=int, default=200, help="Figure dpi.")
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.feature_label is None:
        args.feature_label = "V(s)" if args.feature_kind == "value" else "phi(s)"

    feature_path = resolve_feature_path(args)
    features = load_feature_array(feature_path, args.size, args.array_key)
    option_ids = parse_option_ids(args.option_ids, features.shape[0])

    if args.output_dir is None:
        output_dir = os.path.join(os.path.dirname(feature_path), "vps_phase_heatmaps")
    else:
        output_dir = os.path.abspath(args.output_dir)

    env = make_env(args)
    env.reset()
    wall_positions = get_wall_positions(env, args.size)
    reachable_states = build_reachable_state_set(env, args)
    configs = enumerate_reachable_configs(reachable_states, args.size)

    print(f"[Info] Loaded feature array: {features.shape}")
    print(f"[Info] Plotting option ids: {option_ids}")
    print(f"[Info] Reachable states: {len(reachable_states)}")
    print(f"[Info] Reachable object-state configs: {[cfg['name'] for cfg in configs]}")

    try:
        for option_id in option_ids:
            plot_option(
                features[option_id],
                option_id,
                args,
                configs,
                reachable_states,
                wall_positions,
                output_dir,
            )
    finally:
        env.close()


if __name__ == "__main__":
    main()
