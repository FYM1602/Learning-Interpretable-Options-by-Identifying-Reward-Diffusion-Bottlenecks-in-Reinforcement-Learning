"""KeyLock paper figures (CLI: ``python -m gridworld keylock plot ...``).

Subcommands: ``phase-heatmaps``, ``boxplot``, ``coverage``.
"""

from __future__ import annotations

import argparse
import sys


def _parse_plot_argv(argv: list[str] | None) -> tuple[str, list[str]]:
    if not argv:
        return "", []
    if argv[0] in ("phase-heatmaps", "boxplot", "coverage"):
        return argv[0], argv[1:]
    return "", argv


def run_phase_heatmaps(argv: list[str] | None = None) -> None:
    from .plot_phase_heatmaps import main

    old = sys.argv
    try:
        sys.argv = ["plot_phase_heatmaps", *(argv or [])]
        main()
    finally:
        sys.argv = old


def run_boxplot(argv: list[str] | None = None) -> None:
    from .plot_boxplot import main

    old = sys.argv
    try:
        sys.argv = ["plot_boxplot", *(argv or [])]
        main()
    finally:
        sys.argv = old


def run_coverage(argv: list[str] | None = None) -> None:
    from .plot_coverage import main

    old = sys.argv
    try:
        sys.argv = ["plot_coverage", *(argv or [])]
        main()
    finally:
        sys.argv = old


def build_plot_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="KeyLock paper figure scripts")
    sub = parser.add_subparsers(dest="plot_cmd", metavar="PLOT_CMD")
    sub.add_parser("phase-heatmaps", help="Phase-conditioned VPS heatmaps from saved V/phi")
    sub.add_parser("boxplot", help="Option random-walk success-count boxplots")
    sub.add_parser("coverage", help="Eigen vs VPS termination coverage curves")
    return parser


def main(argv: list[str] | None = None) -> None:
    plot_cmd, rest = _parse_plot_argv(argv)
    if not plot_cmd:
        parser = build_plot_parser()
        parser.parse_args(rest if rest else ["--help"])
        return
    runners = {
        "phase-heatmaps": run_phase_heatmaps,
        "boxplot": run_boxplot,
        "coverage": run_coverage,
    }
    runners[plot_cmd](rest)


if __name__ == "__main__":
    main()
