#!/usr/bin/env python
"""
Improved VPS option visualization.

Design:
1. Plot value V(s) and VPS features φ(s) separately
2. One large figure per option with subplots per state configuration
3. Clear titles and colormaps
4. Optionally show only key stages
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from .state_codec import state_to_index, get_wall_positions


def visualize_vps_option_comprehensive(
    V_base,  # Value functions, shape (k_base, N)
    phi_base,  # VPS features, shape (k_base, N)
    size: int,
    save_dir: str,
    prefix: str = "vps_comprehensive",
    iteration: int = 0,
    max_options_to_plot: int = 4,
    env=None,
    state_configs=None,
):
    """
    Comprehensive visualization of VPS option values and VPS features.
    
    For each option, one figure with:
    - Value V(s) per state configuration (top row)
    - VPS feature φ(s) per state configuration (bottom row)
    
    Args:
        V_base: Value functions, shape (k_base, N)
        phi_base: VPS features, shape (k_base, N)
        size: Grid size
        save_dir: Directory to save figures
        prefix: Prefix for saved files
        iteration: Current iteration number
        max_options_to_plot: Maximum number of options to plot
        env: Optional KeyLockEnv instance for wall visualization
        state_configs: Optional list of state configs to visualize (if None, uses default 5 configs)
    """
    k_base, N = V_base.shape
    
    # Default state configurations
    if state_configs is None:
        state_configs = [
            {
                "name": "Initial\n(no keys, doors closed)",
                "short_name": "Init",
                "yellow_door_open": 0,
                "blue_door_open": 0,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 1,
            },
            {
                "name": "Blue key collected\n(doors closed)",
                "short_name": "BlueKey",
                "yellow_door_open": 0,
                "blue_door_open": 0,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 0,
            },
            {
                "name": "Blue door open\n(blue key consumed)",
                "short_name": "BlueDoor",
                "yellow_door_open": 0,
                "blue_door_open": 1,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 0,
            },
            {
                "name": "Yellow key collected\n(blue door open)",
                "short_name": "YellowKey",
                "yellow_door_open": 0,
                "blue_door_open": 1,
                "yellow_key_on_map": 0,
                "blue_key_on_map": 0,
            },
            {
                "name": "Both doors open\n(keys consumed)",
                "short_name": "Done",
                "yellow_door_open": 1,
                "blue_door_open": 1,
                "yellow_key_on_map": 0,
                "blue_key_on_map": 0,
            },
        ]
    
    num_configs = len(state_configs)
    num_to_plot = min(k_base, max_options_to_plot)
    
    # Get wall positions if env is provided
    wall_positions = []
    if env is not None:
        wall_positions = get_wall_positions(env, size)
    
    # Visualize each option separately
    for opt_idx in range(num_to_plot):
        # Create a large figure for this option
        # Layout: 2 rows (Value function, VPS feature) × num_configs columns
        fig = plt.figure(figsize=(4 * num_configs, 8))
        gs = GridSpec(2, num_configs, figure=fig, hspace=0.3, wspace=0.3)
        
        # Row 1: Value functions V(s)
        for config_idx, config in enumerate(state_configs):
            ax_v = fig.add_subplot(gs[0, config_idx])
            heatmap_v = _create_heatmap(
                V_base[opt_idx], size, config, wall_positions
            )
            _plot_heatmap(
                ax_v, heatmap_v, size,
                title=f"Value V(s)\n{config['short_name']}",
                cmap='viridis'
            )
        
        # Row 2: VPS features φ(s)
        for config_idx, config in enumerate(state_configs):
            ax_phi = fig.add_subplot(gs[1, config_idx])
            heatmap_phi = _create_heatmap(
                phi_base[opt_idx], size, config, wall_positions
            )
            _plot_heatmap(
                ax_phi, heatmap_phi, size,
                title=f"VPS feature φ(s)\n{config['short_name']}",
                cmap='hot'
            )
        
        # Add overall title
        fig.suptitle(f'VPS Option {opt_idx} - value and feature maps', 
                     fontsize=14, fontweight='bold', y=0.98)
        
        # Save figure
        os.makedirs(save_dir, exist_ok=True)
        filename = os.path.join(save_dir, f"{prefix}_opt{opt_idx}_iter{iteration:04d}.png")
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  [Viz] Saved {filename}")


def visualize_vps_option_side_by_side(
    V_base,  # Value functions, shape (k_base, N)
    phi_base,  # VPS features, shape (k_base, N)
    size: int,
    save_dir: str,
    prefix: str = "vps_side_by_side",
    iteration: int = 0,
    max_options_to_plot: int = 4,
    env=None,
    state_configs=None,
):
    """
    Side-by-side value and VPS feature plots.
    
    Layout: one row per option, two columns per config (value | VPS).
    """
    k_base, N = V_base.shape
    
    # Default state configurations
    if state_configs is None:
        state_configs = [
            {
                "name": "Initial state",
                "short_name": "Init",
                "yellow_door_open": 0,
                "blue_door_open": 0,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 1,
            },
            {
                "name": "Blue key collected",
                "short_name": "BlueKey",
                "yellow_door_open": 0,
                "blue_door_open": 0,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 0,
            },
            {
                "name": "Blue door open",
                "short_name": "BlueDoor",
                "yellow_door_open": 0,
                "blue_door_open": 1,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 0,
            },
            {
                "name": "Yellow key collected",
                "short_name": "YellowKey",
                "yellow_door_open": 0,
                "blue_door_open": 1,
                "yellow_key_on_map": 0,
                "blue_key_on_map": 0,
            },
            {
                "name": "Both doors open",
                "short_name": "Done",
                "yellow_door_open": 1,
                "blue_door_open": 1,
                "yellow_key_on_map": 0,
                "blue_key_on_map": 0,
            },
        ]
    
    num_configs = len(state_configs)
    num_to_plot = min(k_base, max_options_to_plot)
    
    # Get wall positions if env is provided
    wall_positions = []
    if env is not None:
        wall_positions = get_wall_positions(env, size)
    
    # Visualize each option separately
    for opt_idx in range(num_to_plot):
        # Create figure: rows = num_configs, cols = 2 (V | φ)
        fig, axes = plt.subplots(
            num_configs, 2,
            figsize=(10, 4 * num_configs)
        )
        
        if num_configs == 1:
            axes = axes[np.newaxis, :]
        
        for config_idx, config in enumerate(state_configs):
            # Left: Value function
            ax_v = axes[config_idx, 0]
            heatmap_v = _create_heatmap(
                V_base[opt_idx], size, config, wall_positions
            )
            _plot_heatmap(
                ax_v, heatmap_v, size,
                title=f"Value V(s) - {config['short_name']}",
                cmap='viridis'
            )
            
            # Right: VPS feature
            ax_phi = axes[config_idx, 1]
            heatmap_phi = _create_heatmap(
                phi_base[opt_idx], size, config, wall_positions
            )
            _plot_heatmap(
                ax_phi, heatmap_phi, size,
                title=f"VPS feature φ(s) - {config['short_name']}",
                cmap='hot'
            )
        
        # Add overall title
        fig.suptitle(f'VPS Option {opt_idx} - value and feature maps', 
                     fontsize=14, fontweight='bold')
        
        plt.tight_layout()
        
        # Save figure
        os.makedirs(save_dir, exist_ok=True)
        filename = os.path.join(save_dir, f"{prefix}_opt{opt_idx}_iter{iteration:04d}.png")
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  [Viz] Saved {filename}")


def visualize_vps_option_key_stages(
    V_base,  # Value functions, shape (k_base, N)
    phi_base,  # VPS features, shape (k_base, N)
    size: int,
    save_dir: str,
    prefix: str = "vps_key_stages",
    iteration: int = 0,
    max_options_to_plot: int = 4,
    env=None,
):
    """
    Plot key stages only: initial, blue door open, completed.
    
    Minimal layout for a quick read of option behavior.
    """
    key_configs = [
        {
            "name": "Initial\n(no keys, doors closed)",
            "short_name": "Init",
            "yellow_door_open": 0,
            "blue_door_open": 0,
            "yellow_key_on_map": 1,
            "blue_key_on_map": 1,
        },
        {
            "name": "Blue door open\n(key milestone)",
            "short_name": "BlueDoor",
            "yellow_door_open": 0,
            "blue_door_open": 1,
            "yellow_key_on_map": 1,
            "blue_key_on_map": 0,
        },
        {
            "name": "Both doors open\n(task complete)",
            "short_name": "Done",
            "yellow_door_open": 1,
            "blue_door_open": 1,
            "yellow_key_on_map": 0,
            "blue_key_on_map": 0,
        },
    ]
    
    visualize_vps_option_comprehensive(
        V_base, phi_base, size, save_dir, prefix, iteration,
        max_options_to_plot, env, state_configs=key_configs
    )


def _create_heatmap(feature_array, size, config, wall_positions):
    """Build a heatmap for one state configuration."""
    heatmap = np.zeros((size, size))
    heatmap.fill(np.nan)
    
    for x in range(size):
        for y in range(size):
            if (x, y) in wall_positions:
                continue
            
            vals = []
            for dir_fixed in range(4):
                s = state_to_index(
                    x, y, dir_fixed,
                    config["yellow_door_open"],
                    config["blue_door_open"],
                    config.get("yellow_key_on_map", 1),
                    config.get("blue_key_on_map", 1),
                    size
                )
                vals.append(feature_array[s])
            
            if len(vals) > 0:
                heatmap[y, x] = np.mean(vals)
    
    return heatmap


def _plot_heatmap(ax, heatmap, size, title, cmap='viridis'):
    """Draw heatmap on the given axes."""
    masked_heatmap = np.ma.masked_invalid(heatmap)
    
    cmap_obj = plt.cm.get_cmap(cmap).copy()
    cmap_obj.set_bad(color='gray', alpha=0.5)
    
    im = ax.imshow(masked_heatmap, origin='upper', cmap=cmap_obj, 
                  aspect='auto', extent=[0, size, 0, size])
    
    ax.set_title(title, fontsize=11, fontweight='bold')
    ax.set_xlabel('X', fontsize=10)
    ax.set_ylabel('Y', fontsize=10)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)


def visualize_eigenvector_comprehensive(
    eig_vecs,  # Eigenvectors, shape (N, k_base)
    size: int,
    save_dir: str,
    prefix: str = "eigen_comprehensive",
    iteration: int = 0,
    max_eigenvectors_to_plot: int = 4,
    env=None,
    state_configs=None,
):
    """
    Comprehensive Laplacian eigenvector visualization.
    
    One figure per eigenvector with subplots per state configuration.
    
    Args:
        eig_vecs: Eigenvectors, shape (N, k_base) - Note: transposed layout
        size: Grid size
        save_dir: Directory to save figures
        prefix: Prefix for saved files
        iteration: Current iteration number
        max_eigenvectors_to_plot: Maximum number of eigenvectors to plot
        env: Optional KeyLockEnv instance for wall visualization
        state_configs: Optional list of state configs to visualize (if None, uses default 5 configs)
    """
    N, k_base = eig_vecs.shape
    
    # Default state configurations
    if state_configs is None:
        state_configs = [
            {
                "name": "Initial\n(no keys, doors closed)",
                "short_name": "Init",
                "yellow_door_open": 0,
                "blue_door_open": 0,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 1,
            },
            {
                "name": "Blue key collected\n(doors closed)",
                "short_name": "BlueKey",
                "yellow_door_open": 0,
                "blue_door_open": 0,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 0,
            },
            {
                "name": "Blue door open\n(blue key consumed)",
                "short_name": "BlueDoor",
                "yellow_door_open": 0,
                "blue_door_open": 1,
                "yellow_key_on_map": 1,
                "blue_key_on_map": 0,
            },
            {
                "name": "Yellow key collected\n(blue door open)",
                "short_name": "YellowKey",
                "yellow_door_open": 0,
                "blue_door_open": 1,
                "yellow_key_on_map": 0,
                "blue_key_on_map": 0,
            },
            {
                "name": "Both doors open\n(keys consumed)",
                "short_name": "Done",
                "yellow_door_open": 1,
                "blue_door_open": 1,
                "yellow_key_on_map": 0,
                "blue_key_on_map": 0,
            },
        ]
    
    num_configs = len(state_configs)
    num_to_plot = min(k_base, max_eigenvectors_to_plot)
    
    # Get wall positions if env is provided
    wall_positions = []
    if env is not None:
        wall_positions = get_wall_positions(env, size)
    
    # Visualize each eigenvector separately
    for eig_idx in range(num_to_plot):
        # Create a large figure for this eigenvector
        # Layout: 1 row × num_configs columns
        fig, axes = plt.subplots(1, num_configs, figsize=(4 * num_configs, 4))
        
        if num_configs == 1:
            axes = [axes]
        
        for config_idx, config in enumerate(state_configs):
            ax = axes[config_idx]
            heatmap = _create_heatmap(
                eig_vecs[:, eig_idx], size, config, wall_positions
            )
            _plot_heatmap(
                ax, heatmap, size,
                title=f"Eigenvector {eig_idx}\n{config['short_name']}",
                cmap='coolwarm'  # Use coolwarm for eigenvectors (can be positive/negative)
            )
        
        # Add overall title
        fig.suptitle(f'Laplacian eigenvector {eig_idx} - distribution', 
                     fontsize=14, fontweight='bold', y=0.98)
        
        plt.tight_layout()
        
        # Save figure
        os.makedirs(save_dir, exist_ok=True)
        filename = os.path.join(save_dir, f"{prefix}_vec{eig_idx}_iter{iteration:04d}.png")
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  [Viz] Saved {filename}")


def visualize_eigenvector_key_stages(
    eig_vecs,  # Eigenvectors, shape (N, k_base)
    size: int,
    save_dir: str,
    prefix: str = "eigen_key_stages",
    iteration: int = 0,
    max_eigenvectors_to_plot: int = 4,
    env=None,
):
    """
    Plot key stages only: initial, blue door open, completed.
    """
    key_configs = [
        {
            "name": "Initial\n(no keys, doors closed)",
            "short_name": "Init",
            "yellow_door_open": 0,
            "blue_door_open": 0,
            "yellow_key_on_map": 1,
            "blue_key_on_map": 1,
        },
        {
            "name": "Blue door open\n(key milestone)",
            "short_name": "BlueDoor",
            "yellow_door_open": 0,
            "blue_door_open": 1,
            "yellow_key_on_map": 1,
            "blue_key_on_map": 0,
        },
        {
            "name": "Both doors open\n(task complete)",
            "short_name": "Done",
            "yellow_door_open": 1,
            "blue_door_open": 1,
            "yellow_key_on_map": 0,
            "blue_key_on_map": 0,
        },
    ]
    
    visualize_eigenvector_comprehensive(
        eig_vecs, size, save_dir, prefix, iteration,
        max_eigenvectors_to_plot, env, state_configs=key_configs
    )


if __name__ == "__main__":
    # Example usage
    print("This module provides improved visualization functions for VPS options and Eigenvectors.")
    print("Import and use:")
    print("  from improved_vps_visualization import visualize_vps_option_comprehensive")
    print("  visualize_vps_option_comprehensive(V_base, phi_base, size, save_dir, ...)")
    print("  from improved_vps_visualization import visualize_eigenvector_comprehensive")
    print("  visualize_eigenvector_comprehensive(eig_vecs, size, save_dir, ...)")

