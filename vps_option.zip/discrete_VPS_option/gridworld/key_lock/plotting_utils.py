"""Shared KeyLock heatmap helpers (exact VPS + phase heatmaps)."""

from __future__ import annotations

import argparse
from math import ceil

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from .env import KeyLockEnv
from .state_codec import index_to_state, state_to_index
from .transitions import build_keylock_transition_matrix

OBJECT_STATE_LEVELS = [
    (0, 1),  # door closed, key still on map
    (0, 0),  # door closed, key not on map
    (1, 0),  # door open, key not on map
]


def parse_option_ids(text: str | None, total: int) -> list[int]:
    """Parse comma-separated ids/ranges like '0,2,4-6'."""
    if text is None or text.strip() == "":
        return list(range(total))

    option_ids: list[int] = []
    for part in text.split(","):
        token = part.strip()
        if not token:
            continue
        if "-" in token:
            start_str, end_str = token.split("-", 1)
            start = int(start_str.strip())
            end = int(end_str.strip())
            option_ids.extend(range(start, end + 1))
        else:
            option_ids.append(int(token))

    option_ids = sorted(set(option_ids))
    for opt_id in option_ids:
        if opt_id < 0 or opt_id >= total:
            raise ValueError(f"Option id {opt_id} is out of range [0, {total - 1}]")
    return option_ids


def get_wall_positions(env: KeyLockEnv, size: int) -> set[tuple[int, int]]:
    """Collect wall coordinates from the environment grid."""
    from minigrid.core.world_object import Wall

    walls: set[tuple[int, int]] = set()
    for x in range(size):
        for y in range(size):
            cell = env.grid.get(x, y)
            if cell is not None and isinstance(cell, Wall):
                walls.add((x, y))
    return walls


def build_reachable_state_set(env: KeyLockEnv, args: argparse.Namespace) -> set[int]:
    """Build the full-state reachable set from the deterministic transition matrix."""
    env.reset()
    _, _, reachable_states = build_keylock_transition_matrix(
        env,
        args.size,
        tuple(args.yellow_key_pos),
        tuple(args.yellow_door_pos),
        tuple(args.blue_key_pos),
        tuple(args.blue_door_pos),
        tuple(args.goal_pos),
    )
    return set(int(s) for s in reachable_states)


def enumerate_reachable_configs(reachable_states: set[int], size: int) -> list[dict]:
    """Enumerate all logically valid object-state configs and keep reachable ones."""
    reachable_tuples: dict[tuple[int, int, int, int], int] = {}
    for s in reachable_states:
        _, _, _, y_door, b_door, y_key, b_key = index_to_state(int(s), size)
        key = (y_door, b_door, y_key, b_key)
        reachable_tuples[key] = reachable_tuples.get(key, 0) + 1

    configs: list[dict] = []
    for yellow_door_open, yellow_key_on_map in OBJECT_STATE_LEVELS:
        for blue_door_open, blue_key_on_map in OBJECT_STATE_LEVELS:
            key = (yellow_door_open, blue_door_open, yellow_key_on_map, blue_key_on_map)
            count = reachable_tuples.get(key, 0)
            if count == 0:
                continue
            configs.append(
                {
                    "name": str(key),
                    "yellow_door_open": yellow_door_open,
                    "blue_door_open": blue_door_open,
                    "yellow_key_on_map": yellow_key_on_map,
                    "blue_key_on_map": blue_key_on_map,
                    "reachable_state_count": count,
                }
            )
    return configs


def aggregate_heatmap(
    feature: np.ndarray,
    size: int,
    config: dict,
    reachable_states: set[int],
    wall_positions: set[tuple[int, int]],
) -> np.ndarray:
    """Aggregate reachable directional states to a position heatmap."""
    heatmap = np.full((size, size), np.nan, dtype=np.float32)

    for x in range(size):
        for y in range(size):
            if (x, y) in wall_positions:
                continue

            vals: list[float] = []
            for direction in range(4):
                s = state_to_index(
                    x,
                    y,
                    direction,
                    config["yellow_door_open"],
                    config["blue_door_open"],
                    config["yellow_key_on_map"],
                    config["blue_key_on_map"],
                    size,
                )
                if s in reachable_states:
                    vals.append(float(feature[s]))

            if vals:
                heatmap[y, x] = float(np.mean(vals))

    return heatmap


def add_object_overlay(ax: plt.Axes, args: argparse.Namespace, config: dict) -> None:
    """Overlay the true object configuration on top of a heatmap."""
    yk = tuple(args.yellow_key_pos)
    yd = tuple(args.yellow_door_pos)
    bk = tuple(args.blue_key_pos)
    bd = tuple(args.blue_door_pos)
    goal = tuple(args.goal_pos)

    ax.scatter(goal[0], goal[1], marker="*", s=180, c="red", edgecolors="black", linewidths=0.8)

    if config["yellow_key_on_map"] == 1:
        ax.scatter(yk[0], yk[1], marker="P", s=120, c="gold", edgecolors="black", linewidths=0.8)
    else:
        ax.scatter(yk[0], yk[1], marker="x", s=90, c="goldenrod", linewidths=2.0)

    if config["blue_key_on_map"] == 1:
        ax.scatter(bk[0], bk[1], marker="P", s=120, c="deepskyblue", edgecolors="black", linewidths=0.8)
    else:
        ax.scatter(bk[0], bk[1], marker="x", s=90, c="royalblue", linewidths=2.0)

    yellow_face = "limegreen" if config["yellow_door_open"] == 1 else "gold"
    blue_face = "limegreen" if config["blue_door_open"] == 1 else "deepskyblue"
    yellow_alpha = 0.65 if config["yellow_door_open"] == 1 else 0.95
    blue_alpha = 0.65 if config["blue_door_open"] == 1 else 0.95

    ax.add_patch(
        Rectangle(
            (yd[0] - 0.38, yd[1] - 0.38),
            0.76,
            0.76,
            facecolor=yellow_face,
            edgecolor="black",
            linewidth=1.0,
            alpha=yellow_alpha,
        )
    )
    ax.add_patch(
        Rectangle(
            (bd[0] - 0.38, bd[1] - 0.38),
            0.76,
            0.76,
            facecolor=blue_face,
            edgecolor="black",
            linewidth=1.0,
            alpha=blue_alpha,
        )
    )


def add_shared_legend(fig: plt.Figure) -> None:
    """Add a single legend for object overlays."""
    handles = [
        Line2D(
            [0],
            [0],
            marker="P",
            color="w",
            markerfacecolor="gold",
            markeredgecolor="black",
            markersize=10,
            label="Yellow key present",
        ),
        Line2D(
            [0],
            [0],
            marker="x",
            color="goldenrod",
            linestyle="None",
            markersize=10,
            markeredgewidth=2,
            label="Yellow key absent",
        ),
        Line2D(
            [0],
            [0],
            marker="P",
            color="w",
            markerfacecolor="deepskyblue",
            markeredgecolor="black",
            markersize=10,
            label="Blue key present",
        ),
        Line2D(
            [0],
            [0],
            marker="x",
            color="royalblue",
            linestyle="None",
            markersize=10,
            markeredgewidth=2,
            label="Blue key absent",
        ),
        Rectangle((0, 0), 1, 1, facecolor="gold", edgecolor="black", label="Yellow door closed"),
        Rectangle((0, 0), 1, 1, facecolor="deepskyblue", edgecolor="black", label="Blue door closed"),
        Rectangle((0, 0), 1, 1, facecolor="limegreen", edgecolor="black", label="Door open"),
        Line2D(
            [0],
            [0],
            marker="*",
            color="w",
            markerfacecolor="red",
            markeredgecolor="black",
            markersize=12,
            label="Goal",
        ),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=4, fontsize=9, frameon=False)
