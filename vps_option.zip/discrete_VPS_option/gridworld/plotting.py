"""2D/3D heatmaps and policy-arrow plots for MiniGrid gridworld experiments."""

import os

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap, hsv_to_rgb

# Allow duplicate OpenMP runtimes when using some MKL builds.
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"


class GridworldHeatmapPlotter:
    """2D/3D heatmaps and policy arrows on MiniGrid layouts."""

    def __init__(self, env):
        self.env = env
        self.height = env.height
        self.width = env.width

    def decode_vector_to_matrix(self, vector: np.ndarray) -> np.ndarray:
        """Reshape a flat state vector to a 2D grid (walls → NaN)."""
        matrix = np.full((self.width, self.height), np.nan)
        for x in range(self.width):
            for y in range(self.height):
                if self.env.grid.get(x, y) is None:
                    matrix[x, y] = vector[x + y * self.width]
        return matrix

    def find_top_k_elements(self, data_matrix: np.ndarray, k: int):
        """Return coordinates of the k largest non-wall cells."""
        valid = np.where(~np.isnan(data_matrix), data_matrix, -np.inf)
        flat_idx = np.argpartition(valid.flatten(), -k)[-k:]
        indices = np.unravel_index(flat_idx, data_matrix.shape)
        return list(zip(indices[0], indices[1]))

    @staticmethod
    def _vivid_colors(k: int, seed: int = 0):
        if k == 0:
            return []
        rng = np.random.default_rng(seed)
        hues = rng.choice(np.linspace(0, 1, 360, endpoint=False), size=k, replace=False)
        return [tuple(hsv_to_rgb([h, 0.45, 1.0])) for h in hues]

    def plot_2d_heatmap(
        self,
        data_vector: np.ndarray,
        topk: int = 32,
        title: str = "2D Heatmap",
        color_bar: bool = True,
        rep_states=None,
        cmap_name: str = "hot",
    ):
        data_matrix = self.decode_vector_to_matrix(data_vector).astype(float)
        extent = [0, self.width, self.height, 0]

        if cmap_name == "auto":
            valid = data_matrix[data_matrix >= 0]
            k_clusters = int(np.nanmax(valid)) + 1 if valid.size else 0
            vivid = self._vivid_colors(k_clusters)
            color_list = [(0.0, 0.0, 0.0, 1.0)] + vivid
            cmap = ListedColormap(color_list)
            cmap.set_bad("gray")
            plot_mat = data_matrix + 1
            vmin, vmax = 0, max(k_clusters, 1)
            show_cbar = False
        else:
            cmap = plt.get_cmap(cmap_name)
            cmap.set_bad("gray")
            plot_mat = data_matrix
            vmin = vmax = None
            show_cbar = color_bar

        plt.figure(figsize=(8, 8))
        plt.imshow(
            plot_mat.T,
            cmap=cmap,
            origin="upper",
            interpolation="nearest",
            extent=extent,
            vmin=vmin,
            vmax=vmax,
        )
        if show_cbar:
            cbar = plt.colorbar(shrink=0.8)
            cbar.ax.tick_params(labelsize=18)

        plt.title(title, fontsize=20)
        plt.xticks(np.arange(0, self.width + 1))
        plt.yticks(np.arange(0, self.height + 1))
        plt.xlim(0, self.width)
        plt.ylim(self.height, 0)
        plt.grid(color="lightgray", linewidth=0.5)

        ax = plt.gca()
        ax.tick_params(axis="both", which="major", labelsize=18)

        if topk > 0:
            for x, y in self.find_top_k_elements(data_matrix, topk):
                ax.add_patch(
                    plt.Rectangle((x, y), 1, 1, edgecolor="blue", linewidth=2, fill=False)
                )

        if rep_states is not None:
            for idx in rep_states:
                row, col = divmod(idx, self.width)
                ax.add_patch(
                    plt.Rectangle((col, row), 1, 1, edgecolor="red", linewidth=4, fill=False)
                )

        ax.set_xticklabels([])
        ax.set_yticklabels([])
        plt.tight_layout()
        plt.show()

    def plot_policy_arrows(
        self,
        action_vector: np.ndarray,
        option_q_table: np.ndarray,
        title: str = "Optimal Policy Arrows",
    ):
        """Plot per-cell policy arrows; red dots mark option termination (max Q ≤ 0)."""
        action_to_delta = {0: (0, -0.3), 1: (0, 0.3), 2: (-0.3, 0), 3: (0.3, 0)}

        plt.figure(figsize=(8, 8))
        ax = plt.gca()
        ax.set_title(title, fontsize=20)
        ax.set_xlim(0, self.width)
        ax.set_ylim(0, self.height)
        ax.set_xticks(np.arange(0, self.width + 1))
        ax.set_yticks(np.arange(0, self.height + 1))
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.grid(True, color="lightgray", linewidth=0.5)
        ax.set_aspect("equal")

        for x in range(self.width):
            for y in range(self.height):
                if self.env.grid.get(x, y) is not None:
                    ax.add_patch(plt.Rectangle((x, y), 1, 1, color="gray"))

        for x in range(self.width):
            for y in range(self.height):
                idx = x + y * self.width
                if self.env.grid.get(x, y) is None:
                    if np.max(option_q_table[idx]) <= 0:
                        ax.plot(x + 0.5, y + 0.5, "ro", markersize=6)
                    else:
                        action = action_vector[idx]
                        dx, dy = action_to_delta.get(action, (0, 0))
                        ax.arrow(
                            x + 0.5,
                            y + 0.5,
                            dx,
                            dy,
                            head_width=0.15,
                            head_length=0.15,
                            fc="black",
                            ec="black",
                        )

        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.show()

    def display_3d_heatmap(self, data_vector, title="3D Heatmap"):
        data_matrix = self.decode_vector_to_matrix(data_vector)
        data_matrix = np.flipud(np.fliplr(data_matrix))

        x = np.arange(self.width)
        y = np.arange(self.height)
        x_grid, y_grid = np.meshgrid(x, y)
        z_grid = np.nan_to_num(data_matrix.T, nan=0)

        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection="3d")
        ax.plot_surface(x_grid, y_grid, z_grid, cmap="coolwarm", edgecolor="k")
        ax.set_title(title)
        ax.set_xlabel("X Position")
        ax.set_ylabel("Y Position")
        ax.set_zlabel("Value")
        plt.show()

    def compare_top_k_positions(self, vector1: np.ndarray, vector2: np.ndarray, topk: int) -> int:
        matrix1 = self.decode_vector_to_matrix(vector1)
        matrix2 = self.decode_vector_to_matrix(vector2)
        top_1 = set(self.find_top_k_elements(matrix1, topk))
        top_2 = set(self.find_top_k_elements(matrix2, topk))
        return len(top_1.intersection(top_2))


BottleneckVisualization = GridworldHeatmapPlotter

__all__ = ["GridworldHeatmapPlotter", "BottleneckVisualization"]
