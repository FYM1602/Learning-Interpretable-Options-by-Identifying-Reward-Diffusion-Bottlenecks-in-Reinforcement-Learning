"""Compatibility shim — use ``rooms.env.RoomsBottleneckEnv``."""

from .env import RoomsBottleneckEnv, SimpleEnv

__all__ = ["RoomsBottleneckEnv", "SimpleEnv"]
