#!/usr/bin/env python
"""Compute exact Value and VPS from xy-based RFF rewards in Rooms."""

from __future__ import annotations

import argparse
import json
import math
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

def build_arg_parser() -> argparse.ArgumentParser:
    """Create the command-line interface."""
    parser = argparse.ArgumentParser(
        description=(
            "Build the Rooms transition matrix, generate xy-based RFF rewards, "
            "solve exact Value functions, compute exact VPS, and save visualizations."
        )
    )
    parser.add_argument("--size", type=int, default=15, help="Grid size for the Rooms environment.")
    parser.add_argument("--num_rewards", type=int, default=8, help="Number of xy-based RFF rewards / VPS heads.")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor used in exact Value computation.")
    parser.add_argument("--rff_sigma", type=float, default=0.25, help="Frequency scale of the xy-based RFF rewards.")
    parser.add_argument("--seed", type=int, default=0, help="Random seed for RFF reward generation.")
    parser.add_argument("--dpi", type=int, default=200, help="DPI for saved figures.")
    parser.add_argument("--max_options_per_figure", type=int, default=4, help="Maximum heatmaps per saved figure.")
    parser.add_argument("--save_dir", default=None, help="Directory to save arrays and figures. Defaults to a timestamped run folder.")
    return parser


def import_rooms_modules():
    """Import Rooms environment helpers lazily so `--help` works without Minigrid."""
    try:
        from .env import RoomsBottleneckEnv
        from .transitions import build_state_transition_matrix
    except ImportError:  # pragma: no cover
        from .env import RoomsBottleneckEnv
        from .transitions import build_state_transition_matrix
    return RoomsBottleneckEnv, build_state_transition_matrix


def ensure_dir(path: str) -> str:
    """Create a directory if needed and return its absolute path."""
    abs_path = os.path.abspath(path)
    os.makedirs(abs_path, exist_ok=True)
    return abs_path


def sanitize_name(name: str) -> str:
    """Convert a string to a filesystem-friendly slug."""
    return str(name).replace("/", "_").replace("\\", "_").replace(":", "_")


def default_save_dir(args: argparse.Namespace) -> str:
    """Return a timestamped default output directory."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    root = os.path.join(script_dir, "exact_xy_rff_vps_results")
    run_name = (
        f"{time.strftime('%Y%m%d_%H%M%S')}__rooms_size{args.size}"
        f"__k{args.num_rewards}__gamma{str(args.gamma).replace('.', 'p')}"
    )
    return ensure_dir(os.path.join(root, sanitize_name(run_name)))


def build_valid_state_mappings(wall_mask: np.ndarray) -> tuple[np.ndarray, dict[int, int]]:
    """Build valid-state index mappings from a wall mask."""
    height, width = wall_mask.shape
    valid_states = [
        y * width + x
        for y in range(height)
        for x in range(width)
        if not bool(wall_mask[y, x])
    ]
    compressed_to_full = np.asarray(valid_states, dtype=np.int32)
    full_to_compressed = {int(full_idx): i for i, full_idx in enumerate(compressed_to_full)}
    return compressed_to_full, full_to_compressed


def state_xy_from_index(state_idx: int, width: int) -> np.ndarray:
    """Convert a flat state index into (x, y) coordinates."""
    x = int(state_idx % width)
    y = int(state_idx // width)
    return np.asarray([x, y], dtype=np.float64)


def build_uniform_random_walk_matrix(
    transition_matrix: np.ndarray,
    compressed_to_full: np.ndarray,
    full_to_compressed: dict[int, int],
) -> sp.csr_matrix:
    """Construct P_pi for a uniform random walk over primitive actions."""
    num_states = len(compressed_to_full)
    num_actions = transition_matrix.shape[1]
    prob = 1.0 / float(num_actions)

    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    for row_idx, full_idx in enumerate(compressed_to_full):
        for action in range(num_actions):
            next_full = int(transition_matrix[int(full_idx), action])
            col_idx = full_to_compressed[next_full]
            rows.append(row_idx)
            cols.append(col_idx)
            data.append(prob)
    return sp.csr_matrix((data, (rows, cols)), shape=(num_states, num_states), dtype=np.float64)


def generate_xy_rff_rewards(
    compressed_to_full: np.ndarray,
    width: int,
    num_rewards: int,
    sigma: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate one reward vector per RFF head from raw (x, y) coordinates."""
    coords = np.stack([state_xy_from_index(int(s), width) for s in compressed_to_full], axis=0)
    rng = np.random.default_rng(seed)
    weight = rng.standard_normal((num_rewards, 2)) * float(sigma)
    phase = rng.uniform(0.0, 2.0 * math.pi, size=(num_rewards,))
    scale = math.sqrt(2.0 / max(num_rewards, 1))
    rewards = scale * np.cos(coords @ weight.T + phase[None, :])
    rewards = rewards.T.astype(np.float64)

    reward_mean = rewards.mean(axis=1, keepdims=True)
    reward_std = np.maximum(rewards.std(axis=1, keepdims=True), 1e-6)
    normalized_rewards = (rewards - reward_mean) / reward_std
    return normalized_rewards.astype(np.float64), weight.astype(np.float64), phase.astype(np.float64)


def solve_exact_values(rewards: np.ndarray, p_pi: sp.csr_matrix, gamma: float) -> np.ndarray:
    """Solve (I - gamma P_pi) V = r for each reward head."""
    num_states = p_pi.shape[0]
    a_mat = sp.eye(num_states, format="csc", dtype=np.float64) - gamma * p_pi.tocsc()
    solver = spla.factorized(a_mat)
    values = np.zeros_like(rewards, dtype=np.float64)
    for idx in range(rewards.shape[0]):
        values[idx] = solver(rewards[idx])
    return values


def compute_exact_vps(
    values: np.ndarray,
    transition_matrix: np.ndarray,
    compressed_to_full: np.ndarray,
    full_to_compressed: dict[int, int],
) -> np.ndarray:
    """Compute exact VPS = E[(V(s') - V(s))^2 | s, a uniform]."""
    num_rewards = values.shape[0]
    num_actions = transition_matrix.shape[1]
    phi = np.zeros_like(values, dtype=np.float64)

    for state_idx, full_idx in enumerate(compressed_to_full):
        current_v = values[:, state_idx]
        accum = np.zeros(num_rewards, dtype=np.float64)
        for action in range(num_actions):
            next_full = int(transition_matrix[int(full_idx), action])
            next_idx = full_to_compressed[next_full]
            next_v = values[:, next_idx]
            diff = next_v - current_v
            accum += diff * diff
        phi[:, state_idx] = accum / float(num_actions)
    return phi


def expand_to_full(
    features: np.ndarray,
    compressed_to_full: np.ndarray,
    full_state_count: int,
) -> np.ndarray:
    """Expand compressed features (K, N_valid) to the full state space (K, N_full)."""
    full = np.zeros((features.shape[0], full_state_count), dtype=np.float64)
    for comp_idx, full_idx in enumerate(compressed_to_full):
        full[:, int(full_idx)] = features[:, comp_idx]
    return full


def vector_to_grid(
    vector: np.ndarray,
    width: int,
    height: int,
    wall_mask: np.ndarray,
) -> np.ndarray:
    """Reshape a flat feature vector into a grid, masking walls with NaN."""
    grid = np.full((height, width), np.nan, dtype=np.float64)
    for y in range(height):
        for x in range(width):
            if bool(wall_mask[y, x]):
                continue
            flat_idx = y * width + x
            grid[y, x] = float(vector[flat_idx])
    return grid


def render_feature_grids(
    features_full: np.ndarray,
    wall_mask: np.ndarray,
    width: int,
    height: int,
    feature_name: str,
    save_dir: str,
    dpi: int,
    max_options_per_figure: int,
) -> list[str]:
    """Render and save Value/VPS heatmaps."""
    save_dir = ensure_dir(save_dir)
    saved_paths: list[str] = []
    num_features = features_full.shape[0]

    for start in range(0, num_features, max_options_per_figure):
        stop = min(start + max_options_per_figure, num_features)
        chunk = features_full[start:stop]
        n_cols = min(2, chunk.shape[0])
        n_rows = int(math.ceil(chunk.shape[0] / n_cols))
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(6.0 * n_cols, 5.5 * n_rows))
        axes = np.atleast_1d(axes).ravel()

        for ax, feature_idx, vector in zip(axes, range(start, stop), chunk):
            grid = vector_to_grid(vector, width=width, height=height, wall_mask=wall_mask)
            image = ax.imshow(grid, cmap="viridis", origin="upper")
            ax.set_title(f"{feature_name} head {feature_idx}", fontsize=11)
            ax.set_xticks([])
            ax.set_yticks([])
            for y in range(height):
                for x in range(width):
                    if bool(wall_mask[y, x]):
                        ax.add_patch(plt.Rectangle((x - 0.5, y - 0.5), 1, 1, facecolor="black", edgecolor="white", linewidth=0.5))
            cbar = fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
            cbar.set_label(feature_name, fontsize=10)

        for ax in axes[chunk.shape[0]:]:
            ax.axis("off")

        fig.suptitle(
            f"Exact {feature_name} from xy-RFF rewards under uniform random walk",
            fontsize=13,
        )
        fig.tight_layout(rect=(0, 0.02, 1, 0.94))
        path = os.path.join(save_dir, f"{feature_name.lower()}_{start:02d}_{stop - 1:02d}.png")
        fig.savefig(path, dpi=dpi, bbox_inches="tight")
        plt.close(fig)
        saved_paths.append(path)
    return saved_paths


def main() -> None:
    """Compute exact Value/VPS from xy-based RFF rewards and save results."""
    args = build_arg_parser().parse_args()
    RoomsBottleneckEnv, build_state_transition_matrix = import_rooms_modules()
    save_dir = ensure_dir(args.save_dir) if args.save_dir else default_save_dir(args)

    env = RoomsBottleneckEnv(size=args.size, render_mode=None)
    env.reset()
    transition_matrix, wall_mask = build_state_transition_matrix(env, agent_start_pos=env.agent_start_pos)
    width, height = env.width, env.height
    env.close()

    compressed_to_full, full_to_compressed = build_valid_state_mappings(wall_mask)
    p_pi = build_uniform_random_walk_matrix(transition_matrix, compressed_to_full, full_to_compressed)
    rewards, weight, phase = generate_xy_rff_rewards(
        compressed_to_full=compressed_to_full,
        width=width,
        num_rewards=args.num_rewards,
        sigma=args.rff_sigma,
        seed=args.seed,
    )
    values = solve_exact_values(rewards, p_pi, gamma=args.gamma)
    vps = compute_exact_vps(values, transition_matrix, compressed_to_full, full_to_compressed)

    full_state_count = width * height
    rewards_full = expand_to_full(rewards, compressed_to_full, full_state_count)
    values_full = expand_to_full(values, compressed_to_full, full_state_count)
    vps_full = expand_to_full(vps, compressed_to_full, full_state_count)

    np.savez_compressed(
        os.path.join(save_dir, "exact_xy_rff_vps_artifacts.npz"),
        transition_matrix=transition_matrix.astype(np.int32),
        wall_mask=wall_mask.astype(bool),
        compressed_to_full=compressed_to_full.astype(np.int32),
        p_pi_data=p_pi.data.astype(np.float64),
        p_pi_indices=p_pi.indices.astype(np.int32),
        p_pi_indptr=p_pi.indptr.astype(np.int32),
        rewards=rewards.astype(np.float32),
        rewards_full=rewards_full.astype(np.float32),
        values=values.astype(np.float32),
        values_full=values_full.astype(np.float32),
        vps=vps.astype(np.float32),
        vps_full=vps_full.astype(np.float32),
        rff_weight=weight.astype(np.float32),
        rff_phase=phase.astype(np.float32),
        gamma=np.asarray(args.gamma, dtype=np.float32),
        rff_sigma=np.asarray(args.rff_sigma, dtype=np.float32),
        seed=np.asarray(args.seed, dtype=np.int32),
        size=np.asarray(args.size, dtype=np.int32),
    )

    value_paths = render_feature_grids(
        features_full=values_full,
        wall_mask=wall_mask,
        width=width,
        height=height,
        feature_name="Value",
        save_dir=os.path.join(save_dir, "value_heatmaps"),
        dpi=args.dpi,
        max_options_per_figure=args.max_options_per_figure,
    )
    vps_paths = render_feature_grids(
        features_full=vps_full,
        wall_mask=wall_mask,
        width=width,
        height=height,
        feature_name="VPS",
        save_dir=os.path.join(save_dir, "vps_heatmaps"),
        dpi=args.dpi,
        max_options_per_figure=args.max_options_per_figure,
    )

    with open(os.path.join(save_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(
            {
                "size": int(args.size),
                "num_rewards": int(args.num_rewards),
                "gamma": float(args.gamma),
                "rff_sigma": float(args.rff_sigma),
                "seed": int(args.seed),
                "save_dir": save_dir,
                "value_heatmaps": [os.path.abspath(p) for p in value_paths],
                "vps_heatmaps": [os.path.abspath(p) for p in vps_paths],
            },
            f,
            indent=2,
            sort_keys=True,
        )

    print(f"[Save] Exact xy-RFF Value/VPS results written to {save_dir}")


if __name__ == "__main__":
    main()
