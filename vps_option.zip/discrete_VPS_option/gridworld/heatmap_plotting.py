"""Compatibility shim — use ``gridworld.plotting.GridworldHeatmapPlotter``."""

from .plotting import BottleneckVisualization, GridworldHeatmapPlotter

__all__ = ["GridworldHeatmapPlotter", "BottleneckVisualization"]
