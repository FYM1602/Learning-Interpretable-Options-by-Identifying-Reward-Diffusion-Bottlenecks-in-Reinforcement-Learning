"""
CLI: ``python -m gridworld keylock ...`` or ``python -m gridworld rooms ...``

Run from ``discrete_VPS_option`` (parent of the ``gridworld`` package).
"""

from __future__ import annotations

import argparse
import sys


def _keylock_train(argv: list[str] | None) -> None:
    from .key_lock.train_options import main

    old = sys.argv
    try:
        sys.argv = ["keylock-train", *(argv or [])]
        main()
    finally:
        sys.argv = old


def _keylock_exact(argv: list[str] | None) -> None:
    from .key_lock.exact_vps import main

    old = sys.argv
    try:
        sys.argv = ["keylock-exact", *(argv or [])]
        main()
    finally:
        sys.argv = old


def _keylock_plot(argv: list[str] | None) -> None:
    from .key_lock.figures import main

    main(argv)


def _keylock_viz(argv: list[str] | None) -> None:
    from .key_lock.visualize_learned import main

    main(argv)


def _rooms_train(argv: list[str] | None) -> None:
    from .rooms.train_options import main

    old = sys.argv
    try:
        sys.argv = ["rooms-train", *(argv or [])]
        main()
    finally:
        sys.argv = old


def _rooms_exact(argv: list[str] | None) -> None:
    from .rooms.exact_vps import main

    old = sys.argv
    try:
        sys.argv = ["rooms-exact", *(argv or [])]
        main()
    finally:
        sys.argv = old


def _rooms_compare(argv: list[str] | None) -> None:
    from .rooms.compare_centrality import main

    old = sys.argv
    try:
        sys.argv = ["rooms-compare", *(argv or [])]
        main()
    finally:
        sys.argv = old


def _rooms_centrality(argv: list[str] | None) -> None:
    from .rooms.centrality import main

    old = sys.argv
    try:
        sys.argv = ["rooms-centrality", *(argv or [])]
        main()
    finally:
        sys.argv = old


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gridworld",
        description="Tabular VPS / options on MiniGrid KeyLock and Rooms",
    )
    sub = parser.add_subparsers(dest="env", metavar="ENV", required=True)

    kl = sub.add_parser("keylock", help="Yellow/blue key–door environment")
    kl_sub = kl.add_subparsers(dest="cmd", metavar="CMD", required=True)
    kl_sub.add_parser("train", help="Train Random / Eigen / VPS tabular options")
    kl_sub.add_parser("exact", help="Exact V, VPS, and Laplacian eigenvectors under uniform RW")
    kl_sub.add_parser("plot", help="Paper figures: phase-heatmaps, boxplot, coverage")
    kl_sub.add_parser("viz", help="Trained models: fields helpers, rollout demo")

    rm = sub.add_parser("rooms", help="Corridor bottleneck layout")
    rm_sub = rm.add_subparsers(dest="cmd", metavar="CMD", required=True)
    rm_sub.add_parser("train", help="Train tabular options")
    rm_sub.add_parser("exact", help="Exact V/VPS from xy-based RFF rewards")
    rm_sub.add_parser("compare", help="VPS vs centrality / connectivity")
    rm_sub.add_parser("centrality", help="Compute centrality baselines only")

    return parser


def main(argv: list[str] | None = None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        build_parser().print_help()
        return

    env_name = argv[0]
    if env_name not in ("keylock", "rooms"):
        build_parser().print_help()
        return

    if len(argv) < 2:
        build_parser().parse_args([env_name, "--help"])
        return

    cmd = argv[1]
    rest = argv[2:]

    if env_name == "keylock":
        dispatch = {
            "train": _keylock_train,
            "exact": _keylock_exact,
            "plot": _keylock_plot,
            "viz": _keylock_viz,
        }
    else:
        dispatch = {
            "train": _rooms_train,
            "exact": _rooms_exact,
            "compare": _rooms_compare,
            "centrality": _rooms_centrality,
        }

    if cmd not in dispatch:
        build_parser().parse_args(argv[:2] + ["--help"])
        return
    dispatch[cmd](rest)


if __name__ == "__main__":
    main()
