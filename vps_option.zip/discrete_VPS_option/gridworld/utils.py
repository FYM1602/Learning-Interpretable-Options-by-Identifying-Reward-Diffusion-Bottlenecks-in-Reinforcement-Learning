"""Compatibility shim — use ``gridworld.plotting``."""

from .plotting import BottleneckVisualization, GridworldHeatmapPlotter

__all__ = ["GridworldHeatmapPlotter", "BottleneckVisualization"]
