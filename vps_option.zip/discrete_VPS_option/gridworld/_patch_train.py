"""One-off patch script for key_lock refactor — not an experiment entry point."""
from __future__ import annotations

import sys

if __name__ == "__main__":
    raise SystemExit(
        "gridworld/_patch_train.py is a one-off migration utility. "
        "Use: python -m gridworld keylock train ..."
    )

from pathlib import Path

KL = Path(__file__).parent / "key_lock"
src = KL / "key_lock_options.py"
if not src.exists():
    src = KL / "train_options.py"

lines = src.read_text(encoding="utf-8").splitlines(keepends=True)
idx = next(i for i, l in enumerate(lines) if l.startswith("# ---------- phase-0"))

# Extract state_codec block (lines 14..idx-1, 0-based: 13..idx-1)
codec_lines = lines[13:idx]
codec_header = '''"""KeyLock state index encoding and env reset helpers."""
import numpy as np

'''
(KL / "state_codec.py").write_text(codec_header + "".join(codec_lines), encoding="utf-8")

header = '''#!/usr/bin/env python
"""Train Random / Eigen / VPS tabular options on KeyLock."""

import os, argparse, random, collections, ast
import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt

from .env import KeyLockEnv
from .state_codec import (
    state_to_index,
    index_to_state,
    reset_env_to_state,
    get_wall_positions,
    visualize_feature_distribution,
)

'''
new = header + "".join(lines[idx:])
new = new.replace(
    "from generate_keylock_transition_matrix import build_keylock_transition_matrix",
    "from .transitions import build_keylock_transition_matrix",
)
(KL / "train_options.py").write_text(new, encoding="utf-8")
print("OK: state_codec.py + train_options.py")
