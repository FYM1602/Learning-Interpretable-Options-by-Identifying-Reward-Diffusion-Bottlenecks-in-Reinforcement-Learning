# -*- coding: utf-8 -*-
"""Finish gridworld package refactor — one-off migration utility, not for experiments."""
from __future__ import annotations

import sys

if __name__ == "__main__":
    raise SystemExit(
        "gridworld/_finish_refactor.py is a one-off migration utility. "
        "Use: python -m gridworld keylock train ..."
    )

import re
from pathlib import Path

ROOT = Path(__file__).parent
KL = ROOT / "key_lock"
RM = ROOT / "rooms"

OLD_KL = [
    "key_lock_env.py",
    "generate_keylock_transition_matrix.py",
    "key_lock_options.py",
    "compute_exact_random_walk_vps.py",
    "plot_keylock_vps_phase_heatmaps.py",
    "keylock_option_random_walk.py",
    "keylock_option_termination_coverage_curves.py",
    "improved_vps_visualization.py",
    "keylock_option_visualization.py",
]

OLD_RM = [
    "gridworld_options.py",
    "compute_exact_xy_rff_vps.py",
    "vps_distribution_visualization.py",
    "brandes_centrality.py",
    "generate_state_transition_matrix.py",
    "bottleneck_env.py",
    "rooms_env.py",
]


def patch_file(path: Path, replacements: list[tuple[str, str]]) -> None:
    text = path.read_text(encoding="utf-8")
    orig = text
    for old, new in replacements:
        text = text.replace(old, new)
    if text != orig:
        path.write_text(text, encoding="utf-8")
        print(f"patched {path.name}")


# --- key_lock import fixes ---
kl_common = [
    ("from generate_keylock_transition_matrix import build_keylock_transition_matrix", "from .transitions import build_keylock_transition_matrix"),
    ("from key_lock_env import KeyLockEnv", "from .env import KeyLockEnv"),
    ("from key_lock_options import index_to_state, state_to_index", "from .state_codec import index_to_state, state_to_index"),
    ("from key_lock_options import state_to_index", "from .state_codec import state_to_index"),
    ("from key_lock_options import (\n    state_to_index,\n    get_wall_positions,\n)", "from .state_codec import state_to_index, get_wall_positions"),
    ("import key_lock_options as klo", "from . import train_options as klo"),
    ("    from key_lock_env import KeyLockEnv", "    from .env import KeyLockEnv"),
    ("from plot_keylock_vps_phase_heatmaps import (", "from .plotting_utils import ("),
]

patch_file(KL / "transitions.py", [("from key_lock_env import KeyLockEnv", "from .env import KeyLockEnv")])

for name in [
    "transitions.py",
    "exact_vps.py",
    "plot_phase_heatmaps.py",
    "plot_boxplot.py",
    "plot_coverage.py",
    "viz_fields.py",
    "viz_rollout.py",
]:
    p = KL / name
    if p.exists():
        patch_file(p, kl_common)

# exact_vps: remove duplicate import lines if plot_keylock was partially fixed
patch_file(
    KL / "exact_vps.py",
    [
        (
            "from .plotting_utils import (\n    add_object_overlay,\n    aggregate_heatmap,\n    enumerate_reachable_configs,\n    get_wall_positions,\n    parse_option_ids,\n)",
            "from .plotting_utils import (\n    add_object_overlay,\n    aggregate_heatmap,\n    enumerate_reachable_configs,\n    get_wall_positions,\n    parse_option_ids,\n)",
        ),
    ],
)

# plot_phase_heatmaps: use plotting_utils for shared helpers
pph = KL / "plot_phase_heatmaps.py"
if pph.exists():
    text = pph.read_text(encoding="utf-8")
    if "from .plotting_utils import" not in text:
        text = text.replace(
            "from .state_codec import index_to_state, state_to_index\n",
            "from .state_codec import index_to_state, state_to_index\n"
            "from .plotting_utils import (\n"
            "    add_object_overlay,\n"
            "    add_shared_legend,\n"
            "    aggregate_heatmap,\n"
            "    build_reachable_state_set,\n"
            "    enumerate_reachable_configs,\n"
            "    get_wall_positions,\n"
            "    parse_option_ids,\n"
            "    OBJECT_STATE_LEVELS,\n"
            ")\n",
        )
        # Drop duplicate helper definitions (parse_option_ids through add_shared_legend)
        start = text.find("\n\ndef parse_option_ids")
        end = text.find("\n\ndef plot_option(")
        if start != -1 and end != -1:
            text = text[:start] + "\n\n" + text[end + 2 :]
        pph.write_text(text, encoding="utf-8")
        print("trimmed plot_phase_heatmaps helpers")

# --- rooms ---
rm_common = [
    ("from .rooms_env import RoomsBottleneckEnv", "from .env import RoomsBottleneckEnv"),
    ("from .generate_state_transition_matrix import build_state_transition_matrix", "from .transitions import build_state_transition_matrix"),
    ("from . import brandes_centrality as bc", "from . import centrality as bc"),
    ("from ..heatmap_plotting import GridworldHeatmapPlotter", "from ..plotting import GridworldHeatmapPlotter"),
]
for name in ["train_options.py", "exact_vps.py", "centrality.py", "compare_centrality.py"]:
    p = RM / name
    if p.exists():
        patch_file(p, rm_common)

patch_file(
    RM / "exact_vps.py",
    [
        (
            "        from .rooms_env import RoomsBottleneckEnv\n        from .generate_state_transition_matrix import build_state_transition_matrix",
            "        from .env import RoomsBottleneckEnv\n        from .transitions import build_state_transition_matrix",
        ),
        (
            "        from rooms_env import RoomsBottleneckEnv\n        from generate_state_transition_matrix import build_state_transition_matrix",
            "        from .env import RoomsBottleneckEnv\n        from .transitions import build_state_transition_matrix",
        ),
    ],
)

# rooms_env shim
(RM / "rooms_env.py").write_text(
    '"""Compatibility shim — use ``rooms.env.RoomsBottleneckEnv``."""\n'
    "from .env import RoomsBottleneckEnv, SimpleEnv\n\n"
    '__all__ = ["RoomsBottleneckEnv", "SimpleEnv"]\n',
    encoding="utf-8",
)

# heatmap_plotting shim -> plotting
hp = ROOT / "heatmap_plotting.py"
if hp.exists():
    hp.write_text(
        '"""Compatibility shim — use ``gridworld.plotting.GridworldHeatmapPlotter``."""\n\n'
        "from .plotting import BottleneckVisualization, GridworldHeatmapPlotter\n\n"
        '__all__ = ["GridworldHeatmapPlotter", "BottleneckVisualization"]\n',
        encoding="utf-8",
    )
    print("heatmap_plotting shim")

utils = ROOT / "utils.py"
if utils.exists():
    utils.write_text(
        '"""Compatibility shim — use ``gridworld.plotting``."""\n\n'
        "from .plotting import BottleneckVisualization, GridworldHeatmapPlotter\n\n"
        '__all__ = ["GridworldHeatmapPlotter", "BottleneckVisualization"]\n',
        encoding="utf-8",
    )

# transitions.py rooms - check import of env
rt = RM / "transitions.py"
if rt.exists():
    t = rt.read_text(encoding="utf-8")
    if "RoomsBottleneckEnv" not in t and "def build_state" in t:
        pass
    if "from .env import" not in t and "RoomsBottleneckEnv" in t:
        patch_file(rt, [("from rooms_env import", "from .env import"), ("from bottleneck_env import", "from .env import")])

# delete old scripts
for name in OLD_KL + OLD_RM:
    for base in (KL, RM):
        p = base / name
        if p.exists():
            p.unlink()
            print(f"deleted {p}")

# delete patch scripts
for name in ("_patch_train.py", "_finish_refactor.py"):
    p = ROOT / name
    if p.exists() and name == "_finish_refactor.py":
        pass  # delete self at end

print("done")
