"""Neural networks for image-based VPS option discovery.

Components
----------
- ``NatureDQNCNN``: Nature-DQN-style encoder for 84x84 frame stacks.
- ``RandomFourierRewardLayer``: fixed random Fourier features for probe rewards.
- ``MultiHeadValueNetwork`` / ``MultiHeadVPSNetwork``: k-headed value and VPS predictors.
- ``OptionQNetwork``: per-option DQN Q-head over discrete actions.
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class NatureDQNCNN(nn.Module):
    """Encode stacked frames (C, 84, 84) into a flat feature vector."""

    def __init__(self, input_channels: int = 4):
        super().__init__()
        self.conv_stack = nn.Sequential(
            nn.Conv2d(input_channels, 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
            nn.Flatten(),
        )
        with torch.no_grad():
            dummy = torch.zeros(1, input_channels, 84, 84)
            self.feature_dim = int(self.conv_stack(dummy).shape[1])

    def forward(self, frames: Tensor) -> Tensor:
        return self.conv_stack(frames)


class RandomFourierRewardLayer(nn.Module):
    """Fixed random Fourier map: r(h) = scale * cos(W h + b)."""

    def __init__(self, input_dim: int, num_probes: int, sigma: float = 1.0, seed: int = 0):
        super().__init__()
        generator = torch.Generator(device="cpu")
        generator.manual_seed(seed)
        weights = torch.randn(num_probes, input_dim, generator=generator) * sigma
        biases = torch.rand(num_probes, generator=generator) * (2.0 * math.pi)
        self.register_buffer("weights", weights)
        self.register_buffer("biases", biases)
        self.scale = 1.0

    @torch.no_grad()
    def forward(self, features: Tensor) -> Tensor:
        return self.scale * torch.cos(F.linear(features, self.weights, self.biases))


class MLPFeatureHead(nn.Module):
    """Three-layer MLP: feature_dim -> 512 -> 256 -> num_outputs."""

    def __init__(self, input_dim: int, num_outputs: int):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_outputs)
        for layer in (self.fc1, self.fc2, self.fc3):
            nn.init.kaiming_normal_(layer.weight, nonlinearity="relu")
            nn.init.zeros_(layer.bias)

    def forward(self, features: Tensor) -> Tensor:
        hidden = F.relu(self.fc1(features))
        hidden = F.relu(self.fc2(hidden))
        return self.fc3(hidden)


class MultiHeadValueNetwork(nn.Module):
    """Predict k random-reward value functions V_i(s) from frame stacks."""

    def __init__(self, num_heads: int, encoder: NatureDQNCNN):
        super().__init__()
        self.encoder = encoder
        self.head = MLPFeatureHead(encoder.feature_dim, num_heads)

    def forward(self, frames: Tensor) -> Tensor:
        return self.head(self.encoder(frames))


class MultiHeadVPSNetwork(nn.Module):
    """Predict k VPS potentials phi_i(s) from frame stacks."""

    def __init__(self, num_heads: int, encoder: NatureDQNCNN):
        super().__init__()
        self.encoder = encoder
        self.head = MLPFeatureHead(encoder.feature_dim, num_heads)

    def forward(self, frames: Tensor) -> Tensor:
        return self.head(self.encoder(frames))


class OptionQNetwork(nn.Module):
    """Q(s, a) head for one discrete option policy."""

    def __init__(self, feature_dim: int, num_actions: int):
        super().__init__()
        self.q_network = nn.Sequential(
            nn.Linear(feature_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, num_actions),
        )
        for module in self.q_network:
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                nn.init.zeros_(module.bias)

    def forward(self, features: Tensor) -> Tensor:
        return self.q_network(features)


# Backward-compatible aliases for older scripts importing the previous names.
AtariCNN = NatureDQNCNN
RFFLayer = RandomFourierRewardLayer
ValueNet = MultiHeadValueNetwork
VPSNet = MultiHeadVPSNetwork
DQNHead = OptionQNetwork
_DeepHead = MLPFeatureHead
