"""Atari VPS training pipeline: env wrappers, buffer, preprocessing, trainer, checkpoints."""

from __future__ import annotations

import collections
import datetime as dt
import os
from typing import Any

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter

from .models import (
    MultiHeadValueNetwork,
    MultiHeadVPSNetwork,
    NatureDQNCNN,
    OptionQNetwork,
    RandomFourierRewardLayer,
)

# ---------------------------------------------------------------------------
# Supported ALE environments
# ---------------------------------------------------------------------------

ALE_GAMES: dict[str, str] = {
    "montezuma": "ALE/MontezumaRevenge-v5",
    "venture": "ALE/Venture-v5",
    "pong": "ALE/Pong-v5",
    "solaris": "ALE/Solaris-v5",
    "freeway": "ALE/Freeway-v5",
    "gravitar": "ALE/Gravitar-v5",
    "adventure": "ALE/Adventure-v5",
    "private": "ALE/PrivateEye-v5",
    "pitfall": "ALE/Pitfall-v5",
    "breakout": "ALE/Breakout-v5",
    "pacman": "ALE/MsPacman-v5",
}

_LEGACY_CHECKPOINT_KEYS = {
    "num_options": "k",
    "frame_stack_length": "frame_stack_len",
    "shared_value_vps_encoder": "backbone_val",
    "rff_encoder": "backbone_rff",
    "rff_layer": "rff",
    "random_reward_mean": "rand_reward_norm_mean",
    "random_reward_std": "rand_reward_norm_std",
    "option_policy_encoder": "backbone_q",
    "option_q_heads": "opt_heads",
}


# ---------------------------------------------------------------------------
# Checkpoints
# ---------------------------------------------------------------------------


def load_training_checkpoint(path: str, map_location: str | torch.device = "cpu") -> dict[str, Any]:
    checkpoint = torch.load(path, map_location=map_location)
    if not isinstance(checkpoint, dict):
        raise TypeError(f"Expected a state dict mapping, got {type(checkpoint)!r}")
    normalized = dict(checkpoint)
    for canonical, legacy in _LEGACY_CHECKPOINT_KEYS.items():
        if canonical not in normalized and legacy in checkpoint:
            normalized[canonical] = checkpoint[legacy]
    if "shared_value_vps_encoder" not in normalized and "backbone_vps" in checkpoint:
        normalized["shared_value_vps_encoder"] = checkpoint["backbone_vps"]
    return normalized


# ---------------------------------------------------------------------------
# Frame preprocessing
# ---------------------------------------------------------------------------


def rgb_to_gray_84(rgb: np.ndarray, device: torch.device) -> torch.Tensor:
    import cv2

    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    gray = cv2.resize(gray, (84, 84), interpolation=cv2.INTER_AREA)
    return torch.as_tensor(gray, device=device, dtype=torch.float32).unsqueeze(0) / 255.0


class FrameStackPreprocessor:
    def __init__(self, frame_stack_length: int, device: str | torch.device = "cpu"):
        self.frame_stack_length = int(frame_stack_length)
        self.device = torch.device(device)
        self._stack: collections.deque[torch.Tensor] | None = None

    def reset(self) -> None:
        self._stack = None

    @torch.no_grad()
    def push_frame(self, frame_1chw: torch.Tensor) -> torch.Tensor:
        if self._stack is None:
            self._stack = collections.deque(maxlen=self.frame_stack_length)
            for _ in range(self.frame_stack_length):
                self._stack.append(frame_1chw.clone())
        else:
            self._stack.append(frame_1chw)
        return torch.cat(list(self._stack), dim=0)

    @torch.no_grad()
    def obs_to_state(self, rgb: np.ndarray) -> torch.Tensor:
        return self.push_frame(rgb_to_gray_84(rgb, self.device))


# ---------------------------------------------------------------------------
# Replay buffer
# ---------------------------------------------------------------------------


class FrameReplayBuffer:
    def __init__(
        self,
        capacity: int,
        storage_devices: str | list[str] = "cuda:0",
        target_device: str | torch.device = "cuda:0",
        frame_stack_length: int = 1,
    ):
        self.capacity = int(capacity)
        self.is_full = False
        self.write_index = 0
        self.target_device = torch.device(target_device)
        self.frame_stack_length = int(frame_stack_length)

        if isinstance(storage_devices, str):
            self.storage_devices = [storage_devices]
        else:
            self.storage_devices = list(storage_devices)
        self.num_shards = len(self.storage_devices)
        self.shard_capacity = self.capacity // self.num_shards

        self.frame_buffers: list[torch.Tensor] = []
        self.env_reward_buffers: list[torch.Tensor] = []
        self.action_buffers: list[torch.Tensor] = []
        self.done_buffers: list[torch.Tensor] = []
        self.random_reward_buffers: list[torch.Tensor] | None = None
        self.random_reward_dim: int | None = None

        for device in self.storage_devices:
            self.frame_buffers.append(
                torch.zeros((self.shard_capacity, 1, 84, 84), dtype=torch.uint8, device=device)
            )
            self.env_reward_buffers.append(torch.zeros((self.shard_capacity, 1), device=device))
            self.action_buffers.append(torch.zeros((self.shard_capacity, 1), dtype=torch.int64, device=device))
            self.done_buffers.append(torch.zeros((self.shard_capacity, 1), dtype=torch.uint8, device=device))

    @property
    def full(self) -> bool:
        return self.is_full

    def _shard_id(self, global_index: int) -> int:
        return global_index // self.shard_capacity

    def _local_index(self, global_index: int) -> int:
        return global_index % self.shard_capacity

    def size(self) -> int:
        return self.capacity if self.is_full else self.write_index

    @torch.no_grad()
    def normalize_random_rewards_(self, eps: float = 1e-6) -> tuple[torch.Tensor, torch.Tensor]:
        if self.random_reward_buffers is None or self.random_reward_dim is None:
            raise RuntimeError("random_reward_buffers not initialized; call store() first.")
        buffer_size = int(self.size())
        if buffer_size <= 0:
            raise RuntimeError("buffer is empty; cannot normalize.")
        rewards = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.random_reward_buffers],
            dim=0,
        )[:buffer_size]
        mean = rewards.mean(dim=0)
        std = torch.sqrt(rewards.var(dim=0, unbiased=False)).clamp_min(eps)
        for shard in self.random_reward_buffers:
            device = shard.device
            shard.sub_(mean.to(device)).div_(std.to(device))
        return mean.detach().cpu(), std.detach().cpu()

    @torch.no_grad()
    def store(
        self,
        frame: np.ndarray,
        action: int,
        env_reward: float,
        random_reward_vector: np.ndarray | None,
        is_terminal: int,
    ) -> None:
        if self.random_reward_dim is None:
            if random_reward_vector is None:
                self.random_reward_dim = 1
                random_reward_vector = np.zeros(1, dtype=np.float32)
            else:
                self.random_reward_dim = int(np.asarray(random_reward_vector).size)
            self.random_reward_buffers = []
            for device in self.storage_devices:
                self.random_reward_buffers.append(
                    torch.zeros(
                        (self.shard_capacity, self.random_reward_dim),
                        dtype=torch.float32,
                        device=device,
                    )
                )
        if random_reward_vector is None:
            random_reward_vector = np.zeros(self.random_reward_dim, dtype=np.float32)
        else:
            random_reward_vector = np.asarray(random_reward_vector, dtype=np.float32).reshape(-1)
        if frame.dtype != np.uint8:
            frame = (frame * 255).astype(np.uint8)
        shard_id = self._shard_id(self.write_index)
        local_index = self._local_index(self.write_index)
        device = self.storage_devices[shard_id]
        self.frame_buffers[shard_id][local_index] = torch.from_numpy(frame).to(device, non_blocking=True)
        self.action_buffers[shard_id][local_index] = int(action)
        self.env_reward_buffers[shard_id][local_index] = float(env_reward)
        self.random_reward_buffers[shard_id][local_index] = torch.from_numpy(random_reward_vector).to(device)
        self.done_buffers[shard_id][local_index] = int(is_terminal)
        self.is_full = self.is_full or (self.write_index + 1 >= self.capacity)
        self.write_index = (self.write_index + 1) % self.capacity

    @torch.no_grad()
    def sample_batch(self, batch_size: int):
        history_tail = self.frame_stack_length - 1
        buffer_size = self.size()
        assert buffer_size >= history_tail + 2, "buffer too small"
        frames = torch.cat([shard.to(self.target_device, non_blocking=True) for shard in self.frame_buffers], dim=0)
        env_rewards = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.env_reward_buffers], dim=0
        )
        random_rewards = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.random_reward_buffers], dim=0
        )
        actions = torch.cat([shard.to(self.target_device, non_blocking=True) for shard in self.action_buffers], dim=0)
        dones = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.done_buffers], dim=0
        ).squeeze(1)
        history_offsets = torch.arange(history_tail, -1, -1, device=self.target_device)
        candidate_indices = torch.randint(history_tail, buffer_size - 1, (batch_size * 2,), device=self.target_device)
        valid_mask = (dones[candidate_indices.unsqueeze(1) - history_offsets[:-1]].sum(dim=1) == 0)
        indices = candidate_indices[valid_mask][:batch_size]
        while indices.numel() < batch_size:
            extra = torch.randint(history_tail, buffer_size - 1, (batch_size // 2,), device=self.target_device)
            indices = torch.cat([indices, extra[(dones[extra.unsqueeze(1) - history_offsets[:-1]].sum(dim=1) == 0)]])[
                :batch_size
            ]
        frame_indices = indices.unsqueeze(1) - history_offsets
        next_frame_indices = frame_indices + 1
        states = frames[frame_indices].squeeze(2).float().div_(255.0)
        next_states = frames[next_frame_indices].squeeze(2).float().div_(255.0)
        return (
            states,
            next_states,
            actions[indices].long(),
            env_rewards[indices],
            random_rewards[indices],
            dones[indices].unsqueeze(1),
        )

    @torch.no_grad()
    def sample_nstep_batch(self, batch_size: int, n_step: int):
        assert n_step >= 2
        history_tail = self.frame_stack_length - 1
        buffer_size = self.size()
        assert buffer_size >= history_tail + n_step, "buffer too small"
        frames = torch.cat([shard.to(self.target_device, non_blocking=True) for shard in self.frame_buffers], dim=0)
        env_rewards = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.env_reward_buffers], dim=0
        )
        random_rewards = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.random_reward_buffers], dim=0
        )
        actions = torch.cat([shard.to(self.target_device, non_blocking=True) for shard in self.action_buffers], dim=0)
        dones = torch.cat(
            [shard.to(self.target_device, non_blocking=True) for shard in self.done_buffers], dim=0
        ).squeeze(1)
        history_offsets = torch.arange(history_tail, -1, -1, device=self.target_device)
        step_offsets = torch.arange(0, n_step, device=self.target_device)
        interior_offsets = torch.arange(0, n_step - 2, device=self.target_device)
        candidate_indices = torch.randint(history_tail, buffer_size - n_step, (batch_size * 2,), device=self.target_device)

        def is_valid(index_row: torch.Tensor) -> torch.Tensor:
            ok_history = (dones[index_row.unsqueeze(1) - history_offsets[:-1]].sum(dim=1) == 0)
            if n_step <= 2:
                return ok_history
            return ok_history & (dones[index_row.unsqueeze(1) + interior_offsets].sum(dim=1) == 0)

        indices = candidate_indices[is_valid(candidate_indices)][:batch_size]
        while indices.numel() < batch_size:
            extra = torch.randint(history_tail, buffer_size - n_step, (batch_size // 2,), device=self.target_device)
            indices = torch.cat([indices, extra[is_valid(extra)]])[:batch_size]
        base_indices = indices.unsqueeze(1) + step_offsets
        frame_indices = base_indices.unsqueeze(2) - history_offsets
        terminal_frame_indices = (indices + n_step).unsqueeze(1) - history_offsets
        return (
            frames[frame_indices].squeeze(3).float().div_(255.0).contiguous(),
            actions[base_indices].long(),
            env_rewards[base_indices],
            random_rewards[base_indices],
            dones[base_indices].unsqueeze(-1),
            frames[terminal_frame_indices].squeeze(2).float().div_(255.0).contiguous(),
        )


# ---------------------------------------------------------------------------
# Environment wrapper
# ---------------------------------------------------------------------------


class MaxAndSkipWrapper(gym.Wrapper):
    def __init__(self, env: gym.Env, skip: int = 4):
        super().__init__(env)
        if skip < 1:
            raise ValueError(f"skip must be >= 1, got {skip}")
        self.skip = int(skip)
        self._obs_buffer: np.ndarray | None = None

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self._obs_buffer = np.zeros((2,) + obs.shape, dtype=obs.dtype)
        self._obs_buffer[0] = obs
        self._obs_buffer[1] = obs
        return obs, info

    def step(self, action):
        total_reward = 0.0
        terminated = False
        truncated = False
        info: dict = {}
        obs = None
        for i in range(self.skip):
            obs, reward, terminated, truncated, info = self.env.step(action)
            if i == self.skip - 2:
                self._obs_buffer[0] = obs
            if i == self.skip - 1:
                self._obs_buffer[1] = obs
            total_reward += float(reward)
            if terminated or truncated:
                break
        if obs is not None and self._obs_buffer is not None:
            if self.skip == 1:
                self._obs_buffer[0] = obs
                self._obs_buffer[1] = obs
            elif i < self.skip - 2:
                self._obs_buffer[0] = obs
                self._obs_buffer[1] = obs
            elif i == self.skip - 2:
                self._obs_buffer[1] = obs
        return np.maximum(self._obs_buffer[0], self._obs_buffer[1]), total_reward, terminated, truncated, info


# ---------------------------------------------------------------------------
# Three-stage VPS trainer
# ---------------------------------------------------------------------------


def _env_name(env: gym.Env) -> str:
    return getattr(getattr(env, "spec", None), "id", env.__class__.__name__)


class VPSOptionTrainer:
    """Stages: (A) RFF value, (B) VPS on squared TD of V, (C) option DQN with φ intrinsic reward."""

    def __init__(
        self,
        env: gym.Env,
        k_options: int = 8,
        gamma_v: float = 0.99,
        gamma_q: float = 0.9,
        device: str = "cuda:0",
        buffer_cap: int = 200_000,
        frame_stack_len: int = 4,
        batch_size: int = 64,
        max_episode_length: int = 500,
        n_step: int = 10,
    ):
        self.env = env
        self.k = k_options
        self.dev = torch.device(device)
        self.g_v = gamma_v
        self.g_q = gamma_q
        self.F = frame_stack_len
        self.B = batch_size
        self.max_episode_length = max_episode_length
        self.n_step = n_step

        eid = _env_name(env)
        logdir = os.path.join("runs", eid.split("/")[0], dt.datetime.now().strftime("%Y%m%d-%H%M%S"))
        self.writer = SummaryWriter(logdir)

        self.backbone_rff = NatureDQNCNN(in_channels=self.F).to(self.dev)
        for param in self.backbone_rff.parameters():
            param.requires_grad_(False)
        self.rff = RandomFourierRewardLayer(self.backbone_rff.feature_dim, k_options, seed=0, sigma=10).to(self.dev)
        self.rand_reward_mean: torch.Tensor | None = None
        self.rand_reward_std: torch.Tensor | None = None

        self.backbone_shared = NatureDQNCNN(in_channels=self.F).to(self.dev)
        self.backbone_val = self.backbone_shared
        self.backbone_vps = self.backbone_shared
        self.val_net = MultiHeadValueNetwork(k_options, self.backbone_val).to(self.dev)
        self.vps_net = MultiHeadVPSNetwork(k_options, self.backbone_vps).to(self.dev)

        self.backbone_q = NatureDQNCNN(in_channels=frame_stack_len).to(self.dev)
        n_act = env.action_space.n
        self.opt_heads = nn.ModuleList(
            [OptionQNetwork(self.backbone_q.feature_dim, n_act).to(self.dev) for _ in range(k_options)]
        )

        self.value_opt = torch.optim.Adam(
            list(self.backbone_val.parameters()) + list(self.val_net.head.parameters()), lr=1e-3
        )
        self.vps_opt = torch.optim.Adam(list(self.vps_net.head.parameters()), lr=1e-4)
        self.q_opt = torch.optim.Adam(
            list(self.backbone_q.parameters()) + [p for h in self.opt_heads for p in h.parameters()], lr=1e-4
        )
        self.buffer = FrameReplayBuffer(
            capacity=buffer_cap,
            storage_devices="cuda",
            target_device=self.dev,
            frame_stack_length=self.F,
        )
        self.frame_preprocessor = FrameStackPreprocessor(self.F, self.dev)
        self.step_A = self.step_B = self.step_C = 0

    def reset_frame_stack(self) -> None:
        self.frame_preprocessor.reset()

    @torch.no_grad()
    def obs_to_state(self, obs: np.ndarray) -> torch.Tensor:
        return self.frame_preprocessor.obs_to_state(obs)

    @torch.no_grad()
    def collect(self) -> None:
        while not self.buffer.full:
            obs, _ = self.env.reset()
            self.frame_preprocessor.reset()
            frame = rgb_to_gray_84(obs, self.dev)
            _ = self.frame_preprocessor.push_frame(frame)
            for _ in range(self.max_episode_length):
                action = self.env.action_space.sample()
                nxt_obs, reward, term, trunc, _ = self.env.step(action)
                nxt_frame = rgb_to_gray_84(nxt_obs, self.dev)
                sp_stack = self.frame_preprocessor.push_frame(nxt_frame)
                r_rand_vec = self.rff(self.backbone_rff(sp_stack.unsqueeze(0)))[0].detach().cpu().numpy()
                self.buffer.store(frame.cpu().numpy(), action, reward, r_rand_vec, int(term or trunc))
                frame = nxt_frame
                if term or trunc:
                    self.buffer.store(frame.cpu().numpy(), 0, 0.0, np.zeros(self.k, dtype=np.float32), int(term or trunc))
                    break
        self.rand_reward_mean, self.rand_reward_std = self.buffer.normalize_random_rewards_()
        print(
            f"[Collect] rand reward normalized: "
            f"mean(abs)={float(self.rand_reward_mean.abs().mean()):.4f}, "
            f"std(mean)={float(self.rand_reward_std.mean()):.4f}"
        )

    def train_value(self):
        if self.buffer.size() < self.B:
            return None
        state, next_state, _, _, r_rand, done = self.buffer.sample_batch(self.B)
        v_s = self.val_net.head(self.backbone_val(state))
        with torch.no_grad():
            v_sp = self.val_net.head(self.backbone_val(next_state))
            target = r_rand + self.g_v * (1 - done.float()) * v_sp
        loss = F.smooth_l1_loss(v_s, target)
        self.value_opt.zero_grad()
        loss.backward()
        self.value_opt.step()
        self.writer.add_scalar("A/value_loss", loss.item(), self.step_A)
        self.step_A += 1
        return float(loss.item())

    def freeze_value(self) -> None:
        for param in self.backbone_val.parameters():
            param.requires_grad_(False)
        for param in self.val_net.head.parameters():
            param.requires_grad_(False)

    def train_vps(self):
        if self.buffer.size() < self.B:
            return None
        state, next_state, _, _, done = self.buffer.sample_batch(self.B)
        with torch.no_grad():
            v_s = self.val_net.head(self.backbone_val(state))
            v_sp = self.val_net.head(self.backbone_val(next_state))
            target = ((1 - done.float()) * v_sp - v_s) ** 2
        phi_s = self.vps_net.head(self.backbone_vps(state))
        loss = F.smooth_l1_loss(phi_s, target)
        self.vps_opt.zero_grad()
        loss.backward()
        self.vps_opt.step()
        self.writer.add_scalar("B/vps_loss", loss.item(), self.step_B)
        self.step_B += 1
        return float(loss.item())

    def freeze_vps(self) -> None:
        for param in self.backbone_vps.parameters():
            param.requires_grad_(False)
        for param in self.vps_net.head.parameters():
            param.requires_grad_(False)

    def _gamma_vec(self, n_step: int, device: torch.device) -> torch.Tensor:
        if getattr(self, "_cached_n", None) != n_step:
            self._cached_gamma = self.g_q ** torch.arange(n_step, device=device)
            self._cached_n = n_step
        return self._cached_gamma

    def train_options(self):
        if self.buffer.size() < self.B:
            return None
        state_seq, action_seq, _, _, done_seq, terminal_state = self.buffer.sample_nstep_batch(self.B, self.n_step)
        state0 = state_seq[:, 0]
        action0 = action_seq[:, 0, 0].long()
        done_last = done_seq[:, -1, 0].float()
        with torch.no_grad():
            batch_n = self.B * self.n_step
            phi_seq = self.vps_net.head(
                self.backbone_vps(state_seq.reshape(batch_n, *state_seq.shape[2:]))
            ).view(self.B, self.n_step, self.k)
            phi_sn = self.vps_net.head(self.backbone_vps(terminal_state))
        r_int_seq = torch.zeros_like(phi_seq)
        r_int_seq[:, :-1] = phi_seq[:, 1:] - phi_seq[:, :-1]
        r_int_seq[:, -1] = phi_sn - phi_seq[:, -1]
        gamma_vec = self._gamma_vec(self.n_step, device=self.dev)
        g_int = (r_int_seq * gamma_vec.view(1, self.n_step, 1)).sum(dim=1)
        feat_s = self.backbone_q(state0)
        feat_sn = self.backbone_q(terminal_state).detach()
        total = 0.0
        for i, head in enumerate(self.opt_heads):
            q = head(feat_s).gather(1, action0.unsqueeze(1)).squeeze(1)
            q_next = head(feat_sn).max(1)[0]
            target = g_int[:, i] + (self.g_q**self.n_step) * (1 - done_last) * q_next
            total += F.mse_loss(q, target)
        self.q_opt.zero_grad()
        total.backward()
        self.q_opt.step()
        self.writer.add_scalar("C/option_q_loss", total.item(), self.step_C)
        self.step_C += 1
        return float(total.item())

    def train(
        self,
        value_iters: int = 10_000,
        vps_iters: int = 10_000,
        option_iters: int = 10_000,
        print_every: int = 50,
    ) -> None:
        print("[Collect]")
        self.collect()
        print("[Stage-A] Value")
        for _ in range(value_iters):
            loss = self.train_value()
            if loss is not None and print_every > 0 and (self.step_A % print_every == 0):
                print(f"[Stage-A] iter={self.step_A:>7d}/{value_iters}  loss={loss:.6f}")
        self.freeze_value()
        print("[Stage-B] VPS")
        for _ in range(vps_iters):
            loss = self.train_vps()
            if loss is not None and print_every > 0 and (self.step_B % print_every == 0):
                print(f"[Stage-B] iter={self.step_B:>7d}/{vps_iters}  loss={loss:.6f}")
        self.freeze_vps()
        print("[Stage-C] Options")
        for _ in range(option_iters):
            loss = self.train_options()
            if loss is not None and print_every > 0 and (self.step_C % print_every == 0):
                print(f"[Stage-C] iter={self.step_C:>7d}/{option_iters}  loss={loss:.6f}")

    def save_all(self, path: str) -> None:
        torch.save(
            {
                "num_options": self.k,
                "frame_stack_length": self.F,
                "shared_value_vps_encoder": self.backbone_val.state_dict(),
                "value_head": self.val_net.head.state_dict(),
                "vps_head": self.vps_net.head.state_dict(),
                "rff_encoder": self.backbone_rff.state_dict(),
                "rff_layer": self.rff.state_dict(),
                "rff_scale": self.rff.scale,
                "random_reward_mean": self.rand_reward_mean,
                "random_reward_std": self.rand_reward_std,
                "option_policy_encoder": self.backbone_q.state_dict(),
                "option_q_heads": [h.state_dict() for h in self.opt_heads],
            },
            path,
        )
        print(f"[✓] saved → {path}")


ContinuousVPSAgent = VPSOptionTrainer
MaxAndSkipEnv = MaxAndSkipWrapper
Memory = FrameReplayBuffer
