# Atari VPS

Train multi-head VPS on Atari, then mark **local maxima** of Σᵢ φᵢ(s) along a **human-played** trajectory.

## Layout (3 modules)

| File | Contents |
|------|----------|
| `models.py` | Nature-DQN CNN, RFF layer, value/VPS/Q heads |
| `pipeline.py` | Buffer, preprocessing, env wrapper, `VPSOptionTrainer`, checkpoint I/O |
| `__main__.py` | CLI: `train` and `annotate` subcommands |

## Usage

From the repository root (`vps_option_discovery`):

```bash
# 1) Train (writes <game>/outputs/networks.pt)
python -m atari_vps train --game freeway --buffer_size 50000 \
  --value_iters 20000 --vps_iters 20000 --option_iters 0

# 2) Manual play + peak frames (keyboard; needs pygame)
python -m atari_vps annotate --ckpt freeway/outputs/networks.pt --env freeway --manual
```

Outputs (unchanged from the original scripts):

- Checkpoint: `{game}/outputs/networks.pt`
- Curve: `vps_sum_curve/{env}/vps_sum_curve.png`
- Peaks: `vps_sum_curve/{env}/peaks/peak*.png`

**Dependencies:** `gymnasium[atari]`, `ale-py`, PyTorch, OpenCV; `pygame` for manual control.

## Pipeline

1. **train** — random-walk buffer → RFF value functions → VPS (squared TD of V) → optional per-option DQN.
2. **annotate** — load VPS only; record human trajectory; windowed argmax on Σφ; save plot and peak frames.

For peak labeling only, `--option_iters 0` is enough.
