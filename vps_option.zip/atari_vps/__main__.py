"""
CLI: ``python -m atari_vps train ...`` or ``python -m atari_vps annotate ...``

Run from the parent package directory (``vps_option_discovery``).
"""

from __future__ import annotations

import argparse
import os
import time
import warnings
from pathlib import Path

import gymnasium as gym
import imageio.v2 as imageio
import matplotlib.pyplot as plt
import numpy as np
import torch

from .models import MultiHeadVPSNetwork, NatureDQNCNN
from .pipeline import (
    ALE_GAMES,
    FrameStackPreprocessor,
    MaxAndSkipWrapper,
    VPSOptionTrainer,
    load_training_checkpoint,
)

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
warnings.filterwarnings("ignore", category=UserWarning)

try:
    import pygame

    _HAS_PYGAME = True
except ImportError:
    _HAS_PYGAME = False


def _add_train_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--game", type=str, default="freeway", choices=ALE_GAMES.keys())
    parser.add_argument("--buffer_size", type=int, default=100_000)
    parser.add_argument("--value_iters", type=int, default=500_000)
    parser.add_argument("--vps_iters", type=int, default=500_000)
    parser.add_argument("--option_iters", type=int, default=500_000)
    parser.add_argument("--num_options", type=int, default=8)
    parser.add_argument("--frame_stack", type=int, default=4)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--frame_skip", type=int, default=4)


def _add_annotate_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--ckpt", default="./freeway/outputs/networks.pt")
    parser.add_argument("--env", choices=ALE_GAMES.keys(), default="freeway")
    parser.add_argument("--steps", type=int, default=1000)
    parser.add_argument("--win", type=int, default=100)
    parser.add_argument("--out", default="vps_sum_curve")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--manual", action="store_true", default=True)
    parser.add_argument("--fps_print", type=int, default=200)
    parser.add_argument("--ylim", type=float, default=20)


def run_train(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Train VPS / option networks on Atari")
    _add_train_args(parser)
    args = parser.parse_args(argv)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device}")

    env_id = ALE_GAMES[args.game.lower()]
    save_dir = os.path.join(args.game.lower(), "outputs")
    os.makedirs(save_dir, exist_ok=True)

    env = MaxAndSkipWrapper(gym.make(env_id), skip=args.frame_skip)
    agent = VPSOptionTrainer(
        env,
        k_options=args.num_options,
        gamma_v=0.99,
        gamma_q=0.9,
        device=device,
        buffer_cap=args.buffer_size,
        frame_stack_len=args.frame_stack,
        batch_size=args.batch_size,
        max_episode_length=500,
    )
    agent.train(
        value_iters=args.value_iters,
        vps_iters=args.vps_iters,
        option_iters=args.option_iters,
        print_every=50,
    )
    checkpoint_path = os.path.join(save_dir, "networks.pt")
    agent.save_all(checkpoint_path)
    env.close()
    print(f"Training done. Checkpoint: {checkpoint_path}")
    print("Next: python -m atari_vps annotate --ckpt", checkpoint_path, "--env", args.game)


def _keyboard_poll():
    key_to_action = {
        pygame.K_k: 0,
        pygame.K_SPACE: 1,
        pygame.K_f: 1,
        pygame.K_UP: 2,
        pygame.K_RIGHT: 3,
        pygame.K_LEFT: 4,
        pygame.K_DOWN: 5,
        "LEFT+FIRE": 15,
        "RIGHT+FIRE": 14,
        "UP+FIRE": 12,
    }

    def poll() -> int | None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_SPACE] or pressed[pygame.K_f]:
            if pressed[pygame.K_LEFT]:
                return key_to_action["LEFT+FIRE"]
            if pressed[pygame.K_RIGHT]:
                return key_to_action["RIGHT+FIRE"]
            if pressed[pygame.K_UP]:
                return key_to_action["UP+FIRE"]
            return 1
        if pressed[pygame.K_LEFT]:
            return 4
        if pressed[pygame.K_RIGHT]:
            return 3
        if pressed[pygame.K_UP]:
            return 2
        if pressed[pygame.K_DOWN]:
            return 5
        if pressed[pygame.K_k]:
            return 0
        return 0

    return poll


def run_annotate(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Annotate VPS local peaks on a human trajectory")
    _add_annotate_args(parser)
    args = parser.parse_args(argv)

    if args.manual and not _HAS_PYGAME:
        raise RuntimeError("Install pygame to use --manual")

    env_id = ALE_GAMES[args.env]
    out_dir = Path(args.out) / args.env
    peak_dir = out_dir / "peaks"
    peak_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)

    ckpt = load_training_checkpoint(args.ckpt, map_location=device)
    k_opt = int(ckpt["num_options"])
    stack_len = int(ckpt["frame_stack_length"])

    backbone = NatureDQNCNN(in_channels=stack_len).to(device).eval()
    backbone.load_state_dict(ckpt["shared_value_vps_encoder"])
    vps_net = MultiHeadVPSNetwork(k_opt, backbone).to(device).eval()
    vps_net.head.load_state_dict(ckpt["vps_head"])

    frame_stack = FrameStackPreprocessor(stack_len, device)
    env_rgb = gym.make(env_id, render_mode="rgb_array", frameskip=3, repeat_action_probability=0.0)
    env_vis = gym.make(env_id, render_mode="human", frameskip=3, repeat_action_probability=0.0)
    env_rgb.reset()
    env_vis.reset()
    frame_stack.reset()

    poll = None
    if args.manual:
        pygame.init()
        poll = _keyboard_poll()

    frames_rgb: list[np.ndarray] = []
    states: list[torch.Tensor] = []
    t0 = time.time()

    for t in range(args.steps):
        rgb = env_rgb.render()
        frames_rgb.append(rgb.copy())
        with torch.no_grad():
            states.append(frame_stack.obs_to_state(rgb).unsqueeze(0))

        act = poll() if args.manual else env_rgb.action_space.sample()
        if act is None:
            print("[Quit]")
            break
        if act >= env_rgb.action_space.n:
            print(f"[Warn] action {act} out of range → NO-OP")
            act = 0

        _, _, term, trunc, _ = env_rgb.step(act)
        env_vis.step(act)
        if term or trunc:
            env_rgb.reset()
            env_vis.reset()
            frame_stack.reset()

        if (t + 1) % args.fps_print == 0:
            fps = (t + 1) / (time.time() - t0 + 1e-9)
            print(f"[Progress] {t + 1}/{args.steps}  {fps:6.1f} FPS")

    env_rgb.close()
    env_vis.close()
    if args.manual:
        pygame.quit()

    trajectory_length = len(frames_rgb)
    print("[Info] Sampling finished:", trajectory_length, "frames")

    with torch.no_grad():
        vps_sum = vps_net(torch.cat(states).to(device)).cpu().numpy().sum(1)

    win = max(1, args.win)
    peaks: list[tuple[int, float]] = []
    for s in range(0, trajectory_length, win):
        seg = vps_sum[s : s + win]
        i = s + int(seg.argmax())
        peaks.append((i, float(vps_sum[i])))

    fig = plt.figure(figsize=(10, 4))
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(vps_sum, color="#CC3333")
    ax.set_ylim(0, args.ylim)
    ax.set_xlabel("Steps")
    ax.set_ylabel("Total VPS of 8 Options")
    ax.set_title(env_id)

    overflow: list[tuple[int, int, float]] = []
    for n, (i, v) in enumerate(peaks):
        if v <= args.ylim:
            ax.scatter(i, v, c="#FF9900")
            ax.text(i, v, f"{n}", fontsize=12, ha="right", va="bottom")
        else:
            overflow.append((n, i, v))

    if overflow:
        ax2 = fig.add_axes([0.72, 0.6, 0.25, 0.2])
        ax2.plot(vps_sum, color="#CC3333")
        ax2.set_title("Overflow Peaks", fontsize=10)
        for n, i, v in overflow:
            ax2.scatter(i, v, c="#FF9900")
            ax2.text(i, v, f"{n}", fontsize=10, ha="right", va="bottom")

    out_dir.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(out_dir / "vps_sum_curve.png")
    plt.show()

    print("[Info] Saving peak frames …")
    for n, (i, score) in enumerate(peaks):
        for off in range(4):
            if i + off >= trajectory_length:
                break
            fn = peak_dir / f"peak{n:02d}_frame{off}_{score:+.4f}.png"
            imageio.imwrite(fn, frames_rgb[i + off])
    print("[✓] Done  →", peak_dir.resolve())


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Atari VPS: train networks or annotate trajectory peaks",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    train_parser = sub.add_parser("train", help="Train Value → VPS → Option Q")
    _add_train_args(train_parser)
    annotate_parser = sub.add_parser("annotate", help="Manual play + VPS peak export")
    _add_annotate_args(annotate_parser)
    args = parser.parse_args()
    if args.command == "train":
        run_train()
    else:
        run_annotate()


if __name__ == "__main__":
    main()
