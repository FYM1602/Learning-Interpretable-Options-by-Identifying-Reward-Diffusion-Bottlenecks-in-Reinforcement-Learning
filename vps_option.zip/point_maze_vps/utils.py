from __future__ import annotations

import json
import os
import random
from typing import Any

import gymnasium as gym
import numpy as np
import torch

_ALLOWED_MAZE_TOKENS = {0, 1, "r", "g", "c"}
CUSTOM_POINTMAZE_ENV_ID = "custom"
DEFAULT_CUSTOM_POINTMAZE_BACKEND = "PointMaze_UMaze-v3"


def register_robotics_envs() -> None:
    """Register Gymnasium-Robotics envs if the package is available."""
    try:
        import gymnasium_robotics
    except ImportError as exc:  # pragma: no cover - exercised only when dependency is missing
        raise ImportError(
            "gymnasium-robotics is required for PointMaze. "
            "Install the updated requirements.txt first."
        ) from exc
    gym.register_envs(gymnasium_robotics)


def set_global_seed(seed: int) -> None:
    """Seed Python, NumPy, and PyTorch RNGs."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _normalize_maze_cell(cell: Any) -> int | str:
    """Normalize one maze cell token into the PointMaze format."""
    if isinstance(cell, str):
        token = cell.strip().lower()
        if token in {"0", "1"}:
            return int(token)
        if token in {"r", "g", "c"}:
            return token
    elif isinstance(cell, (int, np.integer)):
        token = int(cell)
        if token in {0, 1}:
            return token
    raise ValueError(
        "Invalid maze cell value "
        f"{cell!r}. Allowed tokens are 0, 1, 'r', 'g', and 'c'."
    )


def validate_maze_map(maze_map: Any) -> list[list[int | str]]:
    """Validate and normalize a PointMaze maze map."""
    if not isinstance(maze_map, list) or not maze_map:
        raise ValueError("maze_map must be a non-empty 2D JSON array.")

    normalized: list[list[int | str]] = []
    expected_width: int | None = None
    num_free_cells = 0
    for row_idx, row in enumerate(maze_map):
        if not isinstance(row, list) or not row:
            raise ValueError(f"maze_map row {row_idx} must be a non-empty JSON array.")
        normalized_row = [_normalize_maze_cell(cell) for cell in row]
        if expected_width is None:
            expected_width = len(normalized_row)
        elif len(normalized_row) != expected_width:
            raise ValueError(
                "maze_map must be rectangular, but row "
                f"{row_idx} has width {len(normalized_row)} instead of {expected_width}."
            )
        num_free_cells += sum(1 for cell in normalized_row if cell != 1)
        normalized.append(normalized_row)

    if num_free_cells == 0:
        raise ValueError("maze_map must contain at least one non-wall cell.")

    invalid = {cell for row in normalized for cell in row if cell not in _ALLOWED_MAZE_TOKENS}
    if invalid:
        raise ValueError(f"maze_map contains unsupported tokens: {sorted(invalid)!r}")
    return normalized


def load_maze_map_json(path: str) -> list[list[int | str]]:
    """Load a PointMaze maze map from JSON.

    Supported JSON layouts:
    1. A top-level 2D array, e.g. `[[1, 1], [1, 0]]`
    2. An object with a `maze_map` field.
    """
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    maze_map = payload.get("maze_map") if isinstance(payload, dict) else payload
    if maze_map is None:
        raise ValueError(f"JSON file {path!r} does not contain a 'maze_map' field.")
    return validate_maze_map(maze_map)


def maybe_to_maze_map(value: Any) -> list[list[int | str]] | None:
    """Convert optional serialized maze data back into a normalized maze map."""
    if value is None:
        return None
    if isinstance(value, np.ndarray):
        if value.dtype == object and value.shape == ():
            item = value.item()
            if item is None:
                return None
            value = item
        else:
            value = value.tolist()
    return validate_maze_map(value)


def resolve_pointmaze_env_selection(
    env_id: str | None,
    maze_json: str | None,
) -> tuple[str, str | None, list[list[int | str]] | None, bool]:
    """Resolve the user-facing env selector into a backend env id and optional custom maze."""
    requested_env_id = str(env_id or "").strip() or CUSTOM_POINTMAZE_ENV_ID
    if requested_env_id.lower() == CUSTOM_POINTMAZE_ENV_ID:
        if maze_json is None or not str(maze_json).strip():
            raise ValueError("`--env_id custom` requires a valid `--maze_json` path.")
        resolved_maze_json = os.path.abspath(str(maze_json))
        maze_map = load_maze_map_json(resolved_maze_json)
        return DEFAULT_CUSTOM_POINTMAZE_BACKEND, resolved_maze_json, maze_map, True
    return requested_env_id, None, None, False


def make_pointmaze_env(
    env_id: str,
    seed: int | None = None,
    render_mode: str | None = None,
    max_episode_steps: int | None = None,
    extra_kwargs: dict[str, Any] | None = None,
) -> gym.Env:
    """Construct a PointMaze environment with robotics envs registered."""
    register_robotics_envs()
    kwargs: dict[str, Any] = {}
    if render_mode is not None:
        kwargs["render_mode"] = render_mode
    if max_episode_steps is not None:
        kwargs["max_episode_steps"] = int(max_episode_steps)
    if extra_kwargs:
        kwargs.update(extra_kwargs)
    env = gym.make(env_id, **kwargs)
    if seed is not None:
        env.reset(seed=seed)
        env.action_space.seed(seed)
        env.observation_space.seed(seed)
    return env


class PointMazeObsOnlyWrapper(gym.ObservationWrapper):
    """Expose only the 4-D continuous state needed by the VPS model."""

    def __init__(self, env: gym.Env):
        super().__init__(env)
        base_space = env.observation_space["observation"]
        self.observation_space = gym.spaces.Box(
            low=np.asarray(base_space.low, dtype=np.float32),
            high=np.asarray(base_space.high, dtype=np.float32),
            shape=base_space.shape,
            dtype=np.float32,
        )

    def observation(self, observation):
        return np.asarray(observation["observation"], dtype=np.float32)


def default_results_dir(script_file: str) -> str:
    """Return the default result directory next to the training script."""
    script_dir = os.path.dirname(os.path.abspath(script_file))
    return os.path.join(script_dir, "point_maze_vps_results")


def ensure_dir(path: str) -> str:
    """Create the directory if needed and return the absolute path."""
    abs_path = os.path.abspath(path)
    os.makedirs(abs_path, exist_ok=True)
    return abs_path


def save_json(path: str, payload: dict[str, Any]) -> None:
    """Write a JSON file with stable formatting."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)


# Ordered four-waypoint downstream task: (4,2) -> (6,4) -> (4,6) -> (2,4); +1 per waypoint, max 4.
NUM_ORDERED_WAYPOINTS = 4
MAX_WAYPOINT_EPISODE_REWARD = 4
DEFAULT_WAYPOINT_CELLS: tuple[tuple[int, int], ...] = ((4, 2), (6, 4), (4, 6), (2, 4))
DEFAULT_WAYPOINT_CELLS_FLAT: list[int] = [4, 2, 6, 4, 4, 6, 2, 4]


def normalize_waypoint_cells(cells: object) -> list[tuple[int, int]]:
    """Normalize waypoint cells to exactly four ordered `(row, col)` pairs."""
    if cells is None:
        normalized = [tuple(v) for v in DEFAULT_WAYPOINT_CELLS]
    elif isinstance(cells, np.ndarray):
        cells = cells.tolist()
        normalized = _parse_waypoint_cell_spec(cells)
    else:
        normalized = _parse_waypoint_cell_spec(cells)

    if len(normalized) != NUM_ORDERED_WAYPOINTS:
        raise ValueError(
            f"Expected exactly {NUM_ORDERED_WAYPOINTS} ordered waypoints "
            f"(sparse reward +1 each, episode cap {MAX_WAYPOINT_EPISODE_REWARD}), "
            f"got {len(normalized)}: {normalized!r}"
        )
    return normalized


def _parse_waypoint_cell_spec(cells: object) -> list[tuple[int, int]]:
    if isinstance(cells, (list, tuple)) and cells and isinstance(cells[0], (list, tuple)):
        normalized = [(int(pair[0]), int(pair[1])) for pair in cells]
    elif isinstance(cells, (list, tuple)):
        flat = [int(v) for v in cells]
        if len(flat) % 2 != 0 or len(flat) == 0:
            raise ValueError(
                "`waypoint_cells` must contain an even number of integers as `row col` pairs."
            )
        normalized = [(flat[idx], flat[idx + 1]) for idx in range(0, len(flat), 2)]
    else:
        raise TypeError(f"Unsupported waypoint specification: {cells!r}")
    if not normalized:
        raise ValueError("At least one waypoint cell is required.")
    return normalized


def env_success_from_info(info: dict[str, Any], episode_reward: float) -> float:
    """Extract success flag from PointMaze info dict with a simple fallback."""
    for key in ("success", "is_success"):
        if key in info:
            return float(info[key])
    return float(episode_reward >= float(MAX_WAYPOINT_EPISODE_REWARD))


def sanitize_env_name(env_id: str) -> str:
    """Convert env id into a filesystem-friendly slug."""
    return env_id.replace("/", "_").replace(":", "_")


import re


def choose_device(device_arg: str) -> "torch.device":
    """Resolve an `auto` device flag."""
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_arg)


def resolve_optional_dir(path: str | None) -> str | None:
    """Resolve relative paths against the package directory."""
    if path is None or not str(path).strip():
        return None
    candidate = str(path)
    if os.path.isabs(candidate):
        return candidate
    if os.path.exists(candidate):
        return os.path.abspath(candidate)
    script_relative = os.path.join(os.path.dirname(os.path.abspath(__file__)), candidate)
    return os.path.abspath(script_relative)


def _as_fs_path(path: str) -> str:
    abs_path = os.path.abspath(path)
    if os.name != "nt":
        return abs_path
    if abs_path.startswith("\\\\?\\"):
        return abs_path
    if abs_path.startswith("\\"):
        return "\\\\?\\UNC\\" + abs_path[2:].lstrip("\\")
    return "\\\\?\\" + abs_path


def _strip_fs_prefix(path: str) -> str:
    if path.startswith("\\\\?\\UNC\\"):
        return "\\\\" + path[len("\\\\?\\UNC\\") :]
    if path.startswith("\\\\?\\"):
        return path[4:]
    return path


def resolve_option_bank_dir(path: str) -> str:
    """Resolve an option-bank root or run directory to the `options` folder."""
    resolved = resolve_optional_dir(path)
    if resolved is None:
        raise FileNotFoundError(f"Option bank path is empty: {path!r}")
    fs_path = _as_fs_path(resolved)
    if os.path.isdir(fs_path):
        if os.path.basename(os.path.abspath(_strip_fs_prefix(fs_path))) == "options":
            return os.path.abspath(_strip_fs_prefix(fs_path))
        options_dir = os.path.join(fs_path, "options")
        if os.path.isdir(options_dir):
            return os.path.abspath(_strip_fs_prefix(options_dir))
    raise FileNotFoundError(f"Could not resolve option bank directory from {path!r}")


_RUN_SEED_RE = re.compile(r"__seed(?P<seed>\d+)$", re.IGNORECASE)


def extract_run_seed(path: str) -> int | None:
    match = _RUN_SEED_RE.search(os.path.basename(os.path.abspath(path)))
    if match is None:
        return None
    return int(match.group("seed"))


def resolve_seed_specific_option_bank_dir(path: str, option_seed: int | None) -> str:
    resolved = resolve_optional_dir(path)
    if resolved is None:
        raise FileNotFoundError(f"Option bank path is empty: {path!r}")
    if option_seed is None:
        return resolve_option_bank_dir(resolved)
    basename = os.path.basename(os.path.abspath(resolved))
    if basename == "options" or extract_run_seed(resolved) is not None:
        return resolve_option_bank_dir(resolved)
    matching: list[str] = []
    for child_name in os.listdir(resolved):
        child_path = os.path.join(resolved, child_name)
        if os.path.isdir(child_path) and extract_run_seed(child_path) == int(option_seed):
            matching.append(child_path)
    if not matching:
        raise FileNotFoundError(f"No run with suffix __seed{option_seed} under {resolved!r}")
    return resolve_option_bank_dir(max(matching, key=os.path.getmtime))
