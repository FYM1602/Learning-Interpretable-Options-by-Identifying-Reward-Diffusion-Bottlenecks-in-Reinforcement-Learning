"""PointMaze figures: VPS/Value heatmaps, option/skill rollouts, aggregated return curves."""
from __future__ import annotations

import argparse
import glob
import os
import sys
import time

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

from .maze_plotting import (
    aggregate_feature_grid,
    compute_extent,
    draw_maze_overlay,
    get_maze_plot_spec,
    render_feature_grids,
    _open_pointmaze_env,
)

try:
    from .utils import (
        CUSTOM_POINTMAZE_ENV_ID,
        PointMazeObsOnlyWrapper,
        ensure_dir,
        maybe_to_maze_map,
        resolve_optional_dir,
        resolve_pointmaze_env_selection,
        resolve_seed_specific_option_bank_dir,
    )
except ImportError:  # pragma: no cover
    from utils import (
        CUSTOM_POINTMAZE_ENV_ID,
        PointMazeObsOnlyWrapper,
        ensure_dir,
        maybe_to_maze_map,
        resolve_optional_dir,
        resolve_pointmaze_env_selection,
        resolve_seed_specific_option_bank_dir,
    )


def _plot_trajectories(
    trajectories: list[np.ndarray],
    *,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    save_path: str,
    title: str,
) -> str:
    all_states = np.concatenate(trajectories, axis=0)
    states_xy = np.asarray(all_states[:, :2], dtype=np.float64)
    maze_map, known_extent = get_maze_plot_spec(env_id, maze_map=maze_map)
    extent = known_extent if known_extent is not None else compute_extent(states_xy, env_id, maze_map)

    plt.figure(figsize=(5.2, 4.8))
    ax = plt.gca()
    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    draw_maze_overlay(ax, maze_map, extent, env_id=env_id)
    for trajectory in trajectories:
        xy = np.asarray(trajectory[:, :2], dtype=np.float64)
        line, = ax.plot(xy[:, 0], xy[:, 1], linewidth=1.6, alpha=0.85)
        color = line.get_color()
        ax.scatter(xy[0, 0], xy[0, 1], s=18, marker="o", color=color)
        ax.scatter(xy[-1, 0], xy[-1, 1], s=28, marker="x", color=color)
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.grid(alpha=0.2)
    ax.legend(
        handles=[
            Line2D([0], [0], color="black", linewidth=1.6, label="Rollout"),
            Line2D([0], [0], marker="o", color="black", linestyle="None", markersize=6, label="Start"),
            Line2D([0], [0], marker="x", color="black", linestyle="None", markersize=7, label="End"),
        ],
        loc="best",
    )
    plt.tight_layout()
    plt.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close()
    return save_path


def _collect_policy_rollouts(
    *,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    policy,
    num_rollouts: int,
    rollout_steps: int,
    seed: int,
    max_episode_steps: int,
) -> list[np.ndarray]:
    trajectories: list[np.ndarray] = []
    for episode_idx in range(int(num_rollouts)):
        env = _open_pointmaze_env(
            env_id,
            maze_map,
            seed=int(seed) + episode_idx,
            max_episode_steps=max_episode_steps,
        )
        env = PointMazeObsOnlyWrapper(env)
        try:
            obs, _ = env.reset(seed=int(seed) + episode_idx)
            states = [np.asarray(obs, dtype=np.float32).copy()]
            for _ in range(int(rollout_steps)):
                action, _ = policy.predict(obs, deterministic=True)
                obs, _, terminated, truncated, _ = env.step(action)
                states.append(np.asarray(obs, dtype=np.float32).copy())
                if bool(terminated or truncated):
                    break
            trajectories.append(np.asarray(states, dtype=np.float32))
        finally:
            env.close()
    return trajectories


def plot_option_bank_rollouts(
    *,
    option_bank_dir: str,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    save_dir: str,
    device: str,
    num_rollouts: int,
    rollout_steps: int,
    seed: int,
    max_episode_steps: int,
    label_prefix: str,
) -> list[str]:
    """Roll out every policy in an option bank and save trajectory figures."""
    import torch

    from .option_bank import load_option_bank

    bank = load_option_bank(option_bank_dir, device=torch.device(device))
    save_dir = ensure_dir(save_dir)
    saved: list[str] = []
    for entry in bank:
        trajectories = _collect_policy_rollouts(
            env_id=env_id,
            maze_map=maze_map,
            policy=entry.model,
            num_rollouts=num_rollouts,
            rollout_steps=rollout_steps,
            seed=seed + 100 * entry.option_id,
            max_episode_steps=max_episode_steps,
        )
        out_path = os.path.join(save_dir, f"{label_prefix}_{entry.name}.png")
        _plot_trajectories(
            trajectories,
            env_id=env_id,
            maze_map=maze_map,
            save_path=out_path,
            title=f"{label_prefix} {entry.name}",
        )
        saved.append(out_path)
        print(f"[Plot] Saved {out_path}")
    return saved


def aggregate_return_curve_files(
    *,
    return_curve_root: str,
    smoothing_window: int,
    save_dir: str | None = None,
) -> dict[str, str]:
    """Aggregate per-method `*_return_curve.npz` files across seeds into one PNG each."""
    return_curve_root = resolve_optional_dir(return_curve_root) or return_curve_root
    save_dir = ensure_dir(save_dir or os.path.join(return_curve_root, "aggregated"))
    outputs: dict[str, str] = {}
    for category in sorted(os.listdir(return_curve_root)):
        category_dir = os.path.join(return_curve_root, category)
        if not os.path.isdir(category_dir):
            continue
        npz_paths = sorted(glob.glob(os.path.join(category_dir, "*_return_curve.npz")))
        if not npz_paths:
            continue
        curves: list[tuple[np.ndarray, np.ndarray]] = []
        for npz_path in npz_paths:
            payload = np.load(npz_path)
            try:
                timesteps = np.asarray(payload["timesteps"], dtype=np.int64)
                rewards = np.asarray(payload["mean_rewards"], dtype=np.float32)
            finally:
                payload.close()
            if timesteps.size and rewards.size:
                curves.append((timesteps, rewards))

        if not curves:
            continue

        common = curves[0][0]
        stacked = []
        for timesteps, rewards in curves:
            if timesteps.shape != common.shape or not np.array_equal(timesteps, common):
                common = None
                break
        if common is None:
            min_len = min(curve[0].size for curve in curves)
            common = curves[0][0][:min_len]
            stacked = np.stack([curve[1][:min_len] for curve in curves], axis=0)
        else:
            stacked = np.stack([curve[1] for curve in curves], axis=0)

        mu = stacked.mean(axis=0)
        sig = stacked.std(axis=0)
        if int(smoothing_window) > 1:
            kernel = np.ones(int(smoothing_window), dtype=np.float64) / float(smoothing_window)
            mu = np.convolve(mu, kernel, mode="same")
            sig = np.convolve(sig, kernel, mode="same")

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        png_path = os.path.join(save_dir, f"{timestamp}_{category}_aggregated_return.png")
        plt.figure(figsize=(7.2, 4.6))
        plt.plot(common, mu, linewidth=1.9, label=category)
        plt.fill_between(common, mu - sig, mu + sig, alpha=0.15)
        plt.xlabel("Environment Steps")
        plt.ylabel("Mean Eval Reward")
        plt.title(f"{category} aggregated return ({stacked.shape[0]} runs)")
        plt.grid(alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(png_path, dpi=200, bbox_inches="tight")
        plt.close()
        outputs[category] = png_path
        print(f"[Plot] Saved {png_path}")
    return outputs


def _build_heatmap_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Render Value/VPS heatmaps from saved VPS artifacts.")
    parser.add_argument("--artifact_npz", required=True, help="Path to `pointmaze_vps_artifacts.npz`.")
    parser.add_argument("--env_id", default=CUSTOM_POINTMAZE_ENV_ID)
    parser.add_argument("--maze_json", default=os.path.join("maze_maps", "custom.json"))
    parser.add_argument("--feature", choices=("value", "vps", "both"), default="both")
    parser.add_argument("--save_dir", default=None, help="Output directory (defaults next to artifact).")
    parser.add_argument("--projection_mode", choices=("continuous", "cell"), default="continuous")
    parser.add_argument("--bins", type=int, default=40)
    parser.add_argument("--plot_max_options", type=int, default=4)
    parser.add_argument("--dpi", type=int, default=200)
    return parser


def main_heatmaps(argv: list[str] | None = None) -> None:
    args = _build_heatmap_parser().parse_args(argv)
    artifact_path = resolve_optional_dir(args.artifact_npz) or args.artifact_npz
    payload = np.load(artifact_path, allow_pickle=True)
    try:
        env_id = str(np.asarray(payload["env_id"]).item())
        states = np.asarray(payload["states"], dtype=np.float32)
        value_features = np.asarray(payload["value_features"], dtype=np.float32)
        vps_features = np.asarray(payload["vps_features"], dtype=np.float32)
        maze_map = maybe_to_maze_map(payload["maze_map"].item() if "maze_map" in payload else None)
    finally:
        payload.close()

    requested_env_id = str(args.env_id)
    maze_json = resolve_optional_dir(args.maze_json)
    env_id, _, resolved_map, _ = resolve_pointmaze_env_selection(requested_env_id, maze_json)
    if maze_map is None:
        maze_map = resolved_map

    save_root = args.save_dir
    if save_root is None:
        save_root = os.path.join(os.path.dirname(artifact_path), "rendered_heatmaps")
    save_root = ensure_dir(save_root)

    if args.feature in {"value", "both"}:
        render_feature_grids(
            states=states,
            features=value_features,
            env_id=env_id,
            maze_map=maze_map,
            feature_name="Value",
            save_dir=os.path.join(save_root, "value"),
            projection_mode=args.projection_mode,
            bins=args.bins,
            max_options_per_figure=args.plot_max_options,
            dpi=args.dpi,
        )
    if args.feature in {"vps", "both"}:
        render_feature_grids(
            states=states,
            features=vps_features,
            env_id=env_id,
            maze_map=maze_map,
            feature_name="VPS",
            save_dir=os.path.join(save_root, "vps"),
            projection_mode=args.projection_mode,
            bins=args.bins,
            max_options_per_figure=args.plot_max_options,
            dpi=args.dpi,
        )


def _build_rollout_parser(label: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=f"Plot {label} rollout trajectories.")
    parser.add_argument("--option_bank_dir", required=True)
    parser.add_argument("--option_seed", type=int, default=None)
    parser.add_argument("--env_id", default=CUSTOM_POINTMAZE_ENV_ID)
    parser.add_argument("--maze_json", default=os.path.join("maze_maps", "custom.json"))
    parser.add_argument("--save_dir", default=None)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--num_rollouts", type=int, default=5)
    parser.add_argument("--rollout_steps", type=int, default=500)
    parser.add_argument("--max_episode_steps", type=int, default=500)
    parser.add_argument("--seed", type=int, default=0)
    return parser


def main_rollouts_vps(argv: list[str] | None = None) -> None:
    args = _build_rollout_parser("VPS").parse_args(argv)
    device = "cuda" if args.device == "auto" and __import__("torch").cuda.is_available() else (
        "cpu" if args.device == "auto" else args.device
    )
    bank_dir = resolve_seed_specific_option_bank_dir(args.option_bank_dir, args.option_seed)
    env_id, _, maze_map, _ = resolve_pointmaze_env_selection(args.env_id, resolve_optional_dir(args.maze_json))
    save_dir = args.save_dir or os.path.join(bank_dir, "rollout_plots")
    plot_option_bank_rollouts(
        option_bank_dir=bank_dir,
        env_id=env_id,
        maze_map=maze_map,
        save_dir=save_dir,
        device=device,
        num_rollouts=args.num_rollouts,
        rollout_steps=args.rollout_steps,
        seed=args.seed,
        max_episode_steps=args.max_episode_steps,
        label_prefix="VPS",
    )


def main_rollouts_diayn(argv: list[str] | None = None) -> None:
    args = _build_rollout_parser("DIAYN").parse_args(argv)
    device = "cuda" if args.device == "auto" and __import__("torch").cuda.is_available() else (
        "cpu" if args.device == "auto" else args.device
    )
    bank_dir = resolve_seed_specific_option_bank_dir(args.option_bank_dir, args.option_seed)
    env_id, _, maze_map, _ = resolve_pointmaze_env_selection(args.env_id, resolve_optional_dir(args.maze_json))
    save_dir = args.save_dir or os.path.join(bank_dir, "rollout_plots")
    plot_option_bank_rollouts(
        option_bank_dir=bank_dir,
        env_id=env_id,
        maze_map=maze_map,
        save_dir=save_dir,
        device=device,
        num_rollouts=args.num_rollouts,
        rollout_steps=args.rollout_steps,
        seed=args.seed,
        max_episode_steps=args.max_episode_steps,
        label_prefix="DIAYN",
    )


def _build_aggregate_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Aggregate saved downstream return curves across seeds.")
    parser.add_argument(
        "--return_curve_root",
        default=os.path.join("option_goal_reaching_results", "return_curves"),
    )
    parser.add_argument("--save_dir", default=None)
    parser.add_argument("--smoothing_window", type=int, default=1)
    return parser


def main_aggregate_curves(argv: list[str] | None = None) -> None:
    args = _build_aggregate_parser().parse_args(argv)
    root = resolve_optional_dir(args.return_curve_root) or args.return_curve_root
    aggregate_return_curve_files(
        return_curve_root=root,
        smoothing_window=args.smoothing_window,
        save_dir=resolve_optional_dir(args.save_dir) if args.save_dir else None,
    )


def run_heatmaps(argv: list[str] | None = None) -> None:
    main_heatmaps(argv)


def run_rollouts_vps(argv: list[str] | None = None) -> None:
    main_rollouts_vps(argv)


def run_rollouts_diayn(argv: list[str] | None = None) -> None:
    main_rollouts_diayn(argv)


def run_aggregate_curves(argv: list[str] | None = None) -> None:
    main_aggregate_curves(argv)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "heatmaps"
    rest = sys.argv[2:]
    if cmd == "heatmaps":
        main_heatmaps(rest)
    elif cmd == "rollouts-vps":
        main_rollouts_vps(rest)
    elif cmd == "rollouts-diayn":
        main_rollouts_diayn(rest)
    elif cmd == "aggregate-curves":
        main_aggregate_curves(rest)
    else:
        raise SystemExit(f"Unknown command {cmd!r}")
