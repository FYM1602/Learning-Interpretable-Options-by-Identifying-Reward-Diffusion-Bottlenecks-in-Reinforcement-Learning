"""Maze spatial plots shared by pretraining, options, and downstream (no training imports)."""
from __future__ import annotations

import math
import os

import matplotlib.pyplot as plt
import numpy as np

try:
    from .utils import DEFAULT_CUSTOM_POINTMAZE_BACKEND, ensure_dir, make_pointmaze_env
except ImportError:  # pragma: no cover
    from utils import DEFAULT_CUSTOM_POINTMAZE_BACKEND, ensure_dir, make_pointmaze_env


def _open_pointmaze_env(
    env_id: str,
    maze_map: list[list[int | str]] | None,
    *,
    seed: int | None = None,
    max_episode_steps: int | None = None,
    render_mode: str | None = None,
):
    extra: dict = {}
    backend_id = env_id
    if maze_map is not None:
        backend_id = DEFAULT_CUSTOM_POINTMAZE_BACKEND
        extra["maze_map"] = maze_map
    if max_episode_steps is not None:
        extra["max_episode_steps"] = int(max_episode_steps)
    if render_mode is not None:
        extra["render_mode"] = render_mode
    return make_pointmaze_env(backend_id, seed=seed, extra_kwargs=extra or None)


def _maze_object(env):
    unwrapped = env.unwrapped
    if not hasattr(unwrapped, "maze"):
        raise TypeError("Expected a PointMaze environment with a `maze` attribute.")
    return unwrapped.maze


def _extent_from_maze(env) -> tuple[float, float, float, float]:
    maze = _maze_object(env)
    xs: list[float] = []
    ys: list[float] = []
    for row in range(int(maze.map_length)):
        for col in range(int(maze.map_width)):
            if maze.maze_map[row][col] == 1:
                continue
            xy = np.asarray(maze.cell_rowcol_to_xy((row, col)), dtype=np.float64)
            xs.append(float(xy[0]))
            ys.append(float(xy[1]))
    if not xs:
        return (-1.0, 1.0, -1.0, 1.0)
    pad = 0.6
    return (min(xs) - pad, max(xs) + pad, min(ys) - pad, max(ys) + pad)


def get_maze_plot_spec(
    env_id: str,
    *,
    maze_map: list[list[int | str]] | None = None,
) -> tuple[list[list[int | str]] | None, tuple[float, float, float, float] | None]:
    """Return maze map tokens and a plotting extent derived from the environment."""
    env = _open_pointmaze_env(env_id, maze_map)
    try:
        maze = _maze_object(env)
        resolved_map = maze_map if maze_map is not None else [list(row) for row in maze.maze_map]
        return resolved_map, _extent_from_maze(env)
    finally:
        env.close()


def compute_extent(
    states_xy: np.ndarray,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    *,
    pad: float = 0.6,
) -> tuple[float, float, float, float]:
    """Compute plot limits from trajectory samples with optional maze bounds."""
    states_xy = np.asarray(states_xy, dtype=np.float64).reshape(-1, 2)
    if states_xy.size == 0:
        _, extent = get_maze_plot_spec(env_id, maze_map=maze_map)
        return extent if extent is not None else (-1.0, 1.0, -1.0, 1.0)
    x_min = float(np.min(states_xy[:, 0]))
    x_max = float(np.max(states_xy[:, 0]))
    y_min = float(np.min(states_xy[:, 1]))
    y_max = float(np.max(states_xy[:, 1]))
    if maze_map is not None:
        env = _open_pointmaze_env(env_id, maze_map)
        try:
            mx0, mx1, my0, my1 = _extent_from_maze(env)
            x_min = min(x_min, mx0)
            x_max = max(x_max, mx1)
            y_min = min(y_min, my0)
            y_max = max(y_max, my1)
        finally:
            env.close()
    return (x_min - pad, x_max + pad, y_min - pad, y_max + pad)


def draw_maze_overlay(
    ax: plt.Axes,
    maze_map: list[list[int | str]] | None,
    extent: tuple[float, float, float, float],
    *,
    env_id: str = DEFAULT_CUSTOM_POINTMAZE_BACKEND,
) -> None:
    """Draw wall cells as dark rectangles on top of a trajectory or heatmap."""
    if maze_map is None:
        return
    env = _open_pointmaze_env(env_id, maze_map)
    try:
        maze = _maze_object(env)
        centers: list[tuple[float, float]] = []
        for row in range(len(maze_map)):
            for col in range(len(maze_map[row])):
                if maze_map[row][col] != 1:
                    xy = np.asarray(maze.cell_rowcol_to_xy((row, col)), dtype=np.float64)
                    centers.append((float(xy[0]), float(xy[1])))
        if len(centers) < 2:
            return
        xs = sorted({c[0] for c in centers})
        ys = sorted({c[1] for c in centers})
        cell_w = float(np.median(np.diff(xs))) if len(xs) > 1 else 1.0
        cell_h = float(np.median(np.diff(ys))) if len(ys) > 1 else 1.0
        half_w = 0.5 * cell_w
        half_h = 0.5 * cell_h
        for row in range(len(maze_map)):
            for col in range(len(maze_map[row])):
                if maze_map[row][col] != 1:
                    continue
                xy = np.asarray(maze.cell_rowcol_to_xy((row, col)), dtype=np.float64)
                x, y = float(xy[0]), float(xy[1])
                ax.add_patch(
                    plt.Rectangle(
                        (x - half_w, y - half_h),
                        cell_w,
                        cell_h,
                        facecolor="#1a1a1a",
                        edgecolor="white",
                        linewidth=0.4,
                        zorder=3,
                    )
                )
    finally:
        env.close()


def aggregate_feature_grid(
    *,
    states_xy: np.ndarray,
    feature_values: np.ndarray,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    bins: int,
    extent: tuple[float, float, float, float],
    projection_mode: str,
) -> np.ndarray:
    """Project per-state feature values onto a 2D grid for heatmap rendering."""
    states_xy = np.asarray(states_xy, dtype=np.float64).reshape(-1, 2)
    feature_values = np.asarray(feature_values, dtype=np.float64).reshape(-1)
    if states_xy.shape[0] != feature_values.shape[0]:
        raise ValueError("states_xy and feature_values must have the same length.")

    if projection_mode == "continuous":
        hist, _, _ = np.histogram2d(
            states_xy[:, 0],
            states_xy[:, 1],
            bins=int(bins),
            range=[[extent[0], extent[1]], [extent[2], extent[3]]],
            weights=feature_values,
        )
        counts, _, _ = np.histogram2d(
            states_xy[:, 0],
            states_xy[:, 1],
            bins=int(bins),
            range=[[extent[0], extent[1]], [extent[2], extent[3]]],
        )
        with np.errstate(invalid="ignore", divide="ignore"):
            grid = np.divide(hist, counts, where=counts > 0)
        return np.nan_to_num(grid, nan=0.0).T

    if projection_mode != "cell":
        raise ValueError(f"Unsupported projection_mode={projection_mode!r}")

    env = _open_pointmaze_env(env_id, maze_map)
    try:
        maze = _maze_object(env)
        grid = np.zeros((int(maze.map_length), int(maze.map_width)), dtype=np.float64)
        counts = np.zeros_like(grid, dtype=np.float64)
        xy_to_cell = getattr(maze, "xy_to_cellrowcol", None)
        for xy, value in zip(states_xy, feature_values):
            if xy_to_cell is not None:
                row, col = xy_to_cell(np.asarray(xy, dtype=np.float64))
            else:
                best = None
                best_dist = float("inf")
                for row in range(int(maze.map_length)):
                    for col in range(int(maze.map_width)):
                        if maze_map[row][col] == 1:
                            continue
                        center = np.asarray(maze.cell_rowcol_to_xy((row, col)), dtype=np.float64)
                        dist = float(np.linalg.norm(center[:2] - xy))
                        if dist < best_dist:
                            best_dist = dist
                            best = (row, col)
                if best is None:
                    continue
                row, col = best
            row, col = int(row), int(col)
            grid[row, col] += float(value)
            counts[row, col] += 1.0
        with np.errstate(invalid="ignore", divide="ignore"):
            grid = np.divide(grid, counts, where=counts > 0)
        return np.nan_to_num(grid, nan=0.0)
    finally:
        env.close()


def render_feature_grids(
    *,
    states: np.ndarray,
    features: np.ndarray,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    feature_name: str,
    save_dir: str,
    projection_mode: str,
    bins: int,
    max_options_per_figure: int,
    dpi: int,
) -> list[str]:
    """Render per-head spatial heatmaps and save multi-panel PNG files."""
    save_dir = ensure_dir(save_dir)
    states_xy = np.asarray(states[:, :2], dtype=np.float64)
    features = np.asarray(features, dtype=np.float32)
    if features.ndim != 2:
        raise ValueError(f"`features` must be 2-D (num_states, num_heads), got {features.shape!r}")
    num_heads = int(features.shape[1])
    maze_map, known_extent = get_maze_plot_spec(env_id, maze_map=maze_map)
    extent = known_extent if known_extent is not None else compute_extent(states_xy, env_id, maze_map)

    saved_paths: list[str] = []
    for start in range(0, num_heads, max(1, int(max_options_per_figure))):
        stop = min(start + int(max_options_per_figure), num_heads)
        chunk_heads = range(start, stop)
        n_cols = min(2, len(chunk_heads))
        n_rows = int(math.ceil(len(chunk_heads) / n_cols))
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(6.0 * n_cols, 5.2 * n_rows))
        axes = np.atleast_1d(axes).ravel()

        for ax, head_idx in zip(axes, chunk_heads):
            grid = aggregate_feature_grid(
                states_xy=states_xy,
                feature_values=features[:, head_idx],
                env_id=env_id,
                maze_map=maze_map,
                bins=bins,
                extent=extent,
                projection_mode=projection_mode,
            )
            if projection_mode == "cell":
                image = ax.imshow(grid, origin="upper", cmap="viridis", aspect="equal")
            else:
                image = ax.imshow(
                    grid,
                    origin="lower",
                    extent=extent,
                    cmap="viridis",
                    aspect="equal",
                )
            draw_maze_overlay(ax, maze_map, extent, env_id=env_id)
            ax.set_title(f"{feature_name} head {head_idx}")
            ax.set_xlabel("x")
            ax.set_ylabel("y")
            fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)

        for ax in axes[len(chunk_heads) :]:
            ax.axis("off")

        fig.suptitle(f"{feature_name} spatial maps ({projection_mode})", fontsize=12)
        fig.tight_layout(rect=(0, 0.02, 1, 0.94))
        path = os.path.join(save_dir, f"{feature_name.lower()}_{start:02d}_{stop - 1:02d}.png")
        fig.savefig(path, dpi=int(dpi), bbox_inches="tight")
        plt.close(fig)
        saved_paths.append(path)
    return saved_paths
