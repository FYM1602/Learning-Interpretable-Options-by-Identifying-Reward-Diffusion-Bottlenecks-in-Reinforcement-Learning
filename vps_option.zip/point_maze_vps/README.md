# PointMaze VPS / DIAYN

Continuous **Point Maze** experiments: random-walk pretraining → offline Value/VPS or DIAYN skills → downstream **four-waypoint** navigation with SAC / SAC+VPS / SAC+DIAYN.

## Layout

| Module | Role |
|--------|------|
| `models.py` | RFF value/VPS networks |
| `offline_vps.py` | Fit Value/VPS from replay |
| `option_training.py` | SAC option training + rollout plots |
| `diayn_training.py` | DIAYN skills |
| `pipeline.py` | Pretrain orchestration (VPS or DIAYN) |
| `downstream.py` | Four-waypoint SAC comparison + optional meta-control |
| `plotting.py` | Heatmaps, option/skill rollouts, return-curve aggregation |
| `__main__.py` | Unified CLI |

Outputs (not in git): `pretrained_option_bank/`, `option_goal_reaching_results/`, run folders under `point_maze_vps_results/`.

## Usage

From the repository root (`vps_option_discovery`):

```bash
# VPS pretrain (random walk → Value/VPS → 8 options with dual-sign)
python -m point_maze_vps pretrain vps

# DIAYN pretrain (8 skills)
python -m point_maze_vps pretrain diayn

# Downstream: SAC vs SAC+DIAYN vs SAC+VPS (four ordered waypoints, HER off)
python -m point_maze_vps downstream compare --run_method all

# Figures
python -m point_maze_vps plot heatmaps --artifact_npz path/to/pointmaze_vps_artifacts.npz
python -m point_maze_vps plot rollouts vps --option_bank_dir pretrained_option_bank/vps
python -m point_maze_vps plot rollouts diayn --option_bank_dir pretrained_option_bank/diayn
python -m point_maze_vps plot aggregate-curves --return_curve_root option_goal_reaching_results/return_curves
```

See [`EXPERIMENT_DEFAULTS.md`](EXPERIMENT_DEFAULTS.md) for hyperparameter tables.

## Downstream task

- **Waypoints (order):** (4,2) → (6,4) → (4,6) → (2,4)
- **Reward:** +1 per waypoint in order; episode cap **4**
- **Default training:** 500k steps, γ=0.95, plain SAC (no HER in `downstream compare`)

## Legacy script

`run_point_maze_diayn_goal_reaching.py` is a thin wrapper around `downstream compare` (same CLI flags). Prefer:

```bash
python -m point_maze_vps downstream compare ...
```

## Dependencies

`gymnasium`, `gymnasium-robotics`, PyTorch, Stable-Baselines3, Matplotlib, NumPy.
