from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Any

import torch
from stable_baselines3 import SAC

_OPTION_NAME_RE = re.compile(
    r"^(?:option_(?P<option_id>\d+)_)?head(?P<head_idx>\d+)_(?P<sign>pos|neg)$",
    re.IGNORECASE,
)


@dataclass
class OptionBankEntry:
    """Loaded pretrained option policy and its metadata."""

    option_id: int
    head_idx: int
    sign: int
    name: str
    zip_path: str
    source_dir: str
    summary_path: str | None
    model: SAC


def _as_fs_path(path: str) -> str:
    """Use Windows long-path syntax when needed."""
    abs_path = os.path.abspath(path)
    if os.name != "nt":
        return abs_path
    if abs_path.startswith("\\\\?\\"):
        return abs_path
    if abs_path.startswith("\\\\"):
        return "\\\\?\\UNC\\" + abs_path[2:]
    return "\\\\?\\" + abs_path


def _strip_fs_prefix(path: str) -> str:
    """Convert Windows long-path syntax back into a regular absolute path."""
    if os.name != "nt":
        return path
    if path.startswith("\\\\?\\UNC\\"):
        return "\\\\" + path[len("\\\\?\\UNC\\") :]
    if path.startswith("\\\\?\\"):
        return path[len("\\\\?\\") :]
    return path


def _normalize_sign(value: Any) -> int:
    """Normalize sign metadata to +/-1."""
    if isinstance(value, str):
        token = value.strip().lower()
        if token in {"pos", "+", "+1", "1", "positive"}:
            return 1
        if token in {"neg", "-", "-1", "negative"}:
            return -1
    sign = int(value)
    if sign not in {-1, 1}:
        raise ValueError(f"Unsupported option sign: {value!r}")
    return sign


def _summary_candidate_paths(zip_path: str) -> list[str]:
    """Return likely sidecar summary paths for an option zip file."""
    parent = os.path.dirname(zip_path)
    stem = os.path.splitext(os.path.basename(zip_path))[0]
    return [
        os.path.join(parent, "option_summary.json"),
        os.path.join(parent, f"{stem}.json"),
        os.path.join(parent, f"{stem}_summary.json"),
    ]


def _parse_metadata_from_summary(summary_path: str) -> dict[str, Any]:
    """Parse option metadata from a sidecar JSON summary."""
    with open(_as_fs_path(summary_path), "r", encoding="utf-8") as f:
        payload = json.load(f)
    option_id = int(payload["option_id"])
    head_idx = int(payload["head_idx"])
    sign = _normalize_sign(payload["sign"])
    option_name = str(payload.get("option_name") or f"head{head_idx:02d}_{'pos' if sign > 0 else 'neg'}")
    return {
        "option_id": option_id,
        "head_idx": head_idx,
        "sign": sign,
        "name": option_name,
    }


def _parse_metadata_from_name(name: str) -> dict[str, Any] | None:
    """Parse metadata from a directory name or zip stem."""
    match = _OPTION_NAME_RE.match(name)
    if match is None:
        return None
    sign = 1 if match.group("sign").lower() == "pos" else -1
    option_id = match.group("option_id")
    head_idx = int(match.group("head_idx"))
    return {
        "option_id": int(option_id) if option_id is not None else -1,
        "head_idx": head_idx,
        "sign": sign,
        "name": f"head{head_idx:02d}_{'pos' if sign > 0 else 'neg'}",
    }


def _resolve_option_metadata(zip_path: str) -> tuple[dict[str, Any], str | None]:
    """Resolve option metadata from a sidecar JSON or naming convention."""
    for summary_path in _summary_candidate_paths(zip_path):
        if os.path.exists(_as_fs_path(summary_path)):
            return _parse_metadata_from_summary(summary_path), summary_path

    parent_name = os.path.basename(os.path.dirname(zip_path))
    parsed = _parse_metadata_from_name(parent_name)
    if parsed is not None:
        return parsed, None

    stem = os.path.splitext(os.path.basename(zip_path))[0]
    parsed = _parse_metadata_from_name(stem)
    if parsed is not None:
        return parsed, None

    raise ValueError(
        "Could not infer option metadata for "
        f"{zip_path!r}. Provide a sibling `option_summary.json` or name the parent "
        "directory / zip as `option_00_head00_pos` or `head00_pos`."
    )


def discover_option_zip_paths(option_bank_dir: str) -> list[str]:
    """Recursively discover pretrained option zip files."""
    zip_paths: list[str] = []
    for root, _, files in os.walk(_as_fs_path(option_bank_dir)):
        for filename in files:
            if filename.lower() == "option_policy.zip" or filename.lower().endswith(".zip"):
                zip_paths.append(_strip_fs_prefix(os.path.join(root, filename)))
    zip_paths.sort()
    return zip_paths


def load_option_bank(option_bank_dir: str, device: torch.device | str) -> list[OptionBankEntry]:
    """Load all pretrained options from a directory."""
    option_bank_dir = os.path.abspath(option_bank_dir)
    if not os.path.isdir(_as_fs_path(option_bank_dir)):
        raise FileNotFoundError(f"Option bank directory does not exist: {option_bank_dir}")

    zip_paths = discover_option_zip_paths(option_bank_dir)
    if not zip_paths:
        raise FileNotFoundError(
            f"No `.zip` option policies were found under {option_bank_dir}. "
            "Place whole `option_policy.zip` files there; do not unzip them."
        )

    entries: list[OptionBankEntry] = []
    for fallback_id, zip_path in enumerate(zip_paths):
        metadata, summary_path = _resolve_option_metadata(zip_path)
        option_id = int(metadata["option_id"])
        if option_id < 0:
            option_id = fallback_id
        model = SAC.load(_as_fs_path(zip_path), device=str(device))
        entries.append(
            OptionBankEntry(
                option_id=option_id,
                head_idx=int(metadata["head_idx"]),
                sign=int(metadata["sign"]),
                name=str(metadata["name"]),
                zip_path=os.path.abspath(zip_path),
                source_dir=os.path.abspath(os.path.dirname(zip_path)),
                summary_path=None if summary_path is None else os.path.abspath(summary_path),
                model=model,
            )
        )

    entries.sort(key=lambda entry: (entry.option_id, entry.head_idx, entry.sign, entry.name))
    for auto_id, entry in enumerate(entries):
        if entry.option_id < 0:
            entry.option_id = auto_id
    return entries
