#!/usr/bin/env python
"""Downstream four-waypoint task: SAC vs SAC+VPS vs SAC+DIAYN (+ optional meta-control)."""

from __future__ import annotations

import argparse
import os
import re
import time
from dataclasses import dataclass

import gymnasium as gym
import matplotlib.pyplot as plt
import numpy as np
import torch
from stable_baselines3 import DQN, HerReplayBuffer, SAC
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.monitor import Monitor

try:
    from .option_bank import load_option_bank
    from .option_intervention_sac import OptionInterventionSAC
    from .utils import (
        CUSTOM_POINTMAZE_ENV_ID,
        DEFAULT_CUSTOM_POINTMAZE_BACKEND,
        DEFAULT_WAYPOINT_CELLS_FLAT,
        choose_device,
        ensure_dir,
        env_success_from_info,
        extract_run_seed,
        make_pointmaze_env,
        normalize_waypoint_cells,
        resolve_optional_dir,
        resolve_pointmaze_env_selection,
        save_json,
        set_global_seed,
    )
except ImportError:  # pragma: no cover
    from option_bank import load_option_bank
    from option_intervention_sac import OptionInterventionSAC
    from utils import (
        CUSTOM_POINTMAZE_ENV_ID,
        DEFAULT_CUSTOM_POINTMAZE_BACKEND,
        DEFAULT_WAYPOINT_CELLS_FLAT,
        choose_device,
        ensure_dir,
        env_success_from_info,
        extract_run_seed,
        make_pointmaze_env,
        normalize_waypoint_cells,
        resolve_optional_dir,
        resolve_pointmaze_env_selection,
        save_json,
        set_global_seed,
    )


@dataclass(frozen=True)
class MethodSpec:
    """One downstream method to train and evaluate."""

    mode_name: str
    mode_label: str
    use_option_exploration: bool
    option_bank_dir: str | None = None
    option_bank: list | None = None
    use_meta_control: bool = False


class TrainingCurveCallback(BaseCallback):
    """Track training reward curves, eval curves, and option-usage metrics."""

    def __init__(
        self,
        env_id: str,
        eval_freq: int,
        n_eval_episodes: int,
        seed: int,
        max_episode_steps: int,
        maze_map: list[list[int | str]] | None,
        fixed_start_cell: tuple[int, int] | None,
        waypoint_cells: list[tuple[int, int]],
        waypoint_radius: float,
        eval_save_path: str,
        train_curve_path: str,
        loss_curve_path: str,
        option_metrics_path: str | None = None,
        loss_record_freq: int = 1_000,
    ):
        super().__init__(verbose=0)
        self.env_id = env_id
        self.eval_freq = max(int(eval_freq), 1)
        self.n_eval_episodes = max(int(n_eval_episodes), 1)
        self.seed = int(seed)
        self.max_episode_steps = int(max_episode_steps)
        self.maze_map = maze_map
        self.fixed_start_cell = fixed_start_cell
        self.waypoint_cells = [tuple(v) for v in waypoint_cells]
        self.waypoint_radius = float(waypoint_radius)
        self.eval_save_path = eval_save_path
        self.train_curve_path = train_curve_path
        self.loss_curve_path = loss_curve_path
        self.option_metrics_path = option_metrics_path
        self.loss_record_freq = max(int(loss_record_freq), 1)
        self.timesteps: list[int] = []
        self.mean_rewards: list[float] = []
        self.mean_success: list[float] = []
        self.train_episode_timesteps: list[int] = []
        self.train_episode_rewards: list[float] = []
        self.train_episode_lengths: list[int] = []
        self.loss_timesteps: list[int] = []
        self.actor_losses: list[float] = []
        self.critic_losses: list[float] = []
        self.ent_coef_losses: list[float] = []
        self.ent_coefs: list[float] = []
        self.option_total_steps: list[int] = []
        self.option_total_starts: list[int] = []
        self._last_loss_record_step = -1

    def _save_eval_arrays(self) -> None:
        np.savez_compressed(
            self.eval_save_path,
            timesteps=np.asarray(self.timesteps, dtype=np.int64),
            mean_rewards=np.asarray(self.mean_rewards, dtype=np.float32),
            mean_success=np.asarray(self.mean_success, dtype=np.float32),
        )

    def _save_train_arrays(self) -> None:
        np.savez_compressed(
            self.train_curve_path,
            timesteps=np.asarray(self.train_episode_timesteps, dtype=np.int64),
            rewards=np.asarray(self.train_episode_rewards, dtype=np.float32),
            lengths=np.asarray(self.train_episode_lengths, dtype=np.int32),
        )

    def _save_loss_arrays(self) -> None:
        np.savez_compressed(
            self.loss_curve_path,
            timesteps=np.asarray(self.loss_timesteps, dtype=np.int64),
            actor_loss=np.asarray(self.actor_losses, dtype=np.float32),
            critic_loss=np.asarray(self.critic_losses, dtype=np.float32),
            ent_coef_loss=np.asarray(self.ent_coef_losses, dtype=np.float32),
            ent_coef=np.asarray(self.ent_coefs, dtype=np.float32),
        )

    def _maybe_record_train_rewards(self) -> None:
        infos = self.locals.get("infos", [])
        if not isinstance(infos, (list, tuple)):
            return
        for info in infos:
            if not isinstance(info, dict):
                continue
            episode = info.get("episode")
            if not isinstance(episode, dict):
                continue
            self.train_episode_timesteps.append(int(self.num_timesteps))
            self.train_episode_rewards.append(float(episode.get("r", 0.0)))
            self.train_episode_lengths.append(int(episode.get("l", 0)))
        if infos:
            self._save_train_arrays()

    def _maybe_record_losses(self) -> None:
        if self.num_timesteps == self._last_loss_record_step:
            return
        if self.num_timesteps % self.loss_record_freq != 0:
            return
        logger_values = getattr(self.model.logger, "name_to_value", {})
        critic_loss = logger_values.get("train/critic_loss")
        actor_loss = logger_values.get("train/actor_loss")
        ent_coef_loss = logger_values.get("train/ent_coef_loss")
        ent_coef = logger_values.get("train/ent_coef")
        if critic_loss is None and actor_loss is None and ent_coef_loss is None and ent_coef is None:
            return
        self._last_loss_record_step = int(self.num_timesteps)
        self.loss_timesteps.append(int(self.num_timesteps))
        self.actor_losses.append(np.nan if actor_loss is None else float(actor_loss))
        self.critic_losses.append(np.nan if critic_loss is None else float(critic_loss))
        self.ent_coef_losses.append(np.nan if ent_coef_loss is None else float(ent_coef_loss))
        self.ent_coefs.append(np.nan if ent_coef is None else float(ent_coef))
        self._save_loss_arrays()

    def _on_step(self) -> bool:
        self._maybe_record_train_rewards()
        self._maybe_record_losses()
        if self.num_timesteps % self.eval_freq != 0:
            return True
        mean_reward, mean_success = evaluate_model(
            model=self.model,
            env_id=self.env_id,
            n_eval_episodes=self.n_eval_episodes,
            seed=self.seed + len(self.timesteps) + 1,
            max_episode_steps=self.max_episode_steps,
            maze_map=self.maze_map,
            fixed_start_cell=self.fixed_start_cell,
            waypoint_cells=self.waypoint_cells,
            waypoint_radius=self.waypoint_radius,
        )
        self.timesteps.append(int(self.num_timesteps))
        self.mean_rewards.append(float(mean_reward))
        self.mean_success.append(float(mean_success))
        self._save_eval_arrays()
        if self.option_metrics_path is not None and hasattr(self.model, "get_option_intervention_summary"):
            summary = self.model.get_option_intervention_summary()
            self.option_total_steps.append(int(summary.get("total_option_steps", 0)))
            self.option_total_starts.append(int(summary.get("total_option_starts", 0)))
            np.savez_compressed(
                self.option_metrics_path,
                timesteps=np.asarray(self.timesteps, dtype=np.int64),
                total_option_steps=np.asarray(self.option_total_steps, dtype=np.int64),
                total_option_starts=np.asarray(self.option_total_starts, dtype=np.int64),
            )
        print(f"[Eval] steps={self.num_timesteps} mean_reward={mean_reward:.3f} mean_success={mean_success:.3f}")
        return True

    def _on_training_end(self) -> None:
        self._save_eval_arrays()
        self._save_train_arrays()
        self._save_loss_arrays()


def _as_fs_path(path: str) -> str:
    """Use Windows long-path syntax when needed."""
    abs_path = os.path.abspath(path)
    if os.name != "nt":
        return abs_path
    if abs_path.startswith("\\\\?\\"):
        return abs_path
    if abs_path.startswith("\\\\"):
        return "\\\\?\\UNC\\" + abs_path[2:]
    return "\\\\?\\" + abs_path


def _strip_fs_prefix(path: str) -> str:
    """Convert Windows long-path syntax back into a regular absolute path."""
    if os.name != "nt":
        return path
    if path.startswith("\\\\?\\UNC\\"):
        return "\\\\" + path[len("\\\\?\\UNC\\") :]
    if path.startswith("\\\\?\\"):
        return path[len("\\\\?\\") :]
    return path


def resolve_option_bank_dir(path: str) -> str:
    """Accept an options dir, a run dir, or a nested method root."""
    resolved = resolve_optional_dir(path)
    if resolved is None:
        raise FileNotFoundError(f"Option bank path is empty: {path!r}")
    options_dir = os.path.join(resolved, "options")
    if os.path.isdir(_as_fs_path(options_dir)):
        return os.path.abspath(options_dir)

    discovered_options_dirs: list[str] = []
    for root, dirnames, _ in os.walk(_as_fs_path(resolved)):
        if "options" not in dirnames:
            continue
        candidate = _strip_fs_prefix(os.path.join(root, "options"))
        if os.path.isdir(_as_fs_path(candidate)):
            discovered_options_dirs.append(candidate)
    if discovered_options_dirs:
        latest_options_dir = max(discovered_options_dirs, key=os.path.getmtime)
        return os.path.abspath(latest_options_dir)
    return os.path.abspath(resolved)


class FixedStartPointMazeWrapper(gym.Wrapper):
    """Force every episode to start from a user-specified PointMaze cell."""

    def __init__(self, env: gym.Env, fixed_start_cell: tuple[int, int]):
        super().__init__(env)
        row, col = (int(fixed_start_cell[0]), int(fixed_start_cell[1]))
        unwrapped = self.unwrapped
        if not hasattr(unwrapped, "reset_pos") or not hasattr(unwrapped, "point_env"):
            raise TypeError("FixedStartPointMazeWrapper requires a PointMaze environment.")
        maze = unwrapped.maze
        if row < 0 or row >= int(maze.map_length) or col < 0 or col >= int(maze.map_width):
            raise ValueError(f"fixed_start_cell {(row, col)!r} is outside the maze bounds.")
        if maze.maze_map[row][col] == 1:
            raise ValueError(f"fixed_start_cell {(row, col)!r} points to a wall cell.")
        self.fixed_start_xy = np.asarray(maze.cell_rowcol_to_xy((row, col)), dtype=np.float64)[:2].copy()
        self.fixed_start_cell = (row, col)

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        obs, info = self.env.reset(seed=seed, options=options)
        unwrapped = self.unwrapped
        point_env = unwrapped.point_env
        qpos = np.asarray(point_env.data.qpos, dtype=np.float64).copy()
        qvel = np.zeros_like(np.asarray(point_env.data.qvel, dtype=np.float64))
        qpos[:2] = self.fixed_start_xy
        point_env.init_qpos[:2] = self.fixed_start_xy
        point_env.set_state(qpos, qvel)
        unwrapped.reset_pos = self.fixed_start_xy.copy()
        point_obs, _ = point_env._get_obs()
        obs = unwrapped._get_obs(point_obs)
        info = dict(info)
        info["success"] = bool(np.linalg.norm(obs["achieved_goal"] - unwrapped.goal) <= 0.45)
        info["fixed_start_xy"] = self.fixed_start_xy.copy()
        info["fixed_start_cell"] = np.asarray(self.fixed_start_cell, dtype=np.int32)
        return obs, info


class SequentialWaypointPointMazeWrapper(gym.Wrapper):
    """Replace the default goal-reaching reward with ordered waypoint rewards."""

    def __init__(
        self,
        env: gym.Env,
        waypoint_cells: list[tuple[int, int]],
        waypoint_radius: float,
    ):
        super().__init__(env)
        unwrapped = self.unwrapped
        if not hasattr(unwrapped, "maze"):
            raise TypeError("SequentialWaypointPointMazeWrapper requires a PointMaze environment.")
        self.waypoint_cells = [(int(row), int(col)) for row, col in waypoint_cells]
        self.waypoint_radius = float(waypoint_radius)
        maze = unwrapped.maze
        self.waypoint_xy: list[np.ndarray] = []
        for row, col in self.waypoint_cells:
            if row < 0 or row >= int(maze.map_length) or col < 0 or col >= int(maze.map_width):
                raise ValueError(f"Waypoint cell {(row, col)!r} is outside the maze bounds.")
            if maze.maze_map[row][col] == 1:
                raise ValueError(f"Waypoint cell {(row, col)!r} points to a wall cell.")
            self.waypoint_xy.append(np.asarray(maze.cell_rowcol_to_xy((row, col)), dtype=np.float64)[:2].copy())
        self._next_waypoint_idx = 0
        self._num_completed = 0

    def _target_xy(self) -> np.ndarray:
        if self._next_waypoint_idx >= len(self.waypoint_xy):
            return self.waypoint_xy[-1].copy()
        return self.waypoint_xy[self._next_waypoint_idx].copy()

    def _augment_obs(self, obs: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
        obs = dict(obs)
        target_xy = self._target_xy().astype(np.float32)
        obs["desired_goal"] = target_xy.copy()
        return obs

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        self._next_waypoint_idx = 0
        self._num_completed = 0
        obs, info = self.env.reset(seed=seed, options=options)
        obs = self._augment_obs(obs)
        info = dict(info)
        info["success"] = False
        info["is_success"] = False
        info["waypoint_index"] = 0
        info["waypoint_count"] = len(self.waypoint_cells)
        info["waypoint_cells"] = np.asarray(self.waypoint_cells, dtype=np.int32)
        info["next_waypoint_cell"] = np.asarray(self.waypoint_cells[0], dtype=np.int32)
        info["completed_waypoints"] = 0
        return obs, info

    def step(self, action):
        obs, _, terminated, truncated, info = self.env.step(action)
        obs = self._augment_obs(obs)
        achieved_xy = np.asarray(obs["achieved_goal"], dtype=np.float64)
        reward = 0.0
        completed_all = False
        if self._next_waypoint_idx < len(self.waypoint_xy):
            target_xy = self.waypoint_xy[self._next_waypoint_idx]
            if np.linalg.norm(achieved_xy - target_xy) <= self.waypoint_radius:
                reward = 1.0
                self._next_waypoint_idx += 1
                self._num_completed = self._next_waypoint_idx
                completed_all = self._next_waypoint_idx >= len(self.waypoint_xy)
        info = dict(info)
        info["success"] = bool(completed_all)
        info["is_success"] = bool(completed_all)
        info["waypoint_index"] = int(min(self._next_waypoint_idx, len(self.waypoint_cells) - 1))
        info["waypoint_count"] = len(self.waypoint_cells)
        info["waypoint_cells"] = np.asarray(self.waypoint_cells, dtype=np.int32)
        info["completed_waypoints"] = int(self._num_completed)
        info["waypoint_reward"] = float(reward)
        if self._next_waypoint_idx < len(self.waypoint_cells):
            info["next_waypoint_cell"] = np.asarray(self.waypoint_cells[self._next_waypoint_idx], dtype=np.int32)
        else:
            info["next_waypoint_cell"] = np.asarray(self.waypoint_cells[-1], dtype=np.int32)
        return obs, float(reward), bool(completed_all), truncated, info


def build_goal_env(
    env_id: str,
    maze_map: list[list[int | str]] | None,
    seed: int,
    max_episode_steps: int,
    fixed_start_cell: tuple[int, int] | None,
    waypoint_cells: list[tuple[int, int]] | None = None,
    waypoint_radius: float = 0.45,
) -> gym.Env:
    """Create the ordered-waypoint PointMaze navigation task env."""
    normalized_waypoints = normalize_waypoint_cells(waypoint_cells)
    base_env = make_pointmaze_env(
        env_id,
        seed=seed,
        max_episode_steps=max_episode_steps,
        extra_kwargs={
            **({"maze_map": maze_map} if maze_map is not None else {}),
            "reward_type": "sparse",
            "continuing_task": True,
            "reset_target": False,
        },
    )
    if fixed_start_cell is not None:
        base_env = FixedStartPointMazeWrapper(base_env, fixed_start_cell=fixed_start_cell)
    return SequentialWaypointPointMazeWrapper(
        base_env,
        waypoint_cells=normalized_waypoints,
        waypoint_radius=float(waypoint_radius),
    )


def evaluate_model(
    model: SAC,
    env_id: str,
    n_eval_episodes: int,
    seed: int,
    max_episode_steps: int,
    maze_map: list[list[int | str]] | None,
    fixed_start_cell: tuple[int, int] | None,
    waypoint_cells: list[tuple[int, int]] | None = None,
    waypoint_radius: float = 0.45,
) -> tuple[float, float]:
    """Run deterministic evaluation episodes and return mean reward and success."""
    rewards: list[float] = []
    success: list[float] = []
    env = build_goal_env(
        env_id=env_id,
        maze_map=maze_map,
        seed=seed,
        max_episode_steps=max_episode_steps,
        fixed_start_cell=fixed_start_cell,
        waypoint_cells=waypoint_cells,
        waypoint_radius=waypoint_radius,
    )
    try:
        for episode_idx in range(n_eval_episodes):
            obs, _ = env.reset(seed=seed + episode_idx)
            terminated = truncated = False
            episode_reward = 0.0
            last_info: dict[str, object] = {}
            while not (terminated or truncated):
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = env.step(action)
                episode_reward += float(reward)
                last_info = info
            rewards.append(episode_reward)
            success.append(env_success_from_info(last_info, episode_reward))
    finally:
        env.close()
    return float(np.mean(rewards)), float(np.mean(success))


def moving_average(values: np.ndarray, window: int) -> np.ndarray:
    """Optionally smooth a 1D curve using a moving average."""
    if window <= 1 or values.size == 0:
        return values
    kernel = np.ones(int(window), dtype=np.float64) / float(window)
    return np.convolve(values, kernel, mode="same").astype(np.float32)


def aggregate_curves_on_timestep_grid(
    runs: list[tuple[np.ndarray, np.ndarray]],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Align reward curves on a shared timestep grid before aggregation."""
    prepared: list[tuple[np.ndarray, np.ndarray]] = []
    for timesteps, rewards in runs:
        steps = np.asarray(timesteps, dtype=np.int64).reshape(-1)
        vals = np.asarray(rewards, dtype=np.float32).reshape(-1)
        length = min(int(steps.size), int(vals.size))
        if length <= 0:
            continue
        steps = steps[:length]
        vals = vals[:length]
        order = np.argsort(steps, kind="stable")
        steps = steps[order]
        vals = vals[order]
        unique_steps, unique_indices = np.unique(steps, return_index=True)
        unique_vals = vals[unique_indices]
        prepared.append((unique_steps, unique_vals))
    if not prepared:
        raise ValueError("No evaluation curves were available for aggregation.")

    overlap_start = max(int(steps[0]) for steps, _ in prepared)
    overlap_end = min(int(steps[-1]) for steps, _ in prepared)
    if overlap_start <= overlap_end:
        grid = np.unique(
            np.concatenate(
                [steps[(steps >= overlap_start) & (steps <= overlap_end)] for steps, _ in prepared],
                axis=0,
            )
        )
    else:
        grid = np.unique(np.concatenate([steps for steps, _ in prepared], axis=0))

    if grid.size == 0:
        grid = np.asarray([prepared[0][0][0]], dtype=np.int64)

    stacked = np.empty((len(prepared), int(grid.size)), dtype=np.float32)
    for row_idx, (steps, vals) in enumerate(prepared):
        if steps.size == 1:
            stacked[row_idx, :] = np.float32(vals[0])
            continue
        stacked[row_idx, :] = np.interp(grid, steps.astype(np.float64), vals.astype(np.float64)).astype(np.float32)

    mean_rewards = stacked.mean(axis=0).astype(np.float32)
    std_rewards = stacked.std(axis=0).astype(np.float32)
    return grid.astype(np.int64), stacked, mean_rewards, std_rewards


def save_single_run_plots(run_dir: str, mode_label: str) -> dict[str, str | None]:
    """Create per-run reward and loss plots from saved arrays."""
    reward_plot_path = None
    train_curve_path = os.path.join(run_dir, "train_reward_curve.npz")
    if os.path.exists(train_curve_path):
        curves = np.load(train_curve_path)
        try:
            timesteps = np.asarray(curves["timesteps"])
            rewards = np.asarray(curves["rewards"])
        finally:
            curves.close()
        if timesteps.size and rewards.size:
            reward_plot_path = os.path.join(run_dir, "train_reward_curve.png")
            plt.figure(figsize=(7.0, 4.2))
            plt.plot(timesteps, rewards, color="tab:blue", linewidth=1.4)
            plt.xlabel("Environment Steps")
            plt.ylabel("Episode Reward")
            plt.title(f"{mode_label} Training Reward Curve")
            plt.grid(alpha=0.3)
            plt.tight_layout()
            plt.savefig(reward_plot_path, dpi=200, bbox_inches="tight")
            plt.close()

    loss_plot_path = None
    loss_curve_path = os.path.join(run_dir, "loss_curve.npz")
    if os.path.exists(loss_curve_path):
        curves = np.load(loss_curve_path)
        try:
            loss_steps = np.asarray(curves["timesteps"])
            critic_loss = np.asarray(curves["critic_loss"])
            actor_loss = np.asarray(curves["actor_loss"])
        finally:
            curves.close()
        if loss_steps.size:
            loss_plot_path = os.path.join(run_dir, "loss_curve.png")
            plt.figure(figsize=(7.0, 4.2))
            if np.any(~np.isnan(critic_loss)):
                plt.plot(loss_steps, critic_loss, color="tab:red", linewidth=1.4, label="Critic Loss")
            if np.any(~np.isnan(actor_loss)):
                plt.plot(loss_steps, actor_loss, color="tab:green", linewidth=1.4, label="Actor Loss")
            plt.xlabel("Environment Steps")
            plt.ylabel("Loss")
            plt.title(f"{mode_label} Loss Curve")
            plt.grid(alpha=0.3)
            plt.legend()
            plt.tight_layout()
            plt.savefig(loss_plot_path, dpi=200, bbox_inches="tight")
            plt.close()

    eval_plot_path = None
    eval_metrics_path = os.path.join(run_dir, "eval_metrics.npz")
    if os.path.exists(eval_metrics_path):
        curves = np.load(eval_metrics_path)
        try:
            eval_steps = np.asarray(curves["timesteps"])
            eval_rewards = np.asarray(curves["mean_rewards"])
        finally:
            curves.close()
        if eval_steps.size:
            eval_plot_path = os.path.join(run_dir, "eval_reward_curve.png")
            plt.figure(figsize=(7.0, 4.2))
            plt.plot(eval_steps, eval_rewards, color="tab:purple", linewidth=1.6)
            plt.xlabel("Environment Steps")
            plt.ylabel("Mean Eval Reward")
            plt.title(f"{mode_label} Evaluation Reward Curve")
            plt.grid(alpha=0.3)
            plt.tight_layout()
            plt.savefig(eval_plot_path, dpi=200, bbox_inches="tight")
            plt.close()
    return {"train_reward_plot": reward_plot_path, "loss_plot": loss_plot_path, "eval_reward_plot": eval_plot_path}


def train_single_run(
    *,
    args: argparse.Namespace,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    device: torch.device,
    root_save_dir: str,
    seed: int,
    fixed_start_cell: tuple[int, int] | None,
    method: MethodSpec,
) -> dict[str, object]:
    """Run one downstream job for one method and one seed."""
    set_global_seed(seed)
    waypoint_cells = normalize_waypoint_cells(getattr(args, "waypoint_cells", None))
    waypoint_radius = float(getattr(args, "waypoint_radius", 1.0))
    run_dir = ensure_dir(os.path.join(root_save_dir, method.mode_name, f"seed_{seed:03d}"))
    tensorboard_dir = None
    if args.tensorboard_log_dir:
        tensorboard_dir = ensure_dir(os.path.join(args.tensorboard_log_dir, method.mode_name, f"seed_{seed:03d}"))
    env = Monitor(
        build_goal_env(
            env_id,
            maze_map,
            seed,
            args.max_episode_steps,
            fixed_start_cell,
            waypoint_cells=waypoint_cells,
            waypoint_radius=waypoint_radius,
        )
    )

    effective_learning_starts = int(args.learning_starts)
    if not args.no_HER and effective_learning_starts <= int(args.max_episode_steps):
        effective_learning_starts = int(args.max_episode_steps) + 1

    model_kwargs = dict(
        policy="MultiInputPolicy",
        env=env,
        learning_rate=args.learning_rate,
        buffer_size=args.buffer_size,
        learning_starts=effective_learning_starts,
        batch_size=args.batch_size,
        gamma=args.gamma,
        tau=args.tau,
        gradient_steps=args.gradient_steps,
        seed=seed,
        device=str(device),
        tensorboard_log=tensorboard_dir,
        verbose=1,
        policy_kwargs=dict(net_arch=list(args.policy_hidden_dims)),
    )
    algorithm_cls = SAC
    if not args.no_HER:
        model_kwargs.update(
            replay_buffer_class=HerReplayBuffer,
            replay_buffer_kwargs=dict(
                n_sampled_goal=args.her_k,
                goal_selection_strategy="future",
                copy_info_dict=False,
            ),
        )
    if method.use_option_exploration:
        algorithm_cls = OptionInterventionSAC
        model_kwargs.update(
            option_bank=list(method.option_bank or []),
            option_trigger_prob=list(args.option_trigger_prob),
            option_max_steps=args.option_max_steps,
            option_termination_prob=args.option_termination_prob,
            option_deterministic=not args.option_stochastic,
            option_use_during_warmup=not args.disable_option_warmup,
            option_seed=seed,
        )

    model = algorithm_cls(**model_kwargs)
    callback = TrainingCurveCallback(
        env_id=env_id,
        eval_freq=args.eval_freq,
        n_eval_episodes=args.eval_episodes,
        seed=seed,
        max_episode_steps=args.max_episode_steps,
        maze_map=maze_map,
        fixed_start_cell=fixed_start_cell,
        waypoint_cells=waypoint_cells,
        waypoint_radius=waypoint_radius,
        eval_save_path=os.path.join(run_dir, "eval_metrics.npz"),
        train_curve_path=os.path.join(run_dir, "train_reward_curve.npz"),
        loss_curve_path=os.path.join(run_dir, "loss_curve.npz"),
        option_metrics_path=os.path.join(run_dir, "option_intervention_metrics.npz") if method.use_option_exploration else None,
        loss_record_freq=args.loss_record_freq,
    )
    model.learn(total_timesteps=args.total_timesteps, callback=callback, log_interval=10)
    final_reward, final_success = evaluate_model(
        model=model,
        env_id=env_id,
        n_eval_episodes=args.eval_episodes,
        seed=seed + 10_000,
        max_episode_steps=args.max_episode_steps,
        maze_map=maze_map,
        fixed_start_cell=fixed_start_cell,
        waypoint_cells=waypoint_cells,
        waypoint_radius=waypoint_radius,
    )
    model_path = os.path.join(run_dir, "pointmaze_sac_model")
    model.save(model_path)
    if hasattr(model, "save_replay_buffer"):
        model.save_replay_buffer(os.path.join(run_dir, "pointmaze_replay_buffer.pkl"))
    plot_paths = save_single_run_plots(run_dir, method.mode_label)
    run_summary = {
        "mode_name": method.mode_name,
        "mode_label": method.mode_label,
        "seed": int(seed),
        "device": str(device),
        "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
        "has_custom_maze": bool(args.using_custom_env),
        "fixed_start_cell": None if fixed_start_cell is None else [int(v) for v in fixed_start_cell],
        "waypoint_cells": [[int(row), int(col)] for row, col in waypoint_cells],
        "waypoint_radius": float(waypoint_radius),
        "effective_learning_starts": effective_learning_starts,
        "final_eval_reward": float(final_reward),
        "final_eval_success": float(final_success),
        "run_dir": run_dir,
        "model_path": model_path,
        "eval_metrics_path": os.path.join(run_dir, "eval_metrics.npz"),
        "train_reward_curve_path": os.path.join(run_dir, "train_reward_curve.npz"),
        "loss_curve_path": os.path.join(run_dir, "loss_curve.npz"),
        "option_metrics_path": os.path.join(run_dir, "option_intervention_metrics.npz") if method.use_option_exploration else None,
        "option_bank_dir": method.option_bank_dir,
        "plot_paths": plot_paths,
        "option_intervention_summary": model.get_option_intervention_summary() if hasattr(model, "get_option_intervention_summary") else None,
    }
    save_json(os.path.join(run_dir, "run_config.json"), {"args": vars(args), **run_summary})
    env.close()
    return run_summary


def plot_aggregated_reward_comparison(root_save_dir: str, run_summaries: list[dict[str, object]], smoothing_window: int) -> dict[str, str]:
    """Aggregate per-seed evaluation reward curves and save shaded comparison plots."""
    label_by_mode = {str(summary["mode_name"]): str(summary["mode_label"]) for summary in run_summaries}
    color_cycle = ["tab:blue", "tab:orange", "tab:green"]
    color_by_mode = {mode_name: color_cycle[idx % len(color_cycle)] for idx, mode_name in enumerate(label_by_mode)}
    grouped: dict[str, list[tuple[np.ndarray, np.ndarray]]] = {key: [] for key in label_by_mode}
    for summary in run_summaries:
        mode_name = str(summary["mode_name"])
        metrics = np.load(str(summary["eval_metrics_path"]))
        try:
            timesteps = np.asarray(metrics["timesteps"], dtype=np.int64)
            rewards = np.asarray(metrics["mean_rewards"], dtype=np.float32)
        finally:
            metrics.close()
        if timesteps.size and rewards.size:
            grouped[mode_name].append((timesteps, rewards))

    reward_plot_path = os.path.join(root_save_dir, "comparison_eval_reward_curve.png")
    aggregate_npz_path = os.path.join(root_save_dir, "comparison_eval_reward_curve.npz")
    plt.figure(figsize=(7.8, 4.8))
    payload: dict[str, np.ndarray] = {}
    for mode_name, runs in grouped.items():
        if not runs:
            continue
        common_timesteps, stacked, mu, sig = aggregate_curves_on_timestep_grid(runs)
        mu_plot = moving_average(mu, smoothing_window)
        sig_plot = moving_average(sig, smoothing_window)
        plt.plot(common_timesteps, mu_plot, color=color_by_mode[mode_name], linewidth=1.9, label=label_by_mode[mode_name])
        plt.fill_between(common_timesteps, mu_plot - sig_plot, mu_plot + sig_plot, color=color_by_mode[mode_name], alpha=0.15)
        payload[f"{mode_name}_timesteps"] = common_timesteps.astype(np.int64)
        payload[f"{mode_name}_mean_rewards"] = mu.astype(np.float32)
        payload[f"{mode_name}_std_rewards"] = sig.astype(np.float32)
        payload[f"{mode_name}_all_rewards"] = stacked.astype(np.float32)

    plt.xlabel("Environment Steps")
    plt.ylabel("Mean Eval Reward")
    plt.title("PointMaze Reward Comparison")
    plt.grid(alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(reward_plot_path, dpi=200, bbox_inches="tight")
    plt.close()
    np.savez_compressed(aggregate_npz_path, **payload)
    return {"reward_plot_path": reward_plot_path, "reward_npz_path": aggregate_npz_path}




def normalize_run_method(run_method: str) -> str:
    """Normalize legacy aliases and validate the requested method."""
    method = str(run_method).strip().lower()
    if method == "both":
        method = "all"
    valid = {"sac", "diayn", "vps", "all"}
    if method not in valid:
        raise ValueError(f"Unsupported `run_method={run_method}`. Choose one of {sorted(valid)}.")
    return method


def resolve_seed_specific_option_bank_dir(path: str, option_seed: int | None) -> str:
    """Resolve an option-bank path, optionally selecting the run with suffix `__seedN`."""
    resolved = resolve_optional_dir(path)
    if resolved is None:
        raise FileNotFoundError(f"Option bank path is empty: {path!r}")
    if option_seed is None:
        return resolve_option_bank_dir(resolved)

    basename = os.path.basename(os.path.abspath(resolved))
    if basename == "options" or extract_run_seed(resolved) is not None:
        selected_dir = resolve_option_bank_dir(resolved)
        selected_seed = extract_run_seed(os.path.dirname(selected_dir))
        if selected_seed is not None and selected_seed != int(option_seed):
            raise FileNotFoundError(
                f"Resolved option bank {selected_dir!r} has seed suffix {selected_seed}, "
                f"not the requested `__seed{option_seed}`."
            )
        return selected_dir

    matching_run_dirs: list[str] = []
    for child_name in os.listdir(resolved):
        child_path = os.path.join(resolved, child_name)
        if not os.path.isdir(child_path):
            continue
        if extract_run_seed(child_path) == int(option_seed):
            matching_run_dirs.append(child_path)
    if not matching_run_dirs:
        available_seeds = sorted(
            seed for seed in (extract_run_seed(os.path.join(resolved, child)) for child in os.listdir(resolved)) if seed is not None
        )
        raise FileNotFoundError(
            f"Could not find an option-bank run with suffix `__seed{option_seed}` under {resolved!r}. "
            f"Available seed suffixes: {available_seeds!r}"
        )
    selected_run_dir = max(matching_run_dirs, key=os.path.getmtime)
    return resolve_option_bank_dir(selected_run_dir)


class MetaControlOptionEnv(gym.Env):
    """Discrete high-level env that executes one selected skill/option until stop conditions."""

    metadata = {"render_modes": []}

    def __init__(
        self,
        base_env: gym.Env,
        *,
        option_bank: list,
        option_duration: int,
        option_deterministic: bool,
    ):
        super().__init__()
        if not option_bank:
            raise ValueError("`option_bank` must be non-empty when `--meta_control` is enabled.")
        self.base_env = base_env
        self.option_bank = list(option_bank)
        self.option_duration = max(int(option_duration), 1)
        self.option_deterministic = bool(option_deterministic)
        self.action_space = gym.spaces.Discrete(len(self.option_bank))
        self.observation_space = self.base_env.observation_space
        self._episode_primitive_steps = 0
        self._last_obs = None

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        self._episode_primitive_steps = 0
        obs, info = self.base_env.reset(seed=seed, options=options)
        self._last_obs = obs
        return obs, info

    def step(self, action: int):
        option_idx = int(action)
        if not (0 <= option_idx < len(self.option_bank)):
            raise IndexError(f"Meta-controller action {option_idx} is outside [0, {len(self.option_bank) - 1}]")
        option_entry = self.option_bank[option_idx]
        total_reward = 0.0
        terminated = False
        truncated = False
        last_info: dict[str, object] = {}
        primitive_steps = 0
        terminated_on_waypoint = False
        current_obs = self._last_obs
        if current_obs is None:
            raise RuntimeError("MetaControlOptionEnv.step() called before reset().")
        for _ in range(self.option_duration):
            low_level_obs = np.asarray(current_obs["observation"], dtype=np.float32)
            low_level_action, _ = option_entry.model.predict(
                low_level_obs,
                deterministic=self.option_deterministic,
            )
            current_obs, reward, terminated, truncated, info = self.base_env.step(low_level_action)
            total_reward += float(reward)
            primitive_steps += 1
            last_info = dict(info)
            if float(last_info.get("waypoint_reward", 0.0)) > 0.0:
                terminated_on_waypoint = True
                break
            if terminated or truncated:
                break

        self._episode_primitive_steps += int(primitive_steps)
        info = dict(last_info)
        info["meta_action"] = option_idx
        info["meta_option_name"] = str(option_entry.name)
        info["meta_primitive_steps"] = int(primitive_steps)
        info["meta_option_id"] = int(getattr(option_entry, "option_id", option_idx))
        info["meta_terminated_on_waypoint"] = bool(terminated_on_waypoint)
        if terminated or truncated:
            info["meta_episode_primitive_steps"] = int(self._episode_primitive_steps)
        self._last_obs = current_obs
        return current_obs, float(total_reward), terminated, truncated, info

    def render(self):
        return self.base_env.render()

    def close(self):
        self.base_env.close()


class MetaControlTrainingCallback(BaseCallback):
    """Track reward curves for meta-control runs using primitive environment steps."""

    def __init__(
        self,
        *,
        env_id: str,
        eval_freq: int,
        n_eval_episodes: int,
        seed: int,
        max_episode_steps: int,
        maze_map: list[list[int | str]] | None,
        fixed_start_cell: tuple[int, int] | None,
        waypoint_cells: list[tuple[int, int]],
        waypoint_radius: float,
        eval_save_path: str,
        train_curve_path: str,
        loss_curve_path: str,
        total_primitive_timesteps: int,
        option_bank: list,
        option_duration: int,
        option_deterministic: bool,
        loss_record_freq: int = 1_000,
    ):
        super().__init__(verbose=0)
        self.env_id = env_id
        self.eval_freq = max(int(eval_freq), 1)
        self.n_eval_episodes = max(int(n_eval_episodes), 1)
        self.seed = int(seed)
        self.max_episode_steps = int(max_episode_steps)
        self.maze_map = maze_map
        self.fixed_start_cell = fixed_start_cell
        self.waypoint_cells = [tuple(v) for v in waypoint_cells]
        self.waypoint_radius = float(waypoint_radius)
        self.eval_save_path = eval_save_path
        self.train_curve_path = train_curve_path
        self.loss_curve_path = loss_curve_path
        self.total_primitive_timesteps = max(int(total_primitive_timesteps), 1)
        self.option_bank = list(option_bank)
        self.option_duration = max(int(option_duration), 1)
        self.option_deterministic = bool(option_deterministic)
        self.loss_record_freq = max(int(loss_record_freq), 1)
        self.primitive_timesteps = 0
        self._last_eval_primitive_timestep = 0
        self._last_loss_record_timestep = -1
        self.eval_timesteps: list[int] = []
        self.mean_rewards: list[float] = []
        self.mean_success: list[float] = []
        self.train_episode_timesteps: list[int] = []
        self.train_episode_rewards: list[float] = []
        self.train_episode_lengths: list[int] = []
        self.loss_timesteps: list[int] = []
        self.dqn_losses: list[float] = []

    def _save_eval_arrays(self) -> None:
        np.savez_compressed(
            self.eval_save_path,
            timesteps=np.asarray(self.eval_timesteps, dtype=np.int64),
            mean_rewards=np.asarray(self.mean_rewards, dtype=np.float32),
            mean_success=np.asarray(self.mean_success, dtype=np.float32),
        )

    def _save_train_arrays(self) -> None:
        np.savez_compressed(
            self.train_curve_path,
            timesteps=np.asarray(self.train_episode_timesteps, dtype=np.int64),
            rewards=np.asarray(self.train_episode_rewards, dtype=np.float32),
            lengths=np.asarray(self.train_episode_lengths, dtype=np.int32),
        )

    def _save_loss_arrays(self) -> None:
        np.savez_compressed(
            self.loss_curve_path,
            timesteps=np.asarray(self.loss_timesteps, dtype=np.int64),
            dqn_loss=np.asarray(self.dqn_losses, dtype=np.float32),
        )

    def _record_episode_rewards(self, infos) -> None:
        if not isinstance(infos, (list, tuple)):
            return
        for info in infos:
            if not isinstance(info, dict):
                continue
            episode = info.get("episode")
            if not isinstance(episode, dict):
                continue
            self.train_episode_timesteps.append(int(self.primitive_timesteps))
            self.train_episode_rewards.append(float(episode.get("r", 0.0)))
            self.train_episode_lengths.append(int(info.get("meta_episode_primitive_steps", episode.get("l", 0))))
        if infos:
            self._save_train_arrays()

    def _maybe_record_loss(self) -> None:
        if self.primitive_timesteps == self._last_loss_record_timestep:
            return
        if self.primitive_timesteps % self.loss_record_freq != 0:
            return
        logger_values = getattr(self.model.logger, "name_to_value", {})
        dqn_loss = logger_values.get("train/loss")
        if dqn_loss is None:
            return
        self._last_loss_record_timestep = int(self.primitive_timesteps)
        self.loss_timesteps.append(int(self.primitive_timesteps))
        self.dqn_losses.append(float(dqn_loss))
        self._save_loss_arrays()

    def _maybe_eval(self) -> None:
        if self.primitive_timesteps <= 0:
            return
        if (self.primitive_timesteps - self._last_eval_primitive_timestep) < self.eval_freq and self.primitive_timesteps < self.total_primitive_timesteps:
            return
        mean_reward, mean_success = evaluate_meta_control_model(
            model=self.model,
            env_id=self.env_id,
            n_eval_episodes=self.n_eval_episodes,
            seed=self.seed + len(self.eval_timesteps) + 1,
            max_episode_steps=self.max_episode_steps,
            maze_map=self.maze_map,
            fixed_start_cell=self.fixed_start_cell,
            waypoint_cells=self.waypoint_cells,
            waypoint_radius=self.waypoint_radius,
            option_bank=self.option_bank,
            option_duration=self.option_duration,
            option_deterministic=self.option_deterministic,
        )
        self._last_eval_primitive_timestep = int(self.primitive_timesteps)
        self.eval_timesteps.append(int(self.primitive_timesteps))
        self.mean_rewards.append(float(mean_reward))
        self.mean_success.append(float(mean_success))
        self._save_eval_arrays()
        print(
            f"[MetaEval] primitive_steps={self.primitive_timesteps} "
            f"mean_reward={mean_reward:.3f} mean_success={mean_success:.3f}"
        )

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", [])
        primitive_increment = 0
        if isinstance(infos, (list, tuple)):
            for info in infos:
                if isinstance(info, dict):
                    primitive_increment += int(info.get("meta_primitive_steps", 0))
        self.primitive_timesteps += max(int(primitive_increment), 1)
        self._record_episode_rewards(infos)
        self._maybe_record_loss()
        self._maybe_eval()
        return self.primitive_timesteps < self.total_primitive_timesteps

    def _on_training_end(self) -> None:
        self._maybe_eval()
        self._save_eval_arrays()
        self._save_train_arrays()
        self._save_loss_arrays()


def evaluate_meta_control_model(
    *,
    model: DQN,
    env_id: str,
    n_eval_episodes: int,
    seed: int,
    max_episode_steps: int,
    maze_map: list[list[int | str]] | None,
    fixed_start_cell: tuple[int, int] | None,
    waypoint_cells: list[tuple[int, int]],
    waypoint_radius: float,
    option_bank: list,
    option_duration: int,
    option_deterministic: bool,
) -> tuple[float, float]:
    """Evaluate a high-level DQN controller over waypoint-terminated option executions."""
    rewards: list[float] = []
    success: list[float] = []
    env = MetaControlOptionEnv(
        build_goal_env(
            env_id=env_id,
            maze_map=maze_map,
            seed=seed,
            max_episode_steps=max_episode_steps,
            fixed_start_cell=fixed_start_cell,
            waypoint_cells=waypoint_cells,
            waypoint_radius=waypoint_radius,
        ),
        option_bank=option_bank,
        option_duration=option_duration,
        option_deterministic=option_deterministic,
    )
    try:
        for episode_idx in range(int(n_eval_episodes)):
            obs, _ = env.reset(seed=int(seed) + episode_idx)
            terminated = truncated = False
            episode_reward = 0.0
            last_info: dict[str, object] = {}
            while not (terminated or truncated):
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = env.step(action)
                episode_reward += float(reward)
                last_info = dict(info)
            rewards.append(float(episode_reward))
            success.append(env_success_from_info(last_info, episode_reward))
    finally:
        env.close()
    return float(np.mean(rewards)), float(np.mean(success))


def save_meta_control_run_plots(run_dir: str, mode_label: str) -> dict[str, str | None]:
    """Create simple reward/loss plots from a meta-control run."""
    plot_paths: dict[str, str | None] = {
        "train_reward_plot_path": None,
        "eval_reward_plot_path": None,
        "loss_plot_path": None,
    }
    train_curve_path = os.path.join(run_dir, "train_reward_curve.npz")
    if os.path.isfile(train_curve_path):
        payload = np.load(train_curve_path)
        try:
            timesteps = np.asarray(payload["timesteps"], dtype=np.int64)
            rewards = np.asarray(payload["rewards"], dtype=np.float32)
        finally:
            payload.close()
        if timesteps.size and rewards.size:
            plot_paths["train_reward_plot_path"] = os.path.join(run_dir, "train_reward_curve.png")
            plt.figure(figsize=(7.0, 4.2))
            plt.plot(timesteps, rewards, color="tab:blue", linewidth=1.4)
            plt.xlabel("Primitive Environment Steps")
            plt.ylabel("Episode Reward")
            plt.title(f"{mode_label} Training Reward Curve")
            plt.grid(alpha=0.3)
            plt.tight_layout()
            plt.savefig(plot_paths["train_reward_plot_path"], dpi=200, bbox_inches="tight")
            plt.close()

    eval_curve_path = os.path.join(run_dir, "eval_metrics.npz")
    if os.path.isfile(eval_curve_path):
        payload = np.load(eval_curve_path)
        try:
            timesteps = np.asarray(payload["timesteps"], dtype=np.int64)
            mean_rewards = np.asarray(payload["mean_rewards"], dtype=np.float32)
        finally:
            payload.close()
        if timesteps.size and mean_rewards.size:
            plot_paths["eval_reward_plot_path"] = os.path.join(run_dir, "eval_reward_curve.png")
            plt.figure(figsize=(7.0, 4.2))
            plt.plot(timesteps, mean_rewards, color="tab:orange", linewidth=1.6)
            plt.xlabel("Primitive Environment Steps")
            plt.ylabel("Mean Eval Reward")
            plt.title(f"{mode_label} Eval Reward Curve")
            plt.grid(alpha=0.3)
            plt.tight_layout()
            plt.savefig(plot_paths["eval_reward_plot_path"], dpi=200, bbox_inches="tight")
            plt.close()

    loss_curve_path = os.path.join(run_dir, "loss_curve.npz")
    if os.path.isfile(loss_curve_path):
        payload = np.load(loss_curve_path)
        try:
            timesteps = np.asarray(payload["timesteps"], dtype=np.int64)
            dqn_loss = np.asarray(payload["dqn_loss"], dtype=np.float32)
        finally:
            payload.close()
        if timesteps.size and dqn_loss.size:
            plot_paths["loss_plot_path"] = os.path.join(run_dir, "loss_curve.png")
            plt.figure(figsize=(7.0, 4.2))
            plt.plot(timesteps, dqn_loss, color="tab:green", linewidth=1.4)
            plt.xlabel("Primitive Environment Steps")
            plt.ylabel("DQN Loss")
            plt.title(f"{mode_label} DQN Loss Curve")
            plt.grid(alpha=0.3)
            plt.tight_layout()
            plt.savefig(plot_paths["loss_plot_path"], dpi=200, bbox_inches="tight")
            plt.close()

    return plot_paths


def train_single_run_meta_control(
    *,
    args: argparse.Namespace,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    device: torch.device,
    root_save_dir: str,
    seed: int,
    fixed_start_cell: tuple[int, int] | None,
    method: MethodSpec,
) -> dict[str, object]:
    """Run one downstream job with a high-level DQN selecting waypoint-terminated options."""
    set_global_seed(seed)
    waypoint_cells = normalize_waypoint_cells(getattr(args, "waypoint_cells", None))
    waypoint_radius = float(getattr(args, "waypoint_radius", 0.45))
    run_dir = ensure_dir(os.path.join(root_save_dir, method.mode_name, f"seed_{seed:03d}"))
    tensorboard_dir = None
    if args.tensorboard_log_dir:
        tensorboard_dir = ensure_dir(os.path.join(args.tensorboard_log_dir, method.mode_name, f"seed_{seed:03d}"))

    option_horizon = max(int(args.option_max_steps), 1)
    env = Monitor(
        MetaControlOptionEnv(
            build_goal_env(
                env_id,
                maze_map,
                seed,
                args.max_episode_steps,
                fixed_start_cell,
                waypoint_cells=waypoint_cells,
                waypoint_radius=waypoint_radius,
            ),
            option_bank=list(method.option_bank or []),
            option_duration=option_horizon,
            option_deterministic=not args.option_stochastic,
        )
    )
    meta_schedule_nominal_timesteps = max(1, int(math.ceil(float(args.total_timesteps) / float(option_horizon))))
    meta_total_timesteps = max(int(args.total_timesteps), meta_schedule_nominal_timesteps)
    meta_learning_starts = max(1, int(math.ceil(float(args.learning_starts) / float(option_horizon))))
    meta_exploration_fraction = float(args.meta_exploration_fraction) * (
        float(meta_schedule_nominal_timesteps) / float(meta_total_timesteps)
    )
    meta_exploration_fraction = min(max(meta_exploration_fraction, 1.0 / float(meta_total_timesteps)), 1.0)

    model = DQN(
        policy="MultiInputPolicy",
        env=env,
        learning_rate=args.learning_rate,
        buffer_size=args.buffer_size,
        learning_starts=meta_learning_starts,
        batch_size=args.batch_size,
        gamma=args.gamma,
        tau=args.tau,
        train_freq=(1, "step"),
        gradient_steps=args.gradient_steps,
        target_update_interval=int(args.meta_target_update_interval),
        exploration_fraction=meta_exploration_fraction,
        exploration_initial_eps=float(args.meta_exploration_initial_eps),
        exploration_final_eps=float(args.meta_exploration_final_eps),
        seed=seed,
        device=str(device),
        tensorboard_log=tensorboard_dir,
        verbose=1,
        policy_kwargs=dict(net_arch=list(args.policy_hidden_dims)),
    )
    callback = MetaControlTrainingCallback(
        env_id=env_id,
        eval_freq=args.eval_freq,
        n_eval_episodes=args.eval_episodes,
        seed=seed,
        max_episode_steps=args.max_episode_steps,
        maze_map=maze_map,
        fixed_start_cell=fixed_start_cell,
        waypoint_cells=waypoint_cells,
        waypoint_radius=waypoint_radius,
        eval_save_path=os.path.join(run_dir, "eval_metrics.npz"),
        train_curve_path=os.path.join(run_dir, "train_reward_curve.npz"),
        loss_curve_path=os.path.join(run_dir, "loss_curve.npz"),
        total_primitive_timesteps=args.total_timesteps,
        option_bank=list(method.option_bank or []),
        option_duration=option_horizon,
        option_deterministic=not args.option_stochastic,
        loss_record_freq=args.loss_record_freq,
    )
    model.learn(total_timesteps=meta_total_timesteps, callback=callback, log_interval=10)
    final_reward, final_success = evaluate_meta_control_model(
        model=model,
        env_id=env_id,
        n_eval_episodes=args.eval_episodes,
        seed=seed + 10_000,
        max_episode_steps=args.max_episode_steps,
        maze_map=maze_map,
        fixed_start_cell=fixed_start_cell,
        waypoint_cells=waypoint_cells,
        waypoint_radius=waypoint_radius,
        option_bank=list(method.option_bank or []),
        option_duration=option_horizon,
        option_deterministic=not args.option_stochastic,
    )
    model_path = os.path.join(run_dir, "pointmaze_meta_dqn_model")
    model.save(model_path)
    if hasattr(model, "save_replay_buffer"):
        model.save_replay_buffer(os.path.join(run_dir, "pointmaze_replay_buffer.pkl"))
    plot_paths = save_meta_control_run_plots(run_dir, method.mode_label)
    run_summary = {
        "mode_name": method.mode_name,
        "mode_label": method.mode_label,
        "seed": int(seed),
        "device": str(device),
        "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
        "has_custom_maze": bool(args.using_custom_env),
        "fixed_start_cell": None if fixed_start_cell is None else [int(v) for v in fixed_start_cell],
        "waypoint_cells": [[int(row), int(col)] for row, col in waypoint_cells],
        "waypoint_radius": float(waypoint_radius),
        "controller_type": "meta_control_dqn",
        "effective_learning_starts": meta_learning_starts,
        "meta_schedule_nominal_timesteps": meta_schedule_nominal_timesteps,
        "meta_total_timesteps": meta_total_timesteps,
        "primitive_total_timesteps": int(args.total_timesteps),
        "meta_exploration_fraction_effective": float(meta_exploration_fraction),
        "final_eval_reward": float(final_reward),
        "final_eval_success": float(final_success),
        "run_dir": run_dir,
        "model_path": model_path,
        "eval_metrics_path": os.path.join(run_dir, "eval_metrics.npz"),
        "train_reward_curve_path": os.path.join(run_dir, "train_reward_curve.npz"),
        "loss_curve_path": os.path.join(run_dir, "loss_curve.npz"),
        "option_bank_dir": method.option_bank_dir,
        "plot_paths": plot_paths,
        "meta_control": True,
        "meta_option_horizon": option_horizon,
        "num_options": len(method.option_bank or []),
    }
    save_json(os.path.join(run_dir, "run_config.json"), {"args": vars(args), **run_summary})
    env.close()
    return run_summary


def build_method_specs(args: argparse.Namespace, device: torch.device) -> tuple[list[MethodSpec], dict[str, str]]:
    """Build the requested set of downstream methods and lazily load option banks."""
    method_specs: list[MethodSpec] = []
    resolved_bank_dirs: dict[str, str] = {}

    if args.run_method in {"all", "sac"} and not bool(getattr(args, "skip_baseline", False)):
        method_specs.append(
            MethodSpec(
                mode_name="sac_baseline",
                mode_label="SAC",
                use_option_exploration=False,
            )
        )

    if args.run_method in {"all", "diayn"}:
        diayn_bank_dir = resolve_seed_specific_option_bank_dir(args.diayn_option_bank_dir, args.diayn_option_seed)
        resolved_bank_dirs["diayn"] = diayn_bank_dir
        method_specs.append(
            MethodSpec(
                mode_name="meta_diayn" if bool(args.meta_control) else "sac_diayn",
                mode_label="DoubleDQN+DIAYN" if bool(args.meta_control) else "SAC+DIAYN",
                use_option_exploration=not bool(args.meta_control),
                option_bank_dir=diayn_bank_dir,
                option_bank=load_option_bank(diayn_bank_dir, device=device),
                use_meta_control=bool(args.meta_control),
            )
        )

    if args.run_method in {"all", "vps"}:
        vps_bank_dir = resolve_seed_specific_option_bank_dir(args.vps_option_bank_dir, args.vps_option_seed)
        resolved_bank_dirs["vps"] = vps_bank_dir
        method_specs.append(
            MethodSpec(
                mode_name="meta_vps" if bool(args.meta_control) else "sac_vps",
                mode_label="DoubleDQN+VPS" if bool(args.meta_control) else "SAC+VPS",
                use_option_exploration=not bool(args.meta_control),
                option_bank_dir=vps_bank_dir,
                option_bank=load_option_bank(vps_bank_dir, device=device),
                use_meta_control=bool(args.meta_control),
            )
        )

    return method_specs, resolved_bank_dirs


def export_method_return_curves(
    *,
    root_save_dir: str,
    run_summaries: list[dict[str, object]],
    smoothing_window: int,
) -> dict[str, dict[str, str]]:
    """Export per-method return curves and raw arrays into timestamped folders."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    label_by_mode = {str(summary["mode_name"]): str(summary["mode_label"]) for summary in run_summaries}
    grouped: dict[str, list[tuple[np.ndarray, np.ndarray]]] = {key: [] for key in label_by_mode}
    for summary in run_summaries:
        mode_name = str(summary["mode_name"])
        metrics = np.load(str(summary["eval_metrics_path"]))
        try:
            timesteps = np.asarray(metrics["timesteps"], dtype=np.int64)
            rewards = np.asarray(metrics["mean_rewards"], dtype=np.float32)
        finally:
            metrics.close()
        if timesteps.size and rewards.size:
            grouped[mode_name].append((timesteps, rewards))

    display_dir_by_mode = {
        "sac_baseline": "SAC",
        "sac_diayn": "DIAYN",
        "sac_vps": "VPS",
        "meta_diayn": "DIAYN_META",
        "meta_vps": "VPS_META",
    }
    export_paths: dict[str, dict[str, str]] = {}
    return_curve_root = ensure_dir(os.path.join(root_save_dir, "return_curves"))

    for mode_name, runs in grouped.items():
        if not runs:
            continue
        common_timesteps, stacked, mu, sig = aggregate_curves_on_timestep_grid(runs)
        mu_plot = moving_average(mu, smoothing_window)
        sig_plot = moving_average(sig, smoothing_window)

        category_dir = ensure_dir(os.path.join(return_curve_root, display_dir_by_mode.get(mode_name, mode_name.upper())))
        png_path = os.path.join(category_dir, f"{timestamp}_{mode_name}_return_curve.png")
        npz_path = os.path.join(category_dir, f"{timestamp}_{mode_name}_return_curve.npz")

        plt.figure(figsize=(7.2, 4.6))
        plt.plot(common_timesteps, mu_plot, color="tab:blue", linewidth=1.9, label=label_by_mode[mode_name])
        plt.fill_between(common_timesteps, mu_plot - sig_plot, mu_plot + sig_plot, color="tab:blue", alpha=0.15)
        plt.xlabel("Environment Steps")
        plt.ylabel("Mean Eval Reward")
        plt.title(f"{label_by_mode[mode_name]} Return Curve")
        plt.grid(alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(png_path, dpi=200, bbox_inches="tight")
        plt.close()

        np.savez_compressed(
            npz_path,
            timesteps=common_timesteps.astype(np.int64),
            mean_rewards=mu.astype(np.float32),
            std_rewards=sig.astype(np.float32),
            smoothed_mean_rewards=mu_plot.astype(np.float32),
            smoothed_std_rewards=sig_plot.astype(np.float32),
            all_rewards=stacked.astype(np.float32),
        )
        export_paths[mode_name] = {"png_path": png_path, "npz_path": npz_path}

    return export_paths


def build_downstream_arg_parser() -> argparse.ArgumentParser:
    """Create a CLI for SAC with optional DIAYN/VPS exploration interventions."""
    parser = argparse.ArgumentParser(
        description=(
            "Run fixed-start, random-goal PointMaze with plain SAC, SAC+DIAYN skill "
            "intervention, SAC+VPS option intervention, or all three together."
        )
    )
    parser.add_argument(
        "--env_id",
        default=CUSTOM_POINTMAZE_ENV_ID,
        help=(
            "PointMaze environment selector. Use `custom` to load `--maze_json` "
            f"(default backend: `{DEFAULT_CUSTOM_POINTMAZE_BACKEND}`), or pass a "
            "registered env name such as `PointMaze_Large-v3`."
        ),
    )
    parser.add_argument(
        "--maze_json",
        default=os.path.join("maze_maps", "custom.json"),
        help="Path to a custom PointMaze `maze_map` JSON. Used only when `--env_id custom`.",
    )
    parser.add_argument("--seed", type=int, default=0, help="Base random seed.")
    parser.add_argument("--num_seeds", type=int, default=1, help="Number of downstream seeds to evaluate.")
    parser.add_argument("--seed_stride", type=int, default=1, help="Stride used to derive subsequent seeds from the base seed.")
    parser.add_argument("--device", default="auto", help="Torch device for downstream training.")
    parser.add_argument(
        "--save_dir",
        default="option_goal_reaching_results",
        help="Directory for checkpoints, curves, and aggregated reward plots.",
    )
    parser.add_argument("--tensorboard_log_dir", default=None, help="Optional TensorBoard log directory.")
    parser.add_argument("--max_episode_steps", type=int, default=1000, help="Fixed PointMaze episode horizon.")
    parser.add_argument(
        "--fixed_start_cell",
        type=int,
        nargs=2,
        metavar=("ROW", "COL"),
        default=[2, 2],
        help="Fixed PointMaze start cell as `(row col)` when `--random_init` is disabled.",
    )
    parser.add_argument(
        "--random_init",
        action="store_true",
        help="Use the environment's random initial position each episode instead of forcing `--fixed_start_cell`.",
    )
    parser.add_argument(
        "--waypoint_cells",
        type=int,
        nargs="+",
        default=DEFAULT_WAYPOINT_CELLS_FLAT,
        help=(
            "Exactly four ordered waypoint cells as `row col` pairs (flat list of 8 ints). "
            "Default: (4,2) -> (6,4) -> (4,6) -> (2,4); sparse +1 each, episode reward cap 4."
        ),
    )
    parser.add_argument(
        "--waypoint_radius",
        type=float,
        default=1.0,
        help="Distance threshold in maze XY coordinates for counting a waypoint as reached.",
    )
    parser.add_argument(
        "--diayn_option_bank_dir",
        default=os.path.join("pretrained_option_bank", "diayn"),
        help="DIAYN option-bank root, one run dir, or an `options` dir.",
    )
    parser.add_argument(
        "--diayn_option_seed",
        type=int,
        default=None,
        help="Optional `__seedN` suffix to select a specific DIAYN option-bank run when the path contains multiple runs.",
    )
    parser.add_argument(
        "--vps_option_bank_dir",
        default=os.path.join("pretrained_option_bank", "vps"),
        help="VPS option-bank root, one run dir, or an `options` dir.",
    )
    parser.add_argument(
        "--vps_option_seed",
        type=int,
        default=None,
        help="Optional `__seedN` suffix to select a specific VPS option-bank run when the path contains multiple runs.",
    )
    parser.add_argument(
        "--run_method",
        default="all",
        help="Which method to run: `sac`, `diayn`, `vps`, or `all`. `both` is accepted as an alias for `all`.",
    )

    parser.add_argument("--total_timesteps", type=int, default=500000, help="Primitive environment-step budget for downstream SAC training.")
    parser.add_argument("--learning_rate", type=float, default=1e-3, help="SAC learning rate.")
    parser.add_argument("--buffer_size", type=int, default=500000, help="Replay buffer capacity.")
    parser.add_argument("--learning_starts", type=int, default=1000, help="Delay learning until this many steps are collected.")
    parser.add_argument("--batch_size", type=int, default=256, help="Minibatch size.")
    parser.add_argument("--gamma", type=float, default=0.95, help="Discount factor.")
    parser.add_argument("--tau", type=float, default=0.005, help="Target-network update rate.")
    parser.add_argument("--gradient_steps", type=int, default=1, help="Gradient updates per rollout step.")
    parser.add_argument("--policy_hidden_dims", type=int, nargs="+", default=[256, 256], help="Hidden sizes for the SAC actor/critic MLPs.")
    parser.add_argument("--eval_freq", type=int, default=5000, help="Evaluate every N primitive environment steps.")
    parser.add_argument("--eval_episodes", type=int, default=5, help="Number of deterministic evaluation episodes.")
    parser.add_argument(
        "--option_trigger_prob",
        type=float,
        nargs=3,
        metavar=("INITIAL", "TERMINAL", "ANNEAL_STEPS"),
        default=[0.1, 0.005, 40000],
        help="Per-step option-trigger schedule: initial prob, terminal prob, anneal steps.",
    )
    parser.add_argument("--option_max_steps", type=int, default=500, help="Maximum primitive steps executed by one sampled DIAYN skill or VPS option.")
    parser.add_argument("--option_termination_prob", type=float, default=1.0 / 500.0, help="Per-step probability of terminating the active option early.")
    parser.add_argument("--option_stochastic", action="store_true", help="Use stochastic low-level option actions instead of deterministic ones.")
    parser.add_argument("--disable_option_warmup", action="store_true", help="Do not use pretrained skills/options before `learning_starts` is reached.")
    parser.add_argument(
        "--meta_control",
        action="store_true",
        help=(
            "Use a Double-DQN-style high-level controller for DIAYN skills or VPS options. "
            "When enabled, each discrete decision selects one skill/option, which is then "
            "executed for up to `option_max_steps` primitive steps, and terminates early "
            "when the current waypoint is reached or the episode ends."
        ),
    )
    parser.add_argument(
        "--meta_exploration_fraction",
        type=float,
        default=0.1,
        help="High-level DQN epsilon annealing fraction when `--meta_control` is enabled.",
    )
    parser.add_argument(
        "--meta_exploration_initial_eps",
        type=float,
        default=1.0,
        help="Initial epsilon for the high-level DQN when `--meta_control` is enabled.",
    )
    parser.add_argument(
        "--meta_exploration_final_eps",
        type=float,
        default=0.05,
        help="Final epsilon for the high-level DQN when `--meta_control` is enabled.",
    )
    parser.add_argument(
        "--meta_target_update_interval",
        type=int,
        default=1000,
        help="Target-network update interval for the high-level DQN when `--meta_control` is enabled.",
    )
    parser.add_argument("--loss_record_freq", type=int, default=1_000, help="Record actor/critic loss snapshots every N environment steps.")
    parser.add_argument("--reward_smoothing_window", type=int, default=1, help="Optional moving-average window for the aggregated reward plot.")
    parser.add_argument("--no_HER", action="store_true", help="Disable HER and use plain SAC.")
    parser.add_argument("--skip_baseline", action="store_true", help="Skip the plain SAC baseline when running multiple methods.")
    return parser


build_downstream_compare_arg_parser = build_downstream_arg_parser


def run_downstream_compare() -> None:
    """Run the requested downstream PointMaze comparison."""
    args = build_downstream_arg_parser().parse_args()
    args.no_HER = True
    args.her_k = 4
    args.skip_baseline = False
    args.run_method = normalize_run_method(args.run_method)
    device: torch.device = choose_device(args.device)
    args.requested_env_id = str(args.env_id)
    args.maze_json = resolve_optional_dir(args.maze_json)
    args.env_id, args.maze_json, maze_map, args.using_custom_env = resolve_pointmaze_env_selection(args.env_id, args.maze_json)
    save_dir = ensure_dir(resolve_optional_dir(args.save_dir) or args.save_dir)
    args.waypoint_cells = normalize_waypoint_cells(args.waypoint_cells)
    fixed_start_cell = None if bool(args.random_init) else (int(args.fixed_start_cell[0]), int(args.fixed_start_cell[1]))
    method_specs, resolved_bank_dirs = build_method_specs(args, device)
    for method_name, bank_dir in resolved_bank_dirs.items():
        resolved_seed = extract_run_seed(os.path.dirname(bank_dir))
        print(
            f"[PointMaze Goal] Loaded {method_name.upper()} option bank: "
            f"seed={resolved_seed if resolved_seed is not None else 'unknown'} dir={bank_dir}"
        )
    seeds = [int(args.seed + idx * args.seed_stride) for idx in range(int(args.num_seeds))]

    run_summaries: list[dict[str, object]] = []
    for seed in seeds:
        for method in method_specs:
            print(f"[PointMaze Goal] Starting method={method.mode_label} (mode_name={method.mode_name}) seed={seed}")
            train_fn = train_single_run_meta_control if bool(method.use_meta_control) else train_single_run
            run_summaries.append(
                train_fn(
                    args=args,
                    env_id=args.env_id,
                    maze_map=maze_map,
                    device=device,
                    root_save_dir=save_dir,
                    seed=seed,
                    fixed_start_cell=fixed_start_cell,
                    method=method,
                )
            )
            print(f"[PointMaze Goal] Finished method={method.mode_label} (mode_name={method.mode_name}) seed={seed}")

    aggregate_paths = plot_aggregated_reward_comparison(
        save_dir,
        run_summaries,
        smoothing_window=args.reward_smoothing_window,
    )
    return_curve_exports = export_method_return_curves(
        root_save_dir=save_dir,
        run_summaries=run_summaries,
        smoothing_window=args.reward_smoothing_window,
    )
    save_json(
        os.path.join(save_dir, "option_goal_reaching_summary.json"),
        {
            "args": vars(args),
            "env_id": args.env_id,
            "requested_env_id": args.requested_env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": bool(args.using_custom_env),
            "device": str(device),
            "fixed_start_cell": None if fixed_start_cell is None else [int(v) for v in fixed_start_cell],
            "random_init": bool(args.random_init),
            "waypoint_cells": [[int(row), int(col)] for row, col in args.waypoint_cells],
            "waypoint_radius": float(args.waypoint_radius),
            "seeds": seeds,
            "run_method": str(args.run_method),
            "methods": [method.mode_name for method in method_specs],
            "resolved_option_bank_dirs": resolved_bank_dirs,
            "aggregate_paths": aggregate_paths,
            "return_curve_exports": return_curve_exports,
            "runs": run_summaries,
        },
    )
    print(f"[PointMaze Goal] Completed run_method={args.run_method}. Outputs written to {save_dir}")

