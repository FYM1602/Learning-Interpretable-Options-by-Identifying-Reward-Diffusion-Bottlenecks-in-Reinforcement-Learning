from __future__ import annotations

import math
import os
from dataclasses import dataclass

import gymnasium as gym
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from matplotlib.lines import Line2D
from stable_baselines3 import SAC
from stable_baselines3.common.buffers import ReplayBuffer
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.preprocessing import get_flattened_obs_dim
from stable_baselines3.common.torch_layers import BaseFeaturesExtractor
from stable_baselines3.common.type_aliases import ReplayBufferSamples

try:
    from .option_training import (
        can_enable_gif_capture,
        configure_mujoco_gl_for_gif,
        maybe_start_virtual_display,
        save_gif,
        try_render_frame,
    )
    from .maze_plotting import aggregate_feature_grid, compute_extent, draw_maze_overlay, get_maze_plot_spec
    from .utils import PointMazeObsOnlyWrapper, ensure_dir, make_pointmaze_env, save_json
except ImportError:  # pragma: no cover
    from option_training import (
        can_enable_gif_capture,
        configure_mujoco_gl_for_gif,
        maybe_start_virtual_display,
        save_gif,
        try_render_frame,
    )
    from maze_plotting import aggregate_feature_grid, compute_extent, draw_maze_overlay, get_maze_plot_spec
    from utils import PointMazeObsOnlyWrapper, ensure_dir, make_pointmaze_env, save_json


@dataclass(frozen=True)
class DIAYNSkillSpec:
    """Metadata for one exported DIAYN skill."""

    option_id: int
    skill_idx: int

    @property
    def head_idx(self) -> int:
        return self.skill_idx

    @property
    def sign(self) -> int:
        return 1

    @property
    def name(self) -> str:
        return f"head{self.skill_idx:02d}_pos"


def build_mlp(input_dim: int, hidden_dims: tuple[int, ...], output_dim: int) -> nn.Sequential:
    """Create a small ReLU MLP."""
    layers: list[nn.Module] = []
    last_dim = int(input_dim)
    for hidden_dim in hidden_dims:
        linear = nn.Linear(last_dim, int(hidden_dim))
        nn.init.kaiming_normal_(linear.weight, nonlinearity="relu")
        nn.init.zeros_(linear.bias)
        layers.extend([linear, nn.ReLU()])
        last_dim = int(hidden_dim)
    output = nn.Linear(last_dim, int(output_dim))
    nn.init.xavier_uniform_(output.weight)
    nn.init.zeros_(output.bias)
    layers.append(output)
    return nn.Sequential(*layers)


class DIAYNDiscriminator(nn.Module):
    """Predict the active skill id from a PointMaze state."""

    def __init__(self, state_dim: int, num_skills: int, hidden_dims: tuple[int, ...] = (256, 256)):
        super().__init__()
        self.network = build_mlp(state_dim, hidden_dims, num_skills)

    def forward(self, states: torch.Tensor) -> torch.Tensor:
        return self.network(states)


class FixedSkillFeatureExtractor(BaseFeaturesExtractor):
    """Append a fixed one-hot skill vector to a 4-D PointMaze state."""

    def __init__(self, observation_space: gym.Space, num_skills: int, skill_idx: int):
        self.state_dim = int(get_flattened_obs_dim(observation_space))
        self.num_skills = int(num_skills)
        self.skill_idx = int(skill_idx)
        super().__init__(observation_space, features_dim=self.state_dim + self.num_skills)
        one_hot = np.zeros((self.num_skills,), dtype=np.float32)
        one_hot[self.skill_idx] = 1.0
        self.register_buffer("skill_one_hot", torch.as_tensor(one_hot, dtype=torch.float32).view(1, -1))

    def forward(self, observations: torch.Tensor) -> torch.Tensor:
        flat_obs = observations.float().view(observations.shape[0], -1)
        skill = self.skill_one_hot.expand(flat_obs.shape[0], -1)
        return torch.cat([flat_obs, skill], dim=1)


class DIAYNSkillWrapper(gym.Wrapper):
    """Sample or fix a skill id and expose [state, one-hot(skill)]."""

    def __init__(
        self,
        env: gym.Env,
        discriminator: DIAYNDiscriminator,
        num_skills: int,
        reward_scale: float = 1.0,
        device: torch.device | str = "cpu",
        fixed_skill_idx: int | None = None,
        seed: int = 0,
    ):
        super().__init__(env)
        base_space = env.observation_space
        if not isinstance(base_space, gym.spaces.Box):
            raise TypeError("DIAYNSkillWrapper expects a Box observation space.")
        self.state_dim = int(np.prod(base_space.shape))
        self.num_skills = int(num_skills)
        self.reward_scale = float(reward_scale)
        self.device = torch.device(device)
        self.discriminator = discriminator
        self.fixed_skill_idx = None if fixed_skill_idx is None else int(fixed_skill_idx)
        self.rng = np.random.default_rng(seed)
        self._active_skill_idx = 0

        low = np.concatenate(
            [
                np.asarray(base_space.low, dtype=np.float32).reshape(-1),
                np.zeros((self.num_skills,), dtype=np.float32),
            ]
        )
        high = np.concatenate(
            [
                np.asarray(base_space.high, dtype=np.float32).reshape(-1),
                np.ones((self.num_skills,), dtype=np.float32),
            ]
        )
        self.observation_space = gym.spaces.Box(low=low, high=high, dtype=np.float32)

    @property
    def active_skill_idx(self) -> int:
        return int(self._active_skill_idx)

    def _sample_skill_idx(self) -> int:
        if self.fixed_skill_idx is not None:
            return int(self.fixed_skill_idx)
        return int(self.rng.integers(self.num_skills))

    def _append_skill(self, obs: np.ndarray, skill_idx: int) -> np.ndarray:
        obs = np.asarray(obs, dtype=np.float32).reshape(-1)
        one_hot = np.zeros((self.num_skills,), dtype=np.float32)
        one_hot[int(skill_idx)] = 1.0
        return np.concatenate([obs, one_hot], axis=0).astype(np.float32)

    @torch.no_grad()
    def compute_intrinsic_reward(self, obs: np.ndarray, skill_idx: int) -> tuple[float, float]:
        state = np.asarray(obs, dtype=np.float32).reshape(1, -1)
        state_tensor = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        logits = self.discriminator(state_tensor)
        log_probs = F.log_softmax(logits, dim=-1)
        log_q = float(log_probs[0, int(skill_idx)].item())
        prior_log_prob = -math.log(float(self.num_skills))
        intrinsic_reward = self.reward_scale * (log_q - prior_log_prob)
        return float(intrinsic_reward), float(log_q)

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self._active_skill_idx = self._sample_skill_idx()
        info = dict(info)
        info["skill_idx"] = int(self._active_skill_idx)
        info["skill_one_hot"] = self._append_skill(np.zeros((self.state_dim,), dtype=np.float32), self._active_skill_idx)[
            self.state_dim :
        ].copy()
        return self._append_skill(obs, self._active_skill_idx), info

    def step(self, action):
        obs, extr_reward, terminated, truncated, info = self.env.step(action)
        intrinsic_reward, log_q = self.compute_intrinsic_reward(obs, self._active_skill_idx)
        info = dict(info)
        info["external_reward"] = float(extr_reward)
        info["intrinsic_reward"] = float(intrinsic_reward)
        info["diayn_log_q"] = float(log_q)
        info["skill_idx"] = int(self._active_skill_idx)
        return self._append_skill(obs, self._active_skill_idx), float(intrinsic_reward), terminated, truncated, info


class DIAYNReplayBuffer(ReplayBuffer):
    """Replay buffer that recomputes DIAYN rewards from current discriminator logits."""

    def __init__(
        self,
        *args,
        discriminator: DIAYNDiscriminator,
        state_dim: int,
        num_skills: int,
        reward_scale: float = 1.0,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.discriminator = discriminator
        self.state_dim = int(state_dim)
        self.num_skills = int(num_skills)
        self.reward_scale = float(reward_scale)
        self.prior_log_prob = -math.log(float(self.num_skills))

    @torch.no_grad()
    def _intrinsic_rewards(self, observations: torch.Tensor, next_observations: torch.Tensor) -> torch.Tensor:
        skill_idx = observations[:, self.state_dim :].argmax(dim=1)
        next_states = next_observations[:, : self.state_dim]
        disc_device = next(self.discriminator.parameters()).device
        logits = self.discriminator(next_states.to(disc_device))
        log_probs = F.log_softmax(logits, dim=-1)
        rewards = log_probs.gather(1, skill_idx.to(disc_device).unsqueeze(1)) - self.prior_log_prob
        rewards = rewards * self.reward_scale
        return rewards.to(next_observations.device).float()

    def sample(self, batch_size: int, env=None) -> ReplayBufferSamples:
        samples = super().sample(batch_size=batch_size, env=env)
        rewards = self._intrinsic_rewards(samples.observations, samples.next_observations)
        return ReplayBufferSamples(
            observations=samples.observations,
            actions=samples.actions,
            next_observations=samples.next_observations,
            dones=samples.dones,
            rewards=rewards,
        )


class DIAYNTrainingCallback(BaseCallback):
    """Update the discriminator online and save training diagnostics."""

    def __init__(
        self,
        discriminator: DIAYNDiscriminator,
        discriminator_optimizer: torch.optim.Optimizer,
        state_dim: int,
        num_skills: int,
        batch_size: int,
        update_freq: int,
        updates_per_step: int,
        metrics_save_path: str,
    ):
        super().__init__(verbose=0)
        self.discriminator = discriminator
        self.discriminator_optimizer = discriminator_optimizer
        self.state_dim = int(state_dim)
        self.num_skills = int(num_skills)
        self.batch_size = int(batch_size)
        self.update_freq = max(int(update_freq), 1)
        self.updates_per_step = max(int(updates_per_step), 1)
        self.metrics_save_path = metrics_save_path

        self.timesteps: list[int] = []
        self.discriminator_losses: list[float] = []
        self.discriminator_accuracy: list[float] = []
        self.mean_log_q: list[float] = []
        self.train_episode_timesteps: list[int] = []
        self.train_episode_rewards: list[float] = []
        self.train_episode_lengths: list[int] = []

    def _save_metrics(self) -> None:
        np.savez_compressed(
            self.metrics_save_path,
            timesteps=np.asarray(self.timesteps, dtype=np.int64),
            discriminator_loss=np.asarray(self.discriminator_losses, dtype=np.float32),
            discriminator_accuracy=np.asarray(self.discriminator_accuracy, dtype=np.float32),
            mean_log_q=np.asarray(self.mean_log_q, dtype=np.float32),
            train_episode_timesteps=np.asarray(self.train_episode_timesteps, dtype=np.int64),
            train_episode_rewards=np.asarray(self.train_episode_rewards, dtype=np.float32),
            train_episode_lengths=np.asarray(self.train_episode_lengths, dtype=np.int32),
        )

    def _record_episode_stats(self) -> None:
        infos = self.locals.get("infos", [])
        if not isinstance(infos, (list, tuple)):
            return
        for info in infos:
            if not isinstance(info, dict):
                continue
            episode = info.get("episode")
            if not isinstance(episode, dict):
                continue
            self.train_episode_timesteps.append(int(self.num_timesteps))
            self.train_episode_rewards.append(float(episode.get("r", 0.0)))
            self.train_episode_lengths.append(int(episode.get("l", 0)))

    def _train_discriminator_step(self) -> tuple[float, float, float] | None:
        replay_buffer = getattr(self.model, "replay_buffer", None)
        if replay_buffer is None or replay_buffer.size() < self.batch_size:
            return None
        samples = replay_buffer.sample(self.batch_size)
        next_states = samples.next_observations[:, : self.state_dim]
        skill_idx = samples.observations[:, self.state_dim :].argmax(dim=1)
        logits = self.discriminator(next_states)
        loss = F.cross_entropy(logits, skill_idx)
        self.discriminator_optimizer.zero_grad()
        loss.backward()
        self.discriminator_optimizer.step()

        with torch.no_grad():
            log_probs = F.log_softmax(logits, dim=-1)
            mean_log_q = float(log_probs.gather(1, skill_idx.unsqueeze(1)).mean().item())
            accuracy = float((logits.argmax(dim=1) == skill_idx).float().mean().item())
        return float(loss.item()), accuracy, mean_log_q

    def _on_step(self) -> bool:
        self._record_episode_stats()
        if self.num_timesteps % self.update_freq != 0:
            self._save_metrics()
            return True

        stats: list[tuple[float, float, float]] = []
        for _ in range(self.updates_per_step):
            result = self._train_discriminator_step()
            if result is not None:
                stats.append(result)
        if stats:
            loss = float(np.mean([value[0] for value in stats]))
            accuracy = float(np.mean([value[1] for value in stats]))
            mean_log_q = float(np.mean([value[2] for value in stats]))
            self.timesteps.append(int(self.num_timesteps))
            self.discriminator_losses.append(loss)
            self.discriminator_accuracy.append(accuracy)
            self.mean_log_q.append(mean_log_q)
            self.logger.record("diayn/discriminator_loss", loss)
            self.logger.record("diayn/discriminator_accuracy", accuracy)
            self.logger.record("diayn/mean_log_q", mean_log_q)
        self._save_metrics()
        return True

    def _on_training_end(self) -> None:
        self._save_metrics()


def make_plain_pointmaze_env(
    *,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    max_episode_steps: int,
    seed: int,
    render_mode: str | None = None,
    monitor: bool = True,
) -> gym.Env:
    """Create a PointMaze env exposing only the 4-D observation vector."""
    extra_kwargs = {"continuing_task": True}
    if maze_map is not None:
        extra_kwargs["maze_map"] = maze_map
    env = make_pointmaze_env(
        env_id=env_id,
        seed=seed,
        render_mode=render_mode,
        max_episode_steps=max_episode_steps,
        extra_kwargs=extra_kwargs,
    )
    env = PointMazeObsOnlyWrapper(env)
    if monitor:
        env = Monitor(env)
    return env


def make_skill_conditioned_env(
    *,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    max_episode_steps: int,
    seed: int,
    discriminator: DIAYNDiscriminator,
    num_skills: int,
    reward_scale: float,
    device: torch.device,
    fixed_skill_idx: int | None = None,
    render_mode: str | None = None,
    monitor: bool = True,
) -> gym.Env:
    """Create a PointMaze DIAYN env with a sampled or fixed skill."""
    env = make_plain_pointmaze_env(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=max_episode_steps,
        seed=seed,
        render_mode=render_mode,
        monitor=False,
    )
    env = DIAYNSkillWrapper(
        env=env,
        discriminator=discriminator,
        num_skills=num_skills,
        reward_scale=reward_scale,
        device=device,
        fixed_skill_idx=fixed_skill_idx,
        seed=seed,
    )
    if monitor:
        env = Monitor(env)
    return env


def train_diayn_model(
    *,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    num_skills: int,
    max_episode_steps: int,
    seed: int,
    device: torch.device,
    total_timesteps: int,
    learning_rate: float,
    buffer_size: int,
    learning_starts: int,
    batch_size: int,
    gamma: float,
    tau: float,
    gradient_steps: int,
    policy_hidden_dims: tuple[int, ...],
    discriminator_hidden_dims: tuple[int, ...],
    discriminator_learning_rate: float,
    discriminator_batch_size: int,
    discriminator_update_freq: int,
    discriminator_updates_per_step: int,
    reward_scale: float,
    save_dir: str,
) -> tuple[SAC, DIAYNDiscriminator, str, str]:
    """Train one joint DIAYN SAC model and save checkpoints."""
    probe_env = make_plain_pointmaze_env(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=max_episode_steps,
        seed=seed,
        monitor=False,
    )
    try:
        state_dim = int(np.prod(probe_env.observation_space.shape))
    finally:
        probe_env.close()

    discriminator = DIAYNDiscriminator(
        state_dim=state_dim,
        num_skills=num_skills,
        hidden_dims=tuple(int(v) for v in discriminator_hidden_dims),
    ).to(device)
    discriminator_optimizer = torch.optim.Adam(discriminator.parameters(), lr=discriminator_learning_rate)

    env = make_skill_conditioned_env(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=max_episode_steps,
        seed=seed,
        discriminator=discriminator,
        num_skills=num_skills,
        reward_scale=reward_scale,
        device=device,
        monitor=True,
    )

    replay_buffer_kwargs = dict(
        discriminator=discriminator,
        state_dim=state_dim,
        num_skills=num_skills,
        reward_scale=reward_scale,
    )
    model = SAC(
        policy="MlpPolicy",
        env=env,
        learning_rate=learning_rate,
        buffer_size=buffer_size,
        learning_starts=learning_starts,
        batch_size=batch_size,
        gamma=gamma,
        tau=tau,
        gradient_steps=gradient_steps,
        seed=seed,
        device=str(device),
        verbose=1,
        policy_kwargs=dict(net_arch=list(policy_hidden_dims)),
        replay_buffer_class=DIAYNReplayBuffer,
        replay_buffer_kwargs=replay_buffer_kwargs,
    )
    metrics_path = os.path.join(save_dir, "diayn_training_metrics.npz")
    callback = DIAYNTrainingCallback(
        discriminator=discriminator,
        discriminator_optimizer=discriminator_optimizer,
        state_dim=state_dim,
        num_skills=num_skills,
        batch_size=discriminator_batch_size,
        update_freq=discriminator_update_freq,
        updates_per_step=discriminator_updates_per_step,
        metrics_save_path=metrics_path,
    )
    model.learn(total_timesteps=int(total_timesteps), callback=callback, log_interval=10)

    joint_model_path = os.path.join(save_dir, "pointmaze_diayn_joint_model")
    model.save(joint_model_path)
    checkpoint_path = os.path.join(save_dir, "pointmaze_diayn_discriminator.pt")
    with open(checkpoint_path, "wb") as f:
        torch.save(
            {
                "discriminator": discriminator.state_dict(),
                "state_dim": state_dim,
                "num_skills": num_skills,
                "reward_scale": reward_scale,
                "policy_hidden_dims": list(policy_hidden_dims),
                "discriminator_hidden_dims": list(discriminator_hidden_dims),
                "seed": seed,
                "maze_map": maze_map,
            },
            f,
        )
    env.close()
    return model, discriminator, joint_model_path, checkpoint_path


def export_skill_model(
    *,
    joint_model: SAC,
    skill_spec: DIAYNSkillSpec,
    num_skills: int,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    max_episode_steps: int,
    seed: int,
    device: torch.device,
    policy_hidden_dims: tuple[int, ...],
) -> SAC:
    """Create a plain-observation SAC model with a fixed latent skill appended internally."""
    env = make_plain_pointmaze_env(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=max_episode_steps,
        seed=seed,
        monitor=False,
    )
    exported_model = SAC(
        policy="MlpPolicy",
        env=env,
        learning_rate=1e-3,
        buffer_size=2,
        learning_starts=1,
        batch_size=1,
        gamma=0.99,
        tau=0.005,
        gradient_steps=1,
        seed=seed,
        device=str(device),
        verbose=0,
        policy_kwargs=dict(
            net_arch=list(policy_hidden_dims),
            features_extractor_class=FixedSkillFeatureExtractor,
            features_extractor_kwargs={
                "num_skills": int(num_skills),
                "skill_idx": int(skill_spec.skill_idx),
            },
        ),
    )
    exported_model.policy.load_state_dict(joint_model.policy.state_dict(), strict=False)
    if hasattr(joint_model, "log_ent_coef") and getattr(joint_model, "log_ent_coef", None) is not None:
        exported_model.log_ent_coef = joint_model.log_ent_coef.detach().clone().requires_grad_(False)
    exported_model.num_timesteps = int(getattr(joint_model, "num_timesteps", 0))
    env.close()
    return exported_model


@torch.no_grad()
def compute_diayn_reward(
    discriminator: DIAYNDiscriminator,
    next_state: np.ndarray,
    skill_idx: int,
    num_skills: int,
    reward_scale: float,
    device: torch.device,
) -> tuple[float, float]:
    """Compute intrinsic DIAYN reward on a plain PointMaze state."""
    state_tensor = torch.as_tensor(np.asarray(next_state, dtype=np.float32).reshape(1, -1), device=device)
    logits = discriminator(state_tensor)
    log_probs = F.log_softmax(logits, dim=-1)
    log_q = float(log_probs[0, int(skill_idx)].item())
    intrinsic_reward = float(reward_scale * (log_q + math.log(float(num_skills))))
    return intrinsic_reward, log_q


def evaluate_exported_skill(
    *,
    model: SAC,
    discriminator: DIAYNDiscriminator,
    skill_spec: DIAYNSkillSpec,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    max_episode_steps: int,
    seed: int,
    eval_episodes: int,
    reward_scale: float,
    device: torch.device,
    gif_enabled: bool,
    gif_path: str | None = None,
    gif_max_steps: int = 600,
    gif_fps: int = 10,
    gif_stop_on_done: bool = False,
) -> tuple[dict[str, float | list[float]], list[np.ndarray]]:
    """Run deterministic rollouts for one exported skill."""
    env = make_plain_pointmaze_env(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=max_episode_steps,
        seed=seed,
        monitor=False,
    )
    trajectories: list[np.ndarray] = []
    intrinsic_rewards: list[float] = []
    mean_log_qs: list[float] = []
    episode_lengths: list[int] = []
    endpoints: list[np.ndarray] = []
    try:
        for episode_idx in range(int(eval_episodes)):
            obs, _ = env.reset(seed=seed + episode_idx)
            done = False
            total_reward = 0.0
            step_log_q: list[float] = []
            states = [np.asarray(obs, dtype=np.float32).copy()]
            while not done:
                action, _ = model.predict(obs, deterministic=True)
                next_obs, _, terminated, truncated, _ = env.step(action)
                intrinsic_reward, log_q = compute_diayn_reward(
                    discriminator=discriminator,
                    next_state=next_obs,
                    skill_idx=skill_spec.skill_idx,
                    num_skills=int(discriminator.network[-1].out_features),
                    reward_scale=reward_scale,
                    device=device,
                )
                total_reward += float(intrinsic_reward)
                step_log_q.append(float(log_q))
                obs = np.asarray(next_obs, dtype=np.float32)
                states.append(obs.copy())
                done = bool(terminated or truncated)
            trajectory = np.asarray(states, dtype=np.float32)
            trajectories.append(trajectory)
            intrinsic_rewards.append(total_reward)
            mean_log_qs.append(float(np.mean(step_log_q)) if step_log_q else 0.0)
            episode_lengths.append(int(len(states) - 1))
            endpoints.append(np.asarray(states[-1][:2], dtype=np.float32))
    finally:
        env.close()

    if gif_enabled and gif_path is not None:
        render_env = make_plain_pointmaze_env(
            env_id=env_id,
            maze_map=maze_map,
            max_episode_steps=max_episode_steps,
            seed=seed,
            render_mode="rgb_array",
            monitor=False,
        )
        frames: list[np.ndarray] = []
        gif_active = True
        try:
            obs, _ = render_env.reset(seed=seed)
            frame, gif_active = try_render_frame(render_env, gif_active)
            if isinstance(frame, np.ndarray):
                frames.append(frame.copy())
            for _ in range(int(gif_max_steps)):
                action, _ = model.predict(obs, deterministic=True)
                obs, _, terminated, truncated, _ = render_env.step(action)
                frame, gif_active = try_render_frame(render_env, gif_active)
                if isinstance(frame, np.ndarray):
                    frames.append(frame.copy())
                if terminated or truncated:
                    if gif_stop_on_done:
                        break
                    obs, _ = render_env.reset()
                    frame, gif_active = try_render_frame(render_env, gif_active)
                    if isinstance(frame, np.ndarray):
                        frames.append(frame.copy())
                if not gif_active or len(frames) >= int(gif_max_steps) + 1:
                    break
        finally:
            render_env.close()
        if len(frames) > 1:
            save_gif(frames, gif_path, gif_fps)

    summary = {
        "mean_intrinsic_reward": float(np.mean(intrinsic_rewards)) if intrinsic_rewards else 0.0,
        "mean_log_q": float(np.mean(mean_log_qs)) if mean_log_qs else 0.0,
        "mean_episode_length": float(np.mean(episode_lengths)) if episode_lengths else 0.0,
        "episode_intrinsic_rewards": [float(v) for v in intrinsic_rewards],
        "episode_mean_log_q": [float(v) for v in mean_log_qs],
        "episode_lengths": [int(v) for v in episode_lengths],
        "endpoints_xy": np.asarray(endpoints, dtype=np.float32).tolist(),
    }
    return summary, trajectories


def plot_skill_trajectories(
    *,
    trajectories: list[np.ndarray],
    env_id: str,
    maze_map: list[list[int | str]] | None,
    save_path: str,
    title: str,
) -> str:
    """Plot rollout trajectories for one skill."""
    save_path = os.path.abspath(save_path)
    all_states = np.concatenate(trajectories, axis=0)
    states_xy = np.asarray(all_states[:, :2], dtype=np.float64)
    maze_map, known_extent = get_maze_plot_spec(env_id, maze_map=maze_map)
    extent = known_extent if known_extent is not None else compute_extent(states_xy, env_id, maze_map)

    plt.figure(figsize=(5.2, 4.8))
    ax = plt.gca()
    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    draw_maze_overlay(ax, maze_map, extent)
    for trajectory in trajectories:
        xy = np.asarray(trajectory[:, :2], dtype=np.float64)
        line, = ax.plot(xy[:, 0], xy[:, 1], linewidth=1.6, alpha=0.85)
        color = line.get_color()
        ax.scatter(xy[0, 0], xy[0, 1], s=18, marker="o", color=color)
        ax.scatter(xy[-1, 0], xy[-1, 1], s=28, marker="x", color=color)
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.grid(alpha=0.2)
    legend_handles = [
        Line2D([0], [0], color="black", linewidth=1.6, label="Rollout"),
        Line2D([0], [0], marker="o", color="black", linestyle="None", markersize=6, label="Start"),
        Line2D([0], [0], marker="x", color="black", linestyle="None", markersize=7, label="End"),
    ]
    ax.legend(handles=legend_handles, loc="best")
    plt.tight_layout()
    plt.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close()
    return save_path


def plot_skill_occupancy(
    *,
    trajectories: list[np.ndarray],
    env_id: str,
    maze_map: list[list[int | str]] | None,
    projection_mode: str,
    bins: int,
    save_path: str,
    title: str,
) -> str:
    """Plot a DIAYN occupancy heatmap for one skill."""
    save_path = os.path.abspath(save_path)
    all_states = np.concatenate(trajectories, axis=0)
    states_xy = np.asarray(all_states[:, :2], dtype=np.float64)
    feature_values = np.ones((states_xy.shape[0],), dtype=np.float64)
    maze_map, known_extent = get_maze_plot_spec(env_id, maze_map=maze_map)
    extent = known_extent if known_extent is not None else compute_extent(states_xy, env_id, maze_map)
    occupancy = aggregate_feature_grid(
        states_xy=states_xy,
        feature_values=feature_values,
        env_id=env_id,
        maze_map=maze_map,
        bins=bins,
        extent=extent,
        projection_mode=projection_mode,
    )

    plt.figure(figsize=(5.2, 4.8))
    ax = plt.gca()
    image = ax.imshow(
        occupancy,
        origin="lower",
        extent=extent,
        cmap="magma",
        aspect="equal",
    )
    draw_maze_overlay(ax, maze_map, extent)
    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    plt.colorbar(image, ax=ax, fraction=0.046, pad=0.04, label="occupancy")
    plt.tight_layout()
    plt.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close()
    return save_path


def save_skill_eval_metrics(path: str, summary: dict[str, float | list[float]]) -> str:
    """Persist skill evaluation arrays as an `.npz` file."""
    payload = {
        "episode_intrinsic_rewards": np.asarray(summary["episode_intrinsic_rewards"], dtype=np.float32),
        "episode_mean_log_q": np.asarray(summary["episode_mean_log_q"], dtype=np.float32),
        "episode_lengths": np.asarray(summary["episode_lengths"], dtype=np.int32),
        "endpoints_xy": np.asarray(summary["endpoints_xy"], dtype=np.float32),
    }
    np.savez_compressed(path, **payload)
    return os.path.abspath(path)


def prepare_gif_capture(args) -> bool:
    """Set up optional GIF capture using the same helpers as VPS option training."""
    maybe_start_virtual_display(args)
    configure_mujoco_gl_for_gif(args)
    return bool(args.gif_freq > 0 and can_enable_gif_capture())


def save_diayn_run_summary(path: str, payload: dict) -> str:
    """Save a stable JSON summary and return its absolute path."""
    save_json(path, payload)
    return os.path.abspath(path)
