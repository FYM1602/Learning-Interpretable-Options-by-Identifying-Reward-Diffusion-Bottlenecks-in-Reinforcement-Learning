"""
CLI: ``python -m point_maze_vps pretrain|downstream|plot ...``

Run from the repository root (`vps_option_discovery`).
"""

from __future__ import annotations

import argparse
import sys


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="point_maze_vps",
        description="PointMaze VPS / DIAYN pretraining and downstream waypoint navigation",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND", required=True)

    pre = sub.add_parser("pretrain", help="Pretrain VPS options or DIAYN skills")
    pre_sub = pre.add_subparsers(dest="method", metavar="METHOD", required=True)
    pre_sub.add_parser("vps", help="Random walk + RFF Value/VPS + SAC options")
    pre_sub.add_parser("diayn", help="DIAYN skill discovery")

    down = sub.add_parser("downstream", help="Downstream SAC comparison on four waypoints")
    down_sub = down.add_subparsers(dest="down_cmd", metavar="CMD", required=True)
    down_sub.add_parser("compare", help="SAC vs SAC+DIAYN vs SAC+VPS reward curves")

    plot = sub.add_parser("plot", help="Figures and curve aggregation")
    plot_sub = plot.add_subparsers(dest="plot_cmd", metavar="PLOT_CMD", required=True)
    plot_sub.add_parser("heatmaps", help="V/phi spatial heatmaps")
    pr = plot_sub.add_parser("rollouts", help="Fixed-length rollout trajectories")
    pr_sub = pr.add_subparsers(dest="rollout_kind", metavar="KIND", required=True)
    pr_sub.add_parser("vps", help="VPS option rollouts")
    pr_sub.add_parser("diayn", help="DIAYN skill rollouts")
    plot_sub.add_parser("aggregate-curves", help="Aggregate return_curves/ across seeds")

    return parser


def main(argv: list[str] | None = None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        build_parser().print_help()
        return

    cmd = argv[0]
    rest = argv[1:]

    if cmd == "pretrain":
        if not rest or rest[0] not in ("vps", "diayn"):
            build_parser().parse_args([cmd, "--help"])
            return
        from .pipeline import main as pipeline_main

        old = sys.argv
        try:
            sys.argv = ["point_maze_vps", "--method", rest[0], *rest[1:]]
            pipeline_main()
        finally:
            sys.argv = old
    elif cmd == "downstream":
        if not rest or rest[0] != "compare":
            build_parser().parse_args([cmd, "--help"])
            return
        run_downstream_compare_with_argv(rest[1:])
    elif cmd == "plot":
        if not rest:
            build_parser().parse_args([cmd, "--help"])
            return
        plot_cmd = rest[0]
        plot_rest = rest[1:]
        from . import plotting as plt_mod

        if plot_cmd == "heatmaps":
            plt_mod.run_heatmaps(plot_rest)
        elif plot_cmd == "rollouts":
            if not plot_rest or plot_rest[0] not in ("vps", "diayn"):
                build_parser().parse_args([cmd, plot_cmd, "--help"])
                return
            if plot_rest[0] == "vps":
                plt_mod.run_rollouts_vps(plot_rest[1:])
            else:
                plt_mod.run_rollouts_diayn(plot_rest[1:])
        elif plot_cmd == "aggregate-curves":
            plt_mod.run_aggregate_curves(plot_rest)
        else:
            build_parser().parse_args([cmd, "--help"])
    else:
        build_parser().print_help()


def run_downstream_compare_with_argv(argv: list[str]) -> None:
    from .downstream import run_downstream_compare

    old = sys.argv
    try:
        sys.argv = ["downstream-compare", *argv]
        run_downstream_compare()
    finally:
        sys.argv = old


if __name__ == "__main__":
    main()
