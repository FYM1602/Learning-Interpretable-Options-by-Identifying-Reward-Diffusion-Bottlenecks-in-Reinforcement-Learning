#!/usr/bin/env python
"""Legacy entry point — forwards to ``python -m point_maze_vps downstream compare``."""

from __future__ import annotations

import sys
import warnings


def main() -> None:
    warnings.warn(
        "run_point_maze_diayn_goal_reaching.py is deprecated. "
        "Use: python -m point_maze_vps downstream compare",
        DeprecationWarning,
        stacklevel=1,
    )
    try:
        from .downstream import run_downstream_compare
    except ImportError:  # pragma: no cover — `python point_maze_vps/run_point_maze_diayn_goal_reaching.py`
        from downstream import run_downstream_compare

    old_argv = sys.argv
    try:
        sys.argv = ["downstream-compare", *old_argv[1:]]
        run_downstream_compare()
    finally:
        sys.argv = old_argv


if __name__ == "__main__":
    main()
