from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset


@dataclass
class ReplayTransitions:
    """Flat PointMaze transitions extracted from an SB3 replay buffer."""

    states: np.ndarray
    next_states: np.ndarray
    actions: np.ndarray
    dones: np.ndarray
    achieved_goals: np.ndarray | None = None
    desired_goals: np.ndarray | None = None

    def __len__(self) -> int:
        return int(self.states.shape[0])


class PointMazeTransitionDataset(Dataset):
    """Torch dataset for offline value/VPS fitting."""

    def __init__(self, transitions: ReplayTransitions):
        self.states = torch.as_tensor(transitions.states, dtype=torch.float32)
        self.next_states = torch.as_tensor(transitions.next_states, dtype=torch.float32)
        self.actions = torch.as_tensor(transitions.actions, dtype=torch.float32)
        self.dones = torch.as_tensor(transitions.dones, dtype=torch.float32)

    def __len__(self) -> int:
        return int(self.states.shape[0])

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        return (
            self.states[idx],
            self.next_states[idx],
            self.actions[idx],
            self.dones[idx],
        )


def _trim_env_dim(array: np.ndarray, size: int) -> np.ndarray:
    """Drop the SB3 env dimension for single-env training buffers."""
    trimmed = np.asarray(array[:size])
    if trimmed.ndim >= 2 and trimmed.shape[1] == 1:
        trimmed = trimmed[:, 0]
    return trimmed


def extract_sb3_replay_transitions(model, max_transitions: int | None = None) -> ReplayTransitions:
    """Extract PointMaze transitions from an SB3 HER replay buffer."""
    replay_buffer = model.replay_buffer
    size = replay_buffer.buffer_size if replay_buffer.full else replay_buffer.pos
    if size <= 0:
        raise ValueError("Replay buffer is empty; cannot fit PointMaze VPS diagnostics.")

    states = _trim_env_dim(replay_buffer.observations["observation"], size)
    next_states = _trim_env_dim(replay_buffer.next_observations["observation"], size)
    achieved_goals = _trim_env_dim(replay_buffer.observations["achieved_goal"], size)
    desired_goals = _trim_env_dim(replay_buffer.observations["desired_goal"], size)
    actions = _trim_env_dim(replay_buffer.actions, size)
    dones = _trim_env_dim(replay_buffer.dones, size).astype(np.float32)

    if getattr(replay_buffer, "handle_timeout_termination", False) and hasattr(replay_buffer, "timeouts"):
        timeouts = _trim_env_dim(replay_buffer.timeouts, size).astype(np.float32)
        dones = dones * (1.0 - timeouts)

    if max_transitions is not None and size > int(max_transitions):
        rng = np.random.default_rng(getattr(model, "seed", None))
        indices = np.sort(rng.choice(size, size=int(max_transitions), replace=False))
        states = states[indices]
        next_states = next_states[indices]
        achieved_goals = achieved_goals[indices]
        desired_goals = desired_goals[indices]
        actions = actions[indices]
        dones = dones[indices]

    return ReplayTransitions(
        states=np.asarray(states, dtype=np.float32),
        next_states=np.asarray(next_states, dtype=np.float32),
        actions=np.asarray(actions, dtype=np.float32),
        dones=np.asarray(dones, dtype=np.float32).reshape(-1, 1),
        achieved_goals=np.asarray(achieved_goals, dtype=np.float32),
        desired_goals=np.asarray(desired_goals, dtype=np.float32),
    )


def make_transition_loader(
    transitions: ReplayTransitions,
    batch_size: int,
    shuffle: bool = True,
) -> DataLoader:
    """Build a DataLoader over PointMaze replay transitions."""
    dataset = PointMazeTransitionDataset(transitions)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, drop_last=False)
