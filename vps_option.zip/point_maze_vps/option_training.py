from __future__ import annotations

import atexit
import os
import shutil
import subprocess
import time
from dataclasses import dataclass

import gymnasium as gym
import matplotlib.pyplot as plt
import numpy as np
import torch
from matplotlib.lines import Line2D
from stable_baselines3 import SAC
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.monitor import Monitor

try:
    import imageio
except Exception:  # pragma: no cover
    imageio = None

try:
    from .utils import (
        PointMazeObsOnlyWrapper,
        ensure_dir,
        maybe_to_maze_map,
        make_pointmaze_env,
        save_json,
    )
    from .maze_plotting import compute_extent, draw_maze_overlay, get_maze_plot_spec
    from .models import ProbVPSNet, VPSNet
except ImportError:  # pragma: no cover
    from utils import (
        PointMazeObsOnlyWrapper,
        ensure_dir,
        maybe_to_maze_map,
        make_pointmaze_env,
        save_json,
    )
    from maze_plotting import compute_extent, draw_maze_overlay, get_maze_plot_spec
    from models import ProbVPSNet, VPSNet

_XVFB_PROC = None


@dataclass(frozen=True)
class OptionSpec:
    """One dual option derived from a single VPS head."""

    option_id: int
    head_idx: int
    sign: int

    @property
    def name(self) -> str:
        suffix = "pos" if self.sign > 0 else "neg"
        return f"head{self.head_idx:02d}_{suffix}"


@dataclass
class XYRewardLookup:
    """Lookup-table approximation of VPS values on a fine XY grid."""

    phi_grid: np.ndarray
    extent: tuple[float, float, float, float]
    delta_std: np.ndarray
    bins_per_cell: int

    def phi_value(self, xy: np.ndarray, head_idx: int) -> float:
        """Return the VPS value of one head from the XY lookup table."""
        grid = np.asarray(self.phi_grid, dtype=np.float32)
        if grid.ndim != 3:
            raise ValueError(f"`phi_grid` must have shape (num_heads, rows, cols), got {grid.shape!r}")
        if not (0 <= int(head_idx) < int(grid.shape[0])):
            raise IndexError(f"head_idx={head_idx} outside [0, {grid.shape[0] - 1}]")

        x_min, x_max, y_min, y_max = (float(v) for v in self.extent)
        xy = np.asarray(xy, dtype=np.float32).reshape(-1)
        if xy.size < 2:
            raise ValueError(f"Expected XY coordinates with at least 2 dims, got shape {xy.shape!r}")
        x, y = float(xy[0]), float(xy[1])
        cols = int(grid.shape[2])
        rows = int(grid.shape[1])
        x_ratio = np.clip((x - x_min) / max(x_max - x_min, 1e-6), 0.0, 1.0 - 1e-9)
        y_ratio = np.clip((y - y_min) / max(y_max - y_min, 1e-6), 0.0, 1.0 - 1e-9)
        col = int(x_ratio * cols)
        row = int(y_ratio * rows)
        return float(grid[int(head_idx), row, col])


class VPSIntrinsicRewardWrapper(gym.Wrapper):
    """Replace environment reward with VPS-ascent or VPS-descent reward."""

    def __init__(
        self,
        env: gym.Env,
        vps_model: VPSNet | ProbVPSNet,
        state_mean: np.ndarray,
        state_std: np.ndarray,
        option_spec: OptionSpec,
        reward_scale: float = 1.0,
        normalize_rewards: bool = True,
        device: torch.device | str = "cpu",
        reward_lookup: XYRewardLookup | None = None,
    ):
        super().__init__(env)
        self.vps_model = vps_model
        self.reward_lookup = reward_lookup
        self.state_mean = np.asarray(state_mean, dtype=np.float32).reshape(1, -1)
        self.state_std = np.asarray(state_std, dtype=np.float32).reshape(1, -1)
        self.option_spec = option_spec
        self.reward_scale = float(reward_scale)
        self.normalize_rewards = bool(normalize_rewards)
        self.device = torch.device(device)
        if reward_lookup is not None:
            delta_std = np.asarray(reward_lookup.delta_std, dtype=np.float32).reshape(1, -1)
        else:
            delta_std = np.asarray(getattr(vps_model, "_vps_delta_std", np.ones((1, 1), dtype=np.float32)), dtype=np.float32).reshape(1, -1)
        self.delta_std = np.maximum(delta_std, 1e-6)
        self._prev_obs: np.ndarray | None = None

    def _phi_value(self, obs: np.ndarray) -> float:
        if self.reward_lookup is not None:
            obs_np = np.asarray(obs, dtype=np.float32).reshape(-1)
            return self.reward_lookup.phi_value(obs_np[:2], self.option_spec.head_idx)

        @torch.no_grad()
        def _network_phi(obs_value: np.ndarray) -> float:
            obs_np = np.asarray(obs_value, dtype=np.float32).reshape(1, -1)
            norm = (obs_np - self.state_mean) / self.state_std
            obs_tensor = torch.as_tensor(norm, dtype=torch.float32, device=self.device)
            phi = self.vps_model(obs_tensor)[0, self.option_spec.head_idx]
            return float(phi.item())

        return _network_phi(obs)

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self._prev_obs = np.asarray(obs, dtype=np.float32).copy()
        info = dict(info)
        info["option_id"] = self.option_spec.option_id
        info["option_head"] = self.option_spec.head_idx
        info["option_sign"] = self.option_spec.sign
        info["vps_phi"] = self._phi_value(self._prev_obs)
        return obs, info

    def step(self, action):
        obs, extr_reward, terminated, truncated, info = self.env.step(action)
        obs = np.asarray(obs, dtype=np.float32)
        prev_phi = self._phi_value(self._prev_obs if self._prev_obs is not None else obs)
        next_phi = self._phi_value(obs)
        delta_phi = next_phi - prev_phi
        if self.normalize_rewards and 0 <= self.option_spec.head_idx < self.delta_std.shape[1]:
            delta_phi = delta_phi / float(self.delta_std[0, self.option_spec.head_idx])
        intrinsic_reward = self.reward_scale * self.option_spec.sign * delta_phi
        self._prev_obs = obs.copy()

        info = dict(info)
        info["external_reward"] = float(extr_reward)
        info["intrinsic_reward"] = float(intrinsic_reward)
        info["phi_prev"] = float(prev_phi)
        info["phi_next"] = float(next_phi)
        info["phi_delta"] = float(next_phi - prev_phi)
        info["normalized_phi_delta"] = float(delta_phi)
        info["option_id"] = self.option_spec.option_id
        info["option_head"] = self.option_spec.head_idx
        info["option_sign"] = self.option_spec.sign
        return obs, float(intrinsic_reward), terminated, truncated, info


def save_gif(frames, path, fps: int):
    if imageio is None:
        print(f"[GIF] imageio not available, cannot save GIF to {path}")
        return
    if len(frames) == 0:
        print(f"[GIF] No frames to save to {path}")
        return
    try:
        arrs = []
        for frame in frames:
            frame = np.asarray(frame)
            if frame.dtype != np.uint8:
                frame = (frame * 255).astype(np.uint8) if frame.max() <= 1.0 else frame.astype(np.uint8)
            arrs.append(frame)
        if arrs:
            imageio.mimsave(path, arrs, fps=int(fps))
            print(f"[GIF] Saved {len(arrs)} frames -> {path}")
        else:
            print(f"[GIF] No valid frames to save to {path}")
    except Exception as exc:
        print(f"[GIF] Failed: {exc}")


def try_render_frame(env, gif_enabled: bool):
    if not gif_enabled:
        return None, False
    try:
        frame = env.render()
        return frame, True
    except Exception as exc:  # pragma: no cover
        print(f"[GIF] Disabling GIF capture because rendering failed: {exc}")
        return None, False


def stop_virtual_display():
    global _XVFB_PROC
    if _XVFB_PROC is None:
        return
    try:
        if _XVFB_PROC.poll() is None:
            _XVFB_PROC.terminate()
            _XVFB_PROC.wait(timeout=2.0)
    except Exception:
        try:
            _XVFB_PROC.kill()
        except Exception:
            pass
    finally:
        _XVFB_PROC = None


def maybe_start_virtual_display(args):
    global _XVFB_PROC
    if args.gif_freq <= 0 or os.name == "nt":
        return
    if os.environ.get("DISPLAY", "").strip():
        return

    requested = str(getattr(args, "mujoco_gl", "auto")).strip().lower()
    current = os.environ.get("MUJOCO_GL", "").strip().lower()
    if requested in {"egl", "osmesa"} or current in {"egl", "osmesa"}:
        return

    xvfb_bin = shutil.which("Xvfb")
    if not xvfb_bin:
        print("[GIF] Xvfb not found; skipping virtual display setup.")
        return

    for display_id in range(99, 110):
        socket_path = f"/tmp/.X11-unix/X{display_id}"
        if os.path.exists(socket_path):
            continue
        try:
            proc = subprocess.Popen(
                [xvfb_bin, f":{display_id}", "-screen", "0", "1024x768x24", "-nolisten", "tcp"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            time.sleep(0.2)
            if proc.poll() is None:
                _XVFB_PROC = proc
                os.environ["DISPLAY"] = f":{display_id}"
                if requested == "auto" and not current:
                    os.environ["MUJOCO_GL"] = "glfw"
                atexit.register(stop_virtual_display)
                print(f"[GIF] Started virtual display on DISPLAY=:{display_id}.")
                return
        except Exception:
            continue


def can_enable_gif_capture():
    mujoco_gl = os.environ.get("MUJOCO_GL", "").strip().lower()
    display = os.environ.get("DISPLAY", "").strip()

    if os.name != "nt" and not display and mujoco_gl not in {"egl", "osmesa"}:
        print(
            "[GIF] Disabled before training: no DISPLAY detected and no offscreen "
            "backend selected. Try default auto mode with Xvfb available, or pass "
            "--mujoco_gl egl/osmesa explicitly."
        )
        return False
    return True


def configure_mujoco_gl_for_gif(args):
    if args.gif_freq <= 0:
        return

    requested = str(getattr(args, "mujoco_gl", "auto")).strip().lower()
    current = os.environ.get("MUJOCO_GL", "").strip().lower()
    display = os.environ.get("DISPLAY", "").strip()
    if requested in {"egl", "osmesa", "glfw"}:
        if current != requested:
            os.environ["MUJOCO_GL"] = requested
            print(f"[GIF] Set MUJOCO_GL={requested} from --mujoco_gl.")
        return
    if os.name != "nt" and not display and not current:
        os.environ["MUJOCO_GL"] = "egl"
        os.environ.setdefault("EGL_LOG_LEVEL", "fatal")
        print("[GIF] Headless Linux detected; auto-setting MUJOCO_GL=egl for offscreen rendering.")


class PeriodicOptionEvalCallback(BaseCallback):
    """Evaluate each option under its own intrinsic reward."""

    def __init__(
        self,
        make_env_fn,
        make_render_env_fn,
        option_spec: OptionSpec,
        eval_base_seed: int,
        eval_freq: int,
        n_eval_episodes: int,
        save_path: str,
        env_id: str,
        maze_map: list[list[int | str]] | None,
        rollout_dir: str | None = None,
        rollout_plot_freq: int = 0,
        gif_dir: str | None = None,
        gif_enabled: bool = False,
        gif_freq: int = 0,
        gif_fps: int = 10,
        gif_max_steps: int = 300,
        gif_stop_on_done: bool = False,
    ):
        super().__init__(verbose=0)
        self.make_env_fn = make_env_fn
        self.make_render_env_fn = make_render_env_fn
        self.option_spec = option_spec
        self.eval_base_seed = int(eval_base_seed)
        self.eval_freq = max(int(eval_freq), 1)
        self.n_eval_episodes = max(int(n_eval_episodes), 1)
        self.save_path = save_path
        self.env_id = env_id
        self.maze_map = maze_map
        self.rollout_dir = rollout_dir
        self.rollout_plot_freq = max(int(rollout_plot_freq), 0)
        self.gif_dir = gif_dir
        self.gif_enabled = bool(gif_enabled)
        self.gif_freq = max(int(gif_freq), 0)
        self.gif_fps = max(int(gif_fps), 1)
        self.gif_max_steps = max(int(gif_max_steps), 1)
        self.gif_stop_on_done = bool(gif_stop_on_done)
        self.timesteps: list[int] = []
        self.mean_intrinsic_rewards: list[float] = []
        self.mean_phi_changes: list[float] = []
        self.eval_call_count = 0

    def _run_eval(self, collect_trajectories: bool = False) -> tuple[float, float, list[np.ndarray] | None]:
        env = self.make_env_fn()
        try:
            rewards: list[float] = []
            phi_changes: list[float] = []
            trajectories: list[np.ndarray] | None = [] if collect_trajectories else None
            self.eval_call_count += 1
            eval_seed = self.eval_base_seed + self.eval_call_count
            for episode_idx in range(self.n_eval_episodes):
                obs, info = env.reset(seed=eval_seed + episode_idx)
                start_phi = float(info.get("vps_phi", 0.0))
                done = False
                total_reward = 0.0
                last_phi = start_phi
                states = [np.asarray(obs, dtype=np.float32).copy()] if collect_trajectories else None
                while not done:
                    action, _ = self.model.predict(obs, deterministic=True)
                    obs, reward, terminated, truncated, info = env.step(action)
                    total_reward += float(reward)
                    last_phi = float(info.get("phi_next", last_phi))
                    if states is not None:
                        states.append(np.asarray(obs, dtype=np.float32).copy())
                    done = bool(terminated or truncated)
                rewards.append(total_reward)
                phi_changes.append(self.option_spec.sign * (last_phi - start_phi))
                if trajectories is not None and states is not None:
                    trajectories.append(np.asarray(states, dtype=np.float32))
        finally:
            env.close()
        return float(np.mean(rewards)), float(np.mean(phi_changes)), trajectories

    def _save_rollout_plot(self, trajectories: list[np.ndarray]) -> str | None:
        if self.rollout_dir is None or not trajectories:
            return None
        save_path = os.path.join(self.rollout_dir, f"{self.option_spec.name}_step{self.num_timesteps:07d}.png")
        all_states = np.concatenate(trajectories, axis=0)
        states_xy = np.asarray(all_states[:, :2], dtype=np.float64)
        maze_map, known_extent = get_maze_plot_spec(self.env_id, maze_map=self.maze_map)
        extent = known_extent if known_extent is not None else compute_extent(states_xy, self.env_id, maze_map)

        plt.figure(figsize=(5.2, 4.8))
        ax = plt.gca()
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
        draw_maze_overlay(ax, maze_map, extent)
        for trajectory in trajectories:
            xy = np.asarray(trajectory[:, :2], dtype=np.float64)
            line, = ax.plot(xy[:, 0], xy[:, 1], linewidth=1.6, alpha=0.85)
            color = line.get_color()
            ax.scatter(xy[0, 0], xy[0, 1], s=18, marker="o", color=color)
            ax.scatter(xy[-1, 0], xy[-1, 1], s=28, marker="x", color=color)
        ax.set_aspect("equal")
        ax.set_title(f"VPS {self.option_spec.name} Rollouts")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.grid(alpha=0.2)
        legend_handles = [
            Line2D([0], [0], color="black", linewidth=1.6, label="Rollout"),
            Line2D([0], [0], marker="o", color="black", linestyle="None", markersize=6, label="Start"),
            Line2D([0], [0], marker="x", color="black", linestyle="None", markersize=7, label="End"),
        ]
        ax.legend(handles=legend_handles, loc="best")
        plt.tight_layout()
        plt.savefig(save_path, dpi=200, bbox_inches="tight")
        plt.close()
        print(f"[Rollout:{self.option_spec.name}] Saved rollout plot -> {save_path}")
        return save_path

    def _save_gif(self) -> str | None:
        if self.gif_dir is None or self.gif_freq <= 0 or not self.gif_enabled:
            return None
        gif_path = os.path.join(self.gif_dir, f"{self.option_spec.name}_step{self.num_timesteps:07d}.gif")
        frames: list[np.ndarray] = []
        gif_enabled = self.gif_enabled
        env = self.make_render_env_fn()
        try:
            obs, _ = env.reset()
            frame0, gif_enabled = try_render_frame(env, gif_enabled)
            if isinstance(frame0, np.ndarray):
                frames.append(frame0.copy())
            for _ in range(self.gif_max_steps):
                action, _ = self.model.predict(obs, deterministic=True)
                obs, _, terminated, truncated, _ = env.step(action)
                frame, gif_enabled = try_render_frame(env, gif_enabled)
                if isinstance(frame, np.ndarray):
                    frames.append(frame.copy())
                if terminated or truncated:
                    if self.gif_stop_on_done:
                        break
                    obs, _ = env.reset()
                    frame, gif_enabled = try_render_frame(env, gif_enabled)
                    if isinstance(frame, np.ndarray):
                        frames.append(frame.copy())
                if not gif_enabled:
                    self.gif_enabled = False
                    break
                if len(frames) >= self.gif_max_steps + 1:
                    break
        finally:
            env.close()

        if len(frames) <= 1:
            print(f"[GIF:{self.option_spec.name}] Skipped GIF at step {self.num_timesteps} (insufficient frames).")
            return None
        save_gif(frames, gif_path, self.gif_fps)
        return gif_path

    def _on_step(self) -> bool:
        if self.num_timesteps % self.eval_freq != 0:
            return True
        should_save_rollout = self.rollout_plot_freq > 0
        mean_reward, mean_phi_change, trajectories = self._run_eval(collect_trajectories=should_save_rollout)
        self.timesteps.append(int(self.num_timesteps))
        self.mean_intrinsic_rewards.append(mean_reward)
        self.mean_phi_changes.append(mean_phi_change)
        np.savez_compressed(
            self.save_path,
            timesteps=np.asarray(self.timesteps, dtype=np.int64),
            mean_intrinsic_rewards=np.asarray(self.mean_intrinsic_rewards, dtype=np.float32),
            mean_phi_changes=np.asarray(self.mean_phi_changes, dtype=np.float32),
        )
        print(
            f"[Eval:{self.option_spec.name}] steps={self.num_timesteps} "
            f"mean_intr_reward={mean_reward:.4f} mean_signed_phi_change={mean_phi_change:.4f}"
        )
        if should_save_rollout and trajectories is not None:
            try:
                self._save_rollout_plot(trajectories)
            except Exception as exc:
                print(f"[Rollout:{self.option_spec.name}] Failed at step {self.num_timesteps}: {exc}")
        if self.gif_freq > 0 and self.num_timesteps % self.gif_freq == 0:
            try:
                self._save_gif()
            except Exception as exc:
                print(f"[GIF:{self.option_spec.name}] Failed at step {self.num_timesteps}: {exc}")
        return True


def parse_option_ids(spec: str | None, total: int) -> list[int]:
    """Parse comma-separated option ids and numeric ranges."""
    if spec is None or not str(spec).strip():
        return list(range(total))
    result: set[int] = set()
    for chunk in str(spec).split(","):
        item = chunk.strip()
        if not item:
            continue
        if "-" in item:
            left, right = item.split("-", 1)
            start = int(left.strip())
            end = int(right.strip())
            if end < start:
                start, end = end, start
            result.update(range(start, end + 1))
        else:
            result.add(int(item))
    parsed = sorted(v for v in result if 0 <= v < total)
    if not parsed:
        raise ValueError(f"No valid option ids parsed from {spec!r}; expected ids in [0, {total - 1}]")
    return parsed


def load_vps_model(
    checkpoint_path: str,
    device: torch.device,
) -> tuple[VPSNet | ProbVPSNet, np.ndarray, np.ndarray, int, list[list[int | str]] | None]:
    """Load a saved VPS checkpoint for inference."""
    with open(checkpoint_path, "rb") as f:
        # This checkpoint is produced locally by the same pipeline and includes
        # numpy arrays plus config metadata, so PyTorch 2.6 needs weights_only disabled.
        checkpoint = torch.load(f, map_location=device, weights_only=False)
    config = checkpoint["config"]
    state_mean = np.asarray(checkpoint["state_mean"], dtype=np.float32)
    state_std = np.asarray(checkpoint["state_std"], dtype=np.float32)
    hidden_dims = tuple(int(v) for v in config["hidden_dims"])
    adapter_hidden_dim = int(config.get("adapter_hidden_dim", 256))
    num_rewards = int(config["num_rewards"])
    vps_delta_std = np.asarray(checkpoint.get("vps_delta_std", np.ones((1, num_rewards), dtype=np.float32)), dtype=np.float32)
    if bool(config.get("prob_vps", False)):
        model = ProbVPSNet(
            input_dim=state_mean.size,
            k=num_rewards,
            hidden_dims=hidden_dims,
            adapter_hidden_dim=adapter_hidden_dim,
            log_eps=float(config.get("prob_vps_log_eps", 1e-6)),
            min_logvar=float(config.get("prob_vps_min_logvar", -6.0)),
            max_logvar=float(config.get("prob_vps_max_logvar", 2.0)),
        ).to(device)
    else:
        model = VPSNet(
            input_dim=state_mean.size,
            k=num_rewards,
            hidden_dims=hidden_dims,
            adapter_hidden_dim=adapter_hidden_dim,
        ).to(device)
    model.load_state_dict(checkpoint["vps_net"])
    model.eval()
    model._has_saved_vps_delta_std = bool("vps_delta_std" in checkpoint)
    model._vps_delta_std = np.maximum(vps_delta_std, 1e-6).astype(np.float32)
    maze_map = maybe_to_maze_map(config.get("maze_map"))
    return model, state_mean, state_std, num_rewards, maze_map


def option_spec_from_id(option_id: int, num_heads: int, sign_enabled: bool) -> OptionSpec:
    """Map a flat option id to head index and sign."""
    if sign_enabled:
        if not (0 <= option_id < 2 * num_heads):
            raise IndexError(f"option_id={option_id} outside [0, {2 * num_heads - 1}]")
        head_idx = option_id // 2
        sign = 1 if option_id % 2 == 0 else -1
    else:
        if not (0 <= option_id < num_heads):
            raise IndexError(f"option_id={option_id} outside [0, {num_heads - 1}]")
        head_idx = option_id
        sign = 1
    return OptionSpec(option_id=option_id, head_idx=head_idx, sign=sign)


def make_option_env_factory(
    *,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    max_episode_steps: int,
    option_spec: OptionSpec,
    vps_model: VPSNet | ProbVPSNet,
    state_mean: np.ndarray,
    state_std: np.ndarray,
    reward_scale: float,
    normalize_option_rewards: bool,
    seed: int,
    device: torch.device,
    reward_lookup: XYRewardLookup | None = None,
    render_mode: str | None = None,
    monitor: bool = True,
):
    """Create a closure that builds fresh option-training envs."""

    def _factory() -> gym.Env:
        extra_kwargs = {"continuing_task": True}
        if maze_map is not None:
            extra_kwargs["maze_map"] = maze_map
        env = make_pointmaze_env(
            env_id=env_id,
            seed=seed,
            render_mode=render_mode,
            max_episode_steps=max_episode_steps,
            extra_kwargs=extra_kwargs,
        )
        env = PointMazeObsOnlyWrapper(env)
        env = VPSIntrinsicRewardWrapper(
            env=env,
            vps_model=vps_model,
            state_mean=state_mean,
            state_std=state_std,
            option_spec=option_spec,
            reward_scale=reward_scale,
            normalize_rewards=normalize_option_rewards,
            device=device,
            reward_lookup=reward_lookup,
        )
        if monitor:
            env = Monitor(env)
        return env

    return _factory


def train_one_option(
    *,
    args,
    env_id: str,
    maze_map: list[list[int | str]] | None,
    save_dir: str,
    option_spec: OptionSpec,
    vps_model: VPSNet | ProbVPSNet,
    state_mean: np.ndarray,
    state_std: np.ndarray,
    device: torch.device,
    gif_enabled: bool,
    reward_lookup: XYRewardLookup | None = None,
) -> None:
    """Train one SAC option policy from a saved VPS head."""
    option_dir = ensure_dir(os.path.join(save_dir, f"option_{option_spec.option_id:02d}_{option_spec.name}"))
    make_env_fn = make_option_env_factory(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=args.max_episode_steps,
        option_spec=option_spec,
        vps_model=vps_model,
        state_mean=state_mean,
        state_std=state_std,
        reward_scale=args.reward_scale,
        normalize_option_rewards=args.normalize_option_rewards,
        seed=args.seed + option_spec.option_id,
        device=device,
        reward_lookup=reward_lookup,
    )
    make_render_env_fn = make_option_env_factory(
        env_id=env_id,
        maze_map=maze_map,
        max_episode_steps=args.max_episode_steps,
        option_spec=option_spec,
        vps_model=vps_model,
        state_mean=state_mean,
        state_std=state_std,
        reward_scale=args.reward_scale,
        normalize_option_rewards=args.normalize_option_rewards,
        seed=args.seed + option_spec.option_id,
        device=device,
        reward_lookup=reward_lookup,
        render_mode="rgb_array",
        monitor=False,
    )
    env = make_env_fn()
    policy_kwargs = dict(net_arch=list(args.policy_hidden_dims))
    model = SAC(
        policy="MlpPolicy",
        env=env,
        learning_rate=args.learning_rate,
        buffer_size=args.buffer_size,
        learning_starts=args.learning_starts,
        batch_size=args.batch_size,
        gamma=args.gamma,
        tau=args.tau,
        gradient_steps=args.gradient_steps,
        seed=args.seed + option_spec.option_id,
        device=str(device),
        verbose=1,
        policy_kwargs=policy_kwargs,
    )
    callback = PeriodicOptionEvalCallback(
        make_env_fn=make_env_fn,
        make_render_env_fn=make_render_env_fn,
        option_spec=option_spec,
        eval_base_seed=args.seed + option_spec.option_id,
        eval_freq=args.eval_freq,
        n_eval_episodes=args.eval_episodes,
        save_path=os.path.join(option_dir, "eval_metrics.npz"),
        env_id=env_id,
        maze_map=maze_map,
        rollout_dir=ensure_dir(os.path.join(option_dir, "rollouts")),
        rollout_plot_freq=args.rollout_plot_freq,
        gif_dir=ensure_dir(os.path.join(option_dir, "gifs")),
        gif_enabled=gif_enabled,
        gif_freq=args.gif_freq,
        gif_fps=args.gif_fps,
        gif_max_steps=args.gif_max_steps,
        gif_stop_on_done=args.gif_stop_on_done,
    )
    print(
        f"[Option] Training option_id={option_spec.option_id} "
        f"head={option_spec.head_idx} sign={option_spec.sign:+d}"
    )
    model.learn(total_timesteps=args.total_timesteps, callback=callback, log_interval=10)
    model.save(os.path.join(option_dir, "option_policy"))
    if hasattr(model, "save_replay_buffer"):
        model.save_replay_buffer(os.path.join(option_dir, "option_replay_buffer.pkl"))
    save_json(
        os.path.join(option_dir, "option_summary.json"),
        {
            "env_id": env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": maze_map is not None,
            "option_id": option_spec.option_id,
            "option_name": option_spec.name,
            "head_idx": option_spec.head_idx,
            "sign": option_spec.sign,
            "reward_scale": args.reward_scale,
            "normalize_option_rewards": bool(args.normalize_option_rewards),
            "checkpoint_path": os.path.abspath(args.checkpoint_path),
            "total_timesteps": int(args.total_timesteps),
        },
    )
    env.close()
