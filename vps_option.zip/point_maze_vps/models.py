from __future__ import annotations

import copy
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class MLPBackbone(nn.Module):
    """Small MLP encoder for PointMaze state vectors."""

    def __init__(self, input_dim: int, hidden_dims: tuple[int, ...] = (256, 256)):
        super().__init__()
        layers: list[nn.Module] = []
        last_dim = input_dim
        for hidden_dim in hidden_dims:
            linear = nn.Linear(last_dim, hidden_dim)
            nn.init.kaiming_normal_(linear.weight, nonlinearity="relu")
            nn.init.zeros_(linear.bias)
            layers.extend([linear, nn.ReLU()])
            last_dim = hidden_dim
        self.net = nn.Sequential(*layers)
        self.flat_dim = last_dim

    def forward(self, x: Tensor) -> Tensor:
        return self.net(x)


class StateRFFLayer(nn.Module):
    """Frozen random Fourier feature layer for continuous states."""

    def __init__(self, in_dim: int, k: int, sigma: float = 1.0, seed: int = 0):
        super().__init__()
        generator = torch.Generator(device="cpu")
        generator.manual_seed(seed)
        w = torch.randn((k, in_dim), generator=generator) * sigma
        b = torch.rand((k,), generator=generator) * (2.0 * math.pi)
        self.register_buffer("W", w)
        self.register_buffer("b", b)
        self.scale = math.sqrt(2.0 / max(k, 1))

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        return self.scale * torch.cos(F.linear(x, self.W, self.b))


class _MLPHead(nn.Module):
    """Two-layer MLP head used for both value and VPS outputs."""

    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, out_dim),
        )
        for module in self.net:
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                nn.init.zeros_(module.bias)

    def forward(self, x: Tensor) -> Tensor:
        return self.net(x)


class _PerHeadAdapter(nn.Module):
    """Small adapter that lets each reward head specialize beyond the shared trunk."""

    def __init__(self, in_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        for module in self.net:
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                nn.init.zeros_(module.bias)

    def forward(self, x: Tensor) -> Tensor:
        return self.net(x)


class _MultiHeadAdapter(nn.Module):
    """Shared trunk + one small per-head adapter for each output dimension."""

    def __init__(self, in_dim: int, out_dim: int, adapter_hidden_dim: int = 256):
        super().__init__()
        self.adapters = nn.ModuleList(
            [_PerHeadAdapter(in_dim=in_dim, hidden_dim=adapter_hidden_dim) for _ in range(out_dim)]
        )

    def forward(self, x: Tensor) -> Tensor:
        return torch.cat([adapter(x) for adapter in self.adapters], dim=-1)


class ValueNet(nn.Module):
    """Predict k random-reward value functions from PointMaze states."""

    def __init__(
        self,
        input_dim: int,
        k: int,
        hidden_dims: tuple[int, ...] = (256, 256),
        adapter_hidden_dim: int = 256,
    ):
        super().__init__()
        self.backbone = MLPBackbone(input_dim=input_dim, hidden_dims=hidden_dims)
        self.head = _MultiHeadAdapter(self.backbone.flat_dim, k, adapter_hidden_dim=adapter_hidden_dim)

    def forward(self, x: Tensor) -> Tensor:
        return self.head(self.backbone(x))


class VPSNet(nn.Module):
    """Predict k VPS functions from PointMaze states."""

    def __init__(
        self,
        input_dim: int,
        k: int,
        hidden_dims: tuple[int, ...] = (256, 256),
        adapter_hidden_dim: int = 256,
    ):
        super().__init__()
        self.backbone = MLPBackbone(input_dim=input_dim, hidden_dims=hidden_dims)
        self.head = _MultiHeadAdapter(self.backbone.flat_dim, k, adapter_hidden_dim=adapter_hidden_dim)

    def forward(self, x: Tensor) -> Tensor:
        return self.head(self.backbone(x))


class ProbVPSNet(nn.Module):
    """Predict a log-VPS Gaussian distribution and expose its mean VPS."""

    def __init__(
        self,
        input_dim: int,
        k: int,
        hidden_dims: tuple[int, ...] = (256, 256),
        adapter_hidden_dim: int = 256,
        log_eps: float = 1e-6,
        min_logvar: float = -6.0,
        max_logvar: float = 2.0,
    ):
        super().__init__()
        self.backbone = MLPBackbone(input_dim=input_dim, hidden_dims=hidden_dims)
        self.mean_head = _MultiHeadAdapter(self.backbone.flat_dim, k, adapter_hidden_dim=adapter_hidden_dim)
        self.logvar_head = _MultiHeadAdapter(self.backbone.flat_dim, k, adapter_hidden_dim=adapter_hidden_dim)
        self.log_eps = float(log_eps)
        self.min_logvar = float(min_logvar)
        self.max_logvar = float(max_logvar)

    def distribution_params(self, x: Tensor) -> tuple[Tensor, Tensor]:
        features = self.backbone(x)
        mu = self.mean_head(features)
        logvar = self.logvar_head(features).clamp(self.min_logvar, self.max_logvar)
        return mu, logvar

    def forward(self, x: Tensor) -> Tensor:
        mu, _ = self.distribution_params(x)
        return torch.exp(mu).clamp_min(self.log_eps) - self.log_eps


def clone_model(module: nn.Module) -> nn.Module:
    """Deep-copy a module for target-network usage."""
    return copy.deepcopy(module)


@torch.no_grad()
def soft_update(target: nn.Module, source: nn.Module, tau: float) -> None:
    """Polyak average parameters from source into target."""
    for target_param, source_param in zip(target.parameters(), source.parameters()):
        target_param.data.mul_(1.0 - tau).add_(source_param.data, alpha=tau)
