from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Callable

import numpy as np
import torch
import torch.nn.functional as F

try:
    from .vps_dataset import ReplayTransitions
    from .models import ProbVPSNet, StateRFFLayer, VPSNet, ValueNet, clone_model, soft_update
except ImportError:  # pragma: no cover
    from vps_dataset import ReplayTransitions
    from models import ProbVPSNet, StateRFFLayer, VPSNet, ValueNet, clone_model, soft_update


@dataclass
class VPSTrainOutputs:
    """Saved outputs from offline PointMaze value/VPS fitting."""

    value_features: np.ndarray
    vps_features: np.ndarray
    reward_features: np.ndarray
    state_mean: np.ndarray
    state_std: np.ndarray
    reward_mean: np.ndarray
    reward_std: np.ndarray
    vps_delta_mean: np.ndarray
    vps_delta_std: np.ndarray
    value_losses: np.ndarray
    vps_losses: np.ndarray


def normalize_states(states: np.ndarray, next_states: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Standardize PointMaze state vectors for offline fitting."""
    stacked = np.concatenate([states, next_states], axis=0)
    mean = stacked.mean(axis=0, keepdims=True)
    std = stacked.std(axis=0, keepdims=True)
    std = np.maximum(std, 1e-6)
    return (states - mean) / std, (next_states - mean) / std, mean.astype(np.float32), std.astype(np.float32)


def compute_reward_normalization_stats(
    rewards: np.ndarray,
    done_mask: np.ndarray,
    mode: str,
    quantile_low: float,
    quantile_high: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute fixed reward centering and scaling statistics from a replay buffer."""
    nonterminal = rewards[~done_mask] if np.any(~done_mask) else rewards
    reward_mean = nonterminal.mean(axis=0, keepdims=True).astype(np.float32)
    eps = 1e-6

    if mode == "std":
        reward_scale = np.maximum(nonterminal.std(axis=0, keepdims=True), eps)
    elif mode == "range":
        reward_scale = np.maximum(
            nonterminal.max(axis=0, keepdims=True) - nonterminal.min(axis=0, keepdims=True),
            eps,
        )
    elif mode == "quantile_range":
        if not 0.0 <= quantile_low < quantile_high <= 1.0:
            raise ValueError(
                "Quantile range must satisfy 0 <= reward_quantile_low < reward_quantile_high <= 1."
            )
        q_low = np.quantile(nonterminal, quantile_low, axis=0, keepdims=True)
        q_high = np.quantile(nonterminal, quantile_high, axis=0, keepdims=True)
        reward_scale = np.maximum(q_high - q_low, eps)
    else:
        raise ValueError(
            f"Unsupported reward normalization mode: {mode!r}. "
            "Expected one of: 'std', 'range', 'quantile_range'."
        )

    return reward_mean.astype(np.float32), reward_scale.astype(np.float32)


def compute_reward_targets(
    normalized_next_states: np.ndarray,
    dones: np.ndarray,
    k: int,
    sigma: float,
    seed: int,
    device: torch.device,
    xy_only: bool = False,
    normalization_mode: str = "std",
    quantile_low: float = 0.05,
    quantile_high: float = 0.95,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, StateRFFLayer]:
    """Generate standardized RFF random rewards on next states."""
    rff_inputs = normalized_next_states[:, :2] if xy_only else normalized_next_states
    rff = StateRFFLayer(in_dim=rff_inputs.shape[1], k=k, sigma=sigma, seed=seed).to(device)
    with torch.no_grad():
        rewards = rff(torch.as_tensor(rff_inputs, dtype=torch.float32, device=device)).cpu().numpy()
    done_mask = dones.reshape(-1) > 0.5
    rewards[done_mask] = 0.0
    reward_mean, reward_std = compute_reward_normalization_stats(
        rewards=rewards,
        done_mask=done_mask,
        mode=normalization_mode,
        quantile_low=quantile_low,
        quantile_high=quantile_high,
    )
    normalized_rewards = ((rewards - reward_mean) / reward_std).astype(np.float32)
    normalized_rewards[done_mask] = 0.0
    return normalized_rewards, reward_mean, reward_std, rff


def build_n_step_targets(
    rewards: np.ndarray,
    dones: np.ndarray,
    gamma: float,
    n_step: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Precompute fixed n-step reward sums and bootstrap locations from sequential replay."""
    if int(n_step) <= 0:
        raise ValueError("`n_step` must be positive.")

    num_samples, num_heads = rewards.shape
    n_step_returns = np.zeros((num_samples, num_heads), dtype=np.float32)
    bootstrap_indices = np.full((num_samples,), -1, dtype=np.int64)
    bootstrap_discounts = np.zeros((num_samples, 1), dtype=np.float32)
    done_mask = dones.reshape(-1) > 0.5

    gamma = float(gamma)
    horizon = int(n_step)
    for start_idx in range(num_samples):
        total = np.zeros((num_heads,), dtype=np.float32)
        for step_idx in range(horizon):
            transition_idx = start_idx + step_idx
            if transition_idx >= num_samples:
                break
            total += (gamma**step_idx) * rewards[transition_idx]
            if done_mask[transition_idx]:
                break
            if step_idx == horizon - 1:
                bootstrap_indices[start_idx] = transition_idx
                bootstrap_discounts[start_idx, 0] = gamma ** (step_idx + 1)
        n_step_returns[start_idx] = total
    return n_step_returns, bootstrap_indices, bootstrap_discounts


def fit_pointmaze_vps(
    transitions: ReplayTransitions,
    *,
    num_rewards: int,
    gamma: float,
    batch_size: int,
    value_epochs: int,
    vps_epochs: int,
    learning_rate: float,
    target_tau: float,
    hidden_dims: tuple[int, ...],
    rff_sigma: float,
    adapter_hidden_dim: int = 256,
    value_n_step: int = 1,
    freeze_vps_backbone: bool = False,
    prob_vps: bool = False,
    prob_vps_log_eps: float = 1e-6,
    prob_vps_min_logvar: float = -6.0,
    prob_vps_max_logvar: float = 2.0,
    xy_rff: bool = False,
    reward_normalization: str = "std",
    reward_quantile_low: float = 0.05,
    reward_quantile_high: float = 0.95,
    smooth_vps: bool = False,
    smooth_vps_coef: float = 0.1,
    value_snapshot_freq: int = 0,
    vps_snapshot_freq: int = 0,
    maze_map: list[list[int | str]] | None = None,
    on_value_fit: Callable[[np.ndarray, np.ndarray, int], None] | None = None,
    on_vps_fit: Callable[[np.ndarray, np.ndarray, int], None] | None = None,
    seed: int,
    device: torch.device,
    save_dir: str,
) -> tuple[VPSTrainOutputs, str]:
    """Fit k random-reward value functions and the corresponding VPS functions."""
    norm_states, norm_next_states, state_mean, state_std = normalize_states(
        transitions.states,
        transitions.next_states,
    )
    rewards, reward_mean, reward_std, rff = compute_reward_targets(
        normalized_next_states=norm_next_states,
        dones=transitions.dones,
        k=num_rewards,
        sigma=rff_sigma,
        seed=seed,
        device=device,
        xy_only=xy_rff,
        normalization_mode=reward_normalization,
        quantile_low=reward_quantile_low,
        quantile_high=reward_quantile_high,
    )

    normalized_state_tensor = torch.as_tensor(norm_states, dtype=torch.float32, device=device)
    normalized_next_state_tensor = torch.as_tensor(norm_next_states, dtype=torch.float32, device=device)
    n_step_returns_np, bootstrap_indices_np, bootstrap_discounts_np = build_n_step_targets(
        rewards=rewards,
        dones=transitions.dones,
        gamma=gamma,
        n_step=value_n_step,
    )

    value_net = ValueNet(
        input_dim=norm_states.shape[1],
        k=num_rewards,
        hidden_dims=hidden_dims,
        adapter_hidden_dim=adapter_hidden_dim,
    ).to(device)
    target_value_net = clone_model(value_net).to(device)
    optimizer = torch.optim.Adam(value_net.parameters(), lr=learning_rate)
    reward_tensor = torch.as_tensor(rewards, dtype=torch.float32)
    value_losses: list[float] = []
    n_step_returns_t = torch.as_tensor(n_step_returns_np, dtype=torch.float32, device=device)
    bootstrap_indices_t = torch.as_tensor(bootstrap_indices_np, dtype=torch.long, device=device)
    bootstrap_discounts_t = torch.as_tensor(bootstrap_discounts_np, dtype=torch.float32, device=device)
    num_samples = int(norm_states.shape[0])
    for epoch in range(value_epochs):
        epoch_losses: list[float] = []
        batch_order = np.random.permutation(num_samples)
        for batch_start in range(0, num_samples, batch_size):
            batch_indices_np = batch_order[batch_start : batch_start + batch_size]
            batch_indices = torch.as_tensor(batch_indices_np, dtype=torch.long, device=device)
            states_b = normalized_state_tensor[batch_indices]

            with torch.no_grad():
                bootstrap_values = torch.zeros((batch_indices.shape[0], num_rewards), dtype=torch.float32, device=device)
                batch_bootstrap_indices = bootstrap_indices_t[batch_indices]
                valid_bootstrap = batch_bootstrap_indices >= 0
                if torch.any(valid_bootstrap):
                    bootstrap_next_states = normalized_next_state_tensor[batch_bootstrap_indices[valid_bootstrap]]
                    bootstrap_values[valid_bootstrap] = target_value_net(bootstrap_next_states)
                td_target = n_step_returns_t[batch_indices] + bootstrap_discounts_t[batch_indices] * bootstrap_values

            pred_v = value_net(states_b)
            loss = F.smooth_l1_loss(pred_v, td_target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            soft_update(target_value_net, value_net, tau=target_tau)
            epoch_losses.append(float(loss.item()))

        mean_loss = float(np.mean(epoch_losses)) if epoch_losses else 0.0
        value_losses.append(mean_loss)
        print(f"[VPS] value epoch {epoch + 1}/{value_epochs} loss={mean_loss:.6f}")
        should_snapshot_value = (
            on_value_fit is not None
            and int(value_snapshot_freq) > 0
            and ((epoch + 1) % int(value_snapshot_freq) == 0 or (epoch + 1) == int(value_epochs))
        )
        if should_snapshot_value:
            with torch.no_grad():
                value_features = value_net(normalized_state_tensor).cpu().numpy().astype(np.float32)
            on_value_fit(value_features, np.asarray(value_losses, dtype=np.float32), int(epoch + 1))

    with torch.no_grad():
        value_features = value_net(normalized_state_tensor).cpu().numpy().astype(np.float32)

    if prob_vps:
        vps_net = ProbVPSNet(
            input_dim=norm_states.shape[1],
            k=num_rewards,
            hidden_dims=hidden_dims,
            adapter_hidden_dim=adapter_hidden_dim,
            log_eps=prob_vps_log_eps,
            min_logvar=prob_vps_min_logvar,
            max_logvar=prob_vps_max_logvar,
        ).to(device)
    else:
        vps_net = VPSNet(
            input_dim=norm_states.shape[1],
            k=num_rewards,
            hidden_dims=hidden_dims,
            adapter_hidden_dim=adapter_hidden_dim,
        ).to(device)
    vps_net.backbone.load_state_dict(value_net.backbone.state_dict())
    if freeze_vps_backbone:
        for param in vps_net.backbone.parameters():
            param.requires_grad_(False)
        if prob_vps:
            vps_parameters = list(vps_net.mean_head.parameters()) + list(vps_net.logvar_head.parameters())
        else:
            vps_parameters = vps_net.head.parameters()
    else:
        vps_parameters = vps_net.parameters()
    vps_optimizer = torch.optim.Adam(vps_parameters, lr=learning_rate)
    vps_losses: list[float] = []

    for epoch in range(vps_epochs):
        epoch_losses = []
        batch_order = np.random.permutation(num_samples)
        for batch_start in range(0, num_samples, batch_size):
            batch_indices_np = batch_order[batch_start : batch_start + batch_size]
            batch_indices = torch.as_tensor(batch_indices_np, dtype=torch.long, device=device)
            states_b = normalized_state_tensor[batch_indices]
            next_states_b = normalized_next_state_tensor[batch_indices]
            dones_b = torch.as_tensor(transitions.dones[batch_indices_np], dtype=torch.float32, device=device)
            with torch.no_grad():
                v_s = value_net(states_b)
                v_next = value_net(next_states_b)
                target_phi = ((1.0 - dones_b) * v_next - v_s) ** 2
            pred_phi = vps_net(states_b)
            if prob_vps:
                target_log_phi = torch.log(target_phi + float(prob_vps_log_eps))
                pred_mu, pred_logvar = vps_net.distribution_params(states_b)
                inv_var = torch.exp(-pred_logvar)
                loss = 0.5 * (pred_logvar + (target_log_phi - pred_mu).pow(2) * inv_var)
                loss = loss.mean()
            else:
                loss = F.smooth_l1_loss(pred_phi, target_phi)
            if smooth_vps:
                pred_phi_next = vps_net(next_states_b)
                smooth_mask = 1.0 - dones_b
                smooth_loss = ((pred_phi_next - pred_phi).pow(2) * smooth_mask).mean()
                loss = loss + float(smooth_vps_coef) * smooth_loss
            vps_optimizer.zero_grad()
            loss.backward()
            vps_optimizer.step()
            epoch_losses.append(float(loss.item()))

        mean_loss = float(np.mean(epoch_losses)) if epoch_losses else 0.0
        vps_losses.append(mean_loss)
        print(f"[VPS] phi epoch {epoch + 1}/{vps_epochs} loss={mean_loss:.6f}")
        should_snapshot_vps = (
            on_vps_fit is not None
            and int(vps_snapshot_freq) > 0
            and ((epoch + 1) % int(vps_snapshot_freq) == 0 or (epoch + 1) == int(vps_epochs))
        )
        if should_snapshot_vps:
            with torch.no_grad():
                vps_features = vps_net(normalized_state_tensor).cpu().numpy().astype(np.float32)
            on_vps_fit(vps_features, np.asarray(vps_losses, dtype=np.float32), int(epoch + 1))

    with torch.no_grad():
        vps_features = vps_net(normalized_state_tensor).cpu().numpy().astype(np.float32)
        vps_next_features = vps_net(normalized_next_state_tensor).cpu().numpy().astype(np.float32)
    vps_deltas = vps_next_features - vps_features
    vps_delta_mean = vps_deltas.mean(axis=0, keepdims=True).astype(np.float32)
    vps_delta_std = np.maximum(vps_deltas.std(axis=0, keepdims=True), 1e-6).astype(np.float32)

    checkpoint_path = os.path.join(save_dir, "pointmaze_vps_models.pt")
    with open(checkpoint_path, "wb") as f:
        torch.save(
            {
                "value_net": value_net.state_dict(),
                "target_value_net": target_value_net.state_dict(),
                "vps_net": vps_net.state_dict(),
                "rff_state_dict": rff.state_dict(),
                "state_mean": state_mean,
                "state_std": state_std,
                "reward_mean": reward_mean,
                "reward_std": reward_std,
                "vps_delta_mean": vps_delta_mean,
                "vps_delta_std": vps_delta_std,
                "config": {
                    "num_rewards": num_rewards,
                    "gamma": gamma,
                    "hidden_dims": list(hidden_dims),
                    "adapter_hidden_dim": int(adapter_hidden_dim),
                    "rff_sigma": rff_sigma,
                    "value_n_step": int(value_n_step),
                    "freeze_vps_backbone": bool(freeze_vps_backbone),
                    "prob_vps": bool(prob_vps),
                    "prob_vps_log_eps": float(prob_vps_log_eps),
                    "prob_vps_min_logvar": float(prob_vps_min_logvar),
                    "prob_vps_max_logvar": float(prob_vps_max_logvar),
                    "xy_rff": bool(xy_rff),
                    "reward_normalization": str(reward_normalization),
                    "reward_quantile_low": float(reward_quantile_low),
                    "reward_quantile_high": float(reward_quantile_high),
                    "smooth_vps": bool(smooth_vps),
                    "smooth_vps_coef": float(smooth_vps_coef),
                    "maze_map": maze_map,
                },
            },
            f,
        )

    outputs = VPSTrainOutputs(
        value_features=value_features,
        vps_features=vps_features,
        reward_features=reward_tensor.numpy(),
        state_mean=state_mean,
        state_std=state_std,
        reward_mean=reward_mean,
        reward_std=reward_std,
        vps_delta_mean=vps_delta_mean,
        vps_delta_std=vps_delta_std,
        value_losses=np.asarray(value_losses, dtype=np.float32),
        vps_losses=np.asarray(vps_losses, dtype=np.float32),
    )
    return outputs, checkpoint_path


def save_vps_artifacts(
    save_dir: str,
    env_id: str,
    transitions: ReplayTransitions,
    outputs: VPSTrainOutputs,
    maze_map: list[list[int | str]] | None = None,
) -> str:
    """Save PointMaze replay samples and fitted VPS diagnostics to disk."""
    artifact_path = os.path.join(save_dir, "pointmaze_vps_artifacts.npz")
    np.savez_compressed(
        artifact_path,
        env_id=np.asarray(env_id),
        states=transitions.states.astype(np.float32),
        next_states=transitions.next_states.astype(np.float32),
        actions=transitions.actions.astype(np.float32),
        dones=transitions.dones.astype(np.float32),
        achieved_goals=(
            None if transitions.achieved_goals is None else transitions.achieved_goals.astype(np.float32)
        ),
        desired_goals=(
            None if transitions.desired_goals is None else transitions.desired_goals.astype(np.float32)
        ),
        value_features=outputs.value_features.astype(np.float32),
        vps_features=outputs.vps_features.astype(np.float32),
        reward_features=outputs.reward_features.astype(np.float32),
        state_mean=outputs.state_mean.astype(np.float32),
        state_std=outputs.state_std.astype(np.float32),
        reward_mean=outputs.reward_mean.astype(np.float32),
        reward_std=outputs.reward_std.astype(np.float32),
        vps_delta_mean=outputs.vps_delta_mean.astype(np.float32),
        vps_delta_std=outputs.vps_delta_std.astype(np.float32),
        reward_scale=outputs.reward_std.astype(np.float32),
        value_losses=outputs.value_losses.astype(np.float32),
        vps_losses=outputs.vps_losses.astype(np.float32),
        maze_map=np.asarray(maze_map, dtype=object),
    )
    return artifact_path
