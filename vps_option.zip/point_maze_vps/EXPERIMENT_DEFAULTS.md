# PointMaze VPS / DIAYN — default hyperparameters (from code)

This document lists **CLI defaults** in `point_maze_vps/` as of the current codebase. Values taken from `argparse` definitions and fixed logic in `main()`; if your paper runs used different flags, override the corresponding rows.

**Script map (typical paper figures)**

| Figure type | Primary entry points |
|-------------|---------------------|
| VPS φ / Value heatmaps on the maze | `python -m point_maze_vps pretrain vps` → `value_heatmaps/`, `vps_heatmaps/` (or `plot heatmaps` on `pointmaze_vps_artifacts.npz`) |
| VPS option & DIAYN skill rollout trajectories | `python -m point_maze_vps plot rollouts vps|diayn` (or pipeline GIFs when `--gif_freq > 0`) |
| SAC vs SAC+DIAYN vs SAC+VPS reward curves | `python -m point_maze_vps downstream compare --run_method all` → `option_goal_reaching_results/return_curves/` |

---

## 1. Environment & maze

| Item | Default (code) | Source |
|------|----------------|--------|
| Env selector | `--env_id custom` | `python -m point_maze_vps pretrain|downstream|plot` |
| Backend env id | `PointMaze_UMaze-v3` | `utils.DEFAULT_CUSTOM_POINTMAZE_BACKEND` when `env_id=custom` |
| Custom layout | `maze_maps/custom.json` | `--maze_json` default (path relative to `point_maze_vps/`) |
| Pretraining episode horizon | **300** steps | `--max_episode_steps` (pipeline) |
| Downstream episode horizon | **1000** steps | `downstream compare` (`downstream.py`) |
| Continuing task | `continuing_task=True` | `make_option_env_factory`, DIAYN / rollout envs |

**Observation (option / VPS fitting env)**  
`PointMazeObsOnlyWrapper` exposes only the 4-D Box `observation` from Gymnasium-Robotics PointMaze (agent position + velocity in the native dict observation). Goal / waypoint targets for downstream are injected via `desired_goal` in the dict observation used by SAC (`MultiInputPolicy`).

**Action**  
Continuous torque from the registered PointMaze env (`env.action_space`); no extra tanh/clipping layer in this repo beyond what the env / SB3 SAC apply.

---

## 2. Downstream task: four ordered waypoints

Used by `SequentialWaypointPointMazeWrapper` in `downstream.py` for reward-curve experiments.

| Item | Default |
|------|---------|
| Waypoints (row, col), in order | **(4,2) → (6,4) → (4,6) → (2,4)** |
| Flat CLI list | `--waypoint_cells 4 2 6 4 4 6 2 4` |
| Success radius | **1.0** (L2 in maze XY) | `--waypoint_radius` in `run_point_maze_diayn_goal_reaching.py` |
| Compare-script radius | **1.0** | `compare_point_maze_options.py` (was 0.45 in `build_goal_env` fallback only when arg missing) |
| Reward | Sparse **+1** per waypoint, **in order**; no step penalty; no repeat bonus |
| Max episodic return | **4** (terminate after 4th waypoint) | `utils.MAX_WAYPOINT_EPISODE_REWARD` |
| Start cell | **(2, 2)** unless `--random_init` | `--fixed_start_cell` |
| Success metric | `info["success"]` when all 4 reached; eval fallback `episode_reward ≥ 4` | `env_success_from_info` |

---

## 3. Phase A — VPS pretraining (`run_point_maze_vps_pipeline.py --method vps`)

### 3.1 Random-walk dataset

| Parameter | Default |
|-----------|---------|
| Transitions collected | **500,000** | `--buffer_size` |
| Action sampling | Uniform in `action_space` | `random_walk_collector.py` |
| Collection seed | `--seed` (default **0**) |

### 3.2 RFF random rewards

| Parameter | Default |
|-----------|---------|
| Number of reward heads \(K\) | **`num_options // 2` = 4** when dual-sign is on (see below) |
| `--num_options` | **8** → **4 heads**, **8 policies** (±) |
| RFF input | **(x, y)** only | `--xy_rff` (default **on**; `--no_xy_rff` uses full normalized state) |
| Feature map | \(\sqrt{2/K}\cos(Wx + b)\), \(W_{ij} \sim \mathcal{N}(0,\sigma^2)\), \(b_j \sim \mathrm{Unif}[0,2\pi)\) | `StateRFFLayer` |
| `--rff_sigma` | **0.001** |
| Reward at terminal transitions | **0** |
| Per-head normalization | **std** over non-terminal samples | `--reward_normalization std` |
| Quantile bounds (if used) | 0.05 / 0.95 | `--reward_quantile_low/high` |

### 3.3 Offline Value fitting

| Parameter | Default |
|-----------|---------|
| Discount \(\gamma_V\) | **0.999** | `--vps_gamma` |
| Optimizer | Adam, lr **1e-3** | `--vps_learning_rate` |
| Minibatch size | **256** | `--vps_batch_size` |
| Training epochs | **50** | `--value_epochs` |
| TD target | **5-step** return + bootstrapped \(V(s')\) | `--value_n_step 5` |
| Target network Polyak \(\tau\) | **0.02** | `--target_tau` |
| Value loss | Huber (smooth L1) | `offline_vps.py` |
| Network | Shared MLP trunk **(256, 256)** + per-head adapter hidden **256** | `--hidden_dims`, `--adapter_hidden_dim` |

### 3.4 Offline VPS fitting

| Parameter | Default |
|-----------|---------|
| VPS target (per head) | \(\phi(s) = \big((1-\mathrm{done})\,V(s') - V(s)\big)^2\) | `offline_vps.py` |
| VPS loss | Smooth L1 on \(\phi\) (not probabilistic by default) | `--prob_vps` off unless set |
| VPS epochs | **50** | `--vps_epochs` |
| Backbone | Initialized from Value net; **not frozen** by default | `--freeze_vps_backbone` optional |
| Smoothness regularizer | **off** (coef **0.1** if `--smooth_vps`) | `--smooth_vps_coef` |
| Periodic heatmap snapshots | Every **10** epochs | `--heatmap_save_freq 10` |

### 3.5 VPS option policies (SAC on intrinsic reward)

| Parameter | Default |
|-----------|---------|
| Steps per option | **500,000** | `--option_timesteps` |
| Discount \(\gamma_Q\) | **0.99** | `--option_gamma` |
| Learning rate | **3e-4** | `--option_learning_rate` |
| Replay buffer | **200,000** | `--option_buffer_size` |
| Learning starts | **1,000** | `--option_learning_starts` |
| Batch size | **256** | `--option_batch_size` |
| Target \(\tau\) | **0.005** | `--option_tau` |
| Policy / critic MLP | **(256, 256)** | `--policy_hidden_dims` |
| Intrinsic reward | `reward_scale × sign × Δφ`, optional ÷ per-head `vps_delta_std` | `--reward_scale 1.0`, `--normalize_option_rewards` **on** |
| Dual sign options | **on** (± per head) | default; disable with `--no_dual_sign` |
| Eval during training | Every **100,000** steps, **5** episodes | `--option_eval_freq`, `--eval_episodes` |
| Rollout trajectory plots | Every **100,000** steps if enabled | `--rollout_plot_freq 100000` |

**Exported count:** `--num_options 8` + dual-sign → train **8** SAC policies from **4** RFF heads.

---

## 4. Phase B — DIAYN pretraining (`run_point_maze_vps_pipeline.py --method diayn`)

| Parameter | Default |
|-----------|---------|
| Skills / exported policies | **8** | `--num_options` |
| Total env steps | **500,000** | `--diayn_timesteps` (defaults to `option_timesteps`) |
| SAC \(\gamma\) | **0.99** | `--option_gamma` |
| SAC lr | **3e-4** | `--option_learning_rate` |
| Buffer / batch / starts | **200k / 256 / 1000** | same flags as VPS options |
| Policy MLP | **(256, 256)** | `--policy_hidden_dims` |
| Intrinsic reward | `reward_scale × (log q_\psi(z|s) - log 1/|Z|)` | `DIAYNSkillWrapper`, `--reward_scale 1.0` |
| Discriminator lr | **3e-4** | `--disc_learning_rate` |
| Discriminator MLP | **(256, 256)** | `--disc_hidden_dims` |
| Discriminator batch | **256** | `--disc_batch_size` |
| Discriminator updates | **1** every **1** env step | `--disc_update_freq`, `--disc_updates_per_step` |
| Skill observation | `[4-D state, one-hot(skill)]` | `DIAYNSkillWrapper` |
| Eval episodes per skill | **5** | `--eval_episodes` |

Heatmaps / occupancy plots are written under `diayn_heatmaps/`, `diayn_rollouts/` during export.

---

## 5. Visualization defaults (paper-style figures)

### 5.1 VPS / Value spatial maps (`plotting.py` via pipeline or `plot heatmaps`)

| Parameter | Default |
|-----------|---------|
| Projection | **continuous** | `--projection_mode` |
| Spatial bins | **40 × 40** | `--bins` |
| Options per figure | up to **4** | `--plot_max_options` |
| Figure DPI | **200** | `--dpi` |

### 5.2 Option / skill rollout plots

| CLI | Parameter | Default |
|-----|-----------|---------|
| `plot rollouts vps` | Rollout length | **500** steps (`--rollout_steps`) |
| | Rollouts per option | **5** (`--num_rollouts`) |
| | Option run seed | `--option_seed` (optional `__seedN` suffix) |
| | Plot seed | **0** (`--seed`) |
| | `max_episode_steps` | **500** |
| `plot rollouts diayn` | Same structure | `--option_seed` optional |
| Pipeline GIFs (optional) | `--gif_freq` | **0** (off); `--gif_max_steps 600`, `--gif_fps 10` |

Policies loaded from `pretrained_option_bank/vps` or `.../diayn` (deterministic action unless `--option_stochastic`).

---

## 6. Downstream reward curves — primary (`python -m point_maze_vps downstream compare`)

This is the script tied to `option_goal_reaching_results/` and aggregated curves under `return_curves/`.

### 6.1 Training budget & optimization

| Parameter | Default |
|-----------|---------|
| Primitive env steps | **500,000** | `--total_timesteps` |
| Random seeds | **1** run (`--seed 0`, `--num_seeds 1`, `--seed_stride 1`) |
| SAC discount \(\gamma\) | **0.95** |
| Learning rate | **1e-3** |
| Replay buffer | **500,000** |
| Learning starts | **1,000** |
| Batch size | **256** |
| Target \(\tau\) | **0.005** |
| Policy MLP | **(256, 256)** |
| HER | **Forced off** in `main()` (`args.no_HER = True`) despite `--her_k 4` in parser |

### 6.2 Option / skill exploration intervention (SAC+DIAYN / SAC+VPS)

| Parameter | Default |
|-----------|---------|
| Trigger probability schedule | **0.1 → 0.005** over **40,000** steps | `--option_trigger_prob 0.1 0.005 40000` |
| Max primitive steps per intervention | **500** | `--option_max_steps` |
| Early termination prob. per step | **1/500** | `--option_termination_prob` |
| Option actions | **Deterministic** unless `--option_stochastic` |
| Option warmup before `learning_starts` | **on** unless `--disable_option_warmup` |
| Pretrained banks | `pretrained_option_bank/diayn`, `pretrained_option_bank/vps` | `--diayn_option_bank_dir`, `--vps_option_bank_dir` |

### 6.3 Evaluation & logging

| Parameter | Default |
|-----------|---------|
| Eval every | **5,000** steps | `--eval_freq` |
| Eval episodes | **5** | `--eval_episodes` |
| Return-curve export | Per-method folders under `save_dir/return_curves/{SAC,DIAYN,VPS}/` | `export_method_return_curves` |
| Reward plot smoothing | **1** (no extra MA) | `--reward_smoothing_window` |

**Typical multi-seed aggregation:** `--num_seeds 5`; stored curves are aggregated with `python -m point_maze_vps plot aggregate-curves` (default root `option_goal_reaching_results/return_curves`).

### 6.4 Optional meta-control (`--meta_control`)

High-level **DQN** selects which option/skill to run for up to `option_max_steps` primitives; terminates early on waypoint hit. Extra defaults: exploration fraction **0.1**, \(\epsilon\) **1.0 → 0.05**, target update every **1000** steps. Not enabled unless flag is set.

---

## 7. Alternate downstream CLI (`compare_point_maze_options.py`)

Use this row only if your curves came from **`comparison_results/`**, not `option_goal_reaching_results/`.

| Parameter | Default (differs from §6) |
|-----------|---------------------------|
| `--total_timesteps` | **100,000** |
| `--gamma` | **0.99** |
| `--learning_rate` | **3e-4** |
| `--buffer_size` | **100,000** |
| `--num_seeds` | **5** |
| HER | **on** unless `--no_HER` |
| `--her_k` | **4** |
| Option trigger | **0.005 → 0.005** over **1** step |
| `--option_max_steps` | **50** |
| `--eval_freq` | **10,000** |
| `--eval_episodes` | **10** |

---

## 8. Quick reference — discount factors

| Stage | Symbol | Default |
|-------|--------|---------|
| Offline Value (VPS pretrain) | \(\gamma_V\) | **0.999** |
| VPS / DIAYN option SAC | \(\gamma_Q\) | **0.99** |
| Downstream SAC (`run_point_maze_diayn_goal_reaching`) | \(\gamma\) | **0.95** |
| Downstream SAC (`compare_point_maze_options`) | \(\gamma\) | **0.99** |

---

## 9. Suggested one-line commands (defaults only)

```bash
# VPS maps + 8 options (4 RFF heads, ±)
python -m point_maze_vps pretrain vps

# DIAYN 8 skills
python -m point_maze_vps pretrain diayn

# Downstream SAC / SAC+DIAYN / SAC+VPS curves (all methods)
python -m point_maze_vps downstream compare --run_method all

# Aggregate saved return curves
python -m point_maze_vps plot aggregate-curves

# Rollout figure grids
python -m point_maze_vps plot rollouts vps --option_bank_dir pretrained_option_bank/vps
python -m point_maze_vps plot rollouts diayn --option_bank_dir pretrained_option_bank/diayn
```

---

## 10. Not fixed in code (check your run configs)

- Exact **custom maze** JSON on disk (`maze_maps/custom.json` may be missing in a fresh clone; layout is whatever you pass to `--maze_json`).
- **Wall-clock training time** (depends on GPU / CPU).
- Whether paper figures used **`num_seeds > 1`** or edited CLI flags — inspect saved `option_goal_reaching_summary.json` / `run_config.json` under each result directory.
