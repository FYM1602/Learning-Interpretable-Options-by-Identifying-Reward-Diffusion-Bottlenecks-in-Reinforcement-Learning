from __future__ import annotations

from collections import defaultdict
from typing import Any

import numpy as np
from gymnasium import spaces
from stable_baselines3 import SAC
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.noise import ActionNoise, VectorizedActionNoise
from stable_baselines3.common.off_policy_algorithm import should_collect_more_steps
from stable_baselines3.common.type_aliases import RolloutReturn, TrainFreq, TrainFrequencyUnit
from stable_baselines3.common.vec_env import VecEnv

try:
    from .option_bank import OptionBankEntry
except ImportError:  # pragma: no cover
    from option_bank import OptionBankEntry


class OptionInterventionSAC(SAC):
    """SAC that occasionally replaces exploration actions with pretrained option actions."""

    def __init__(
        self,
        *,
        option_bank: list[OptionBankEntry] | None = None,
        option_trigger_prob: tuple[float, float, float] | list[float] = (0.1, 0.1, 1.0),
        option_max_steps: int = 50,
        option_termination_prob: float = 1.0 / 50.0,
        option_deterministic: bool = True,
        option_use_during_warmup: bool = True,
        option_seed: int = 0,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.option_bank = list(option_bank or [])
        if len(option_trigger_prob) != 3:
            raise ValueError(
                "`option_trigger_prob` must contain exactly three values: "
                "[initial_prob, terminal_prob, anneal_steps]."
            )
        self.option_trigger_prob = tuple(float(value) for value in option_trigger_prob)
        self.option_max_steps = max(int(option_max_steps), 1)
        self.option_termination_prob = float(option_termination_prob)
        self.option_deterministic = bool(option_deterministic)
        self.option_use_during_warmup = bool(option_use_during_warmup)
        self._option_rng = np.random.default_rng(option_seed)
        self._active_option_index: int | None = None
        self._active_option_steps_left = 0
        self._option_total_steps = 0
        self._option_total_starts = 0
        self._option_steps_by_name: dict[str, int] = defaultdict(int)
        self._option_starts_by_name: dict[str, int] = defaultdict(int)

    def _reset_active_option(self) -> None:
        """Clear any currently running option rollout."""
        self._active_option_index = None
        self._active_option_steps_left = 0

    def _extract_single_option_obs(self) -> np.ndarray:
        """Extract the 4-D observation expected by the pretrained option policy."""
        obs = self._last_obs
        if not isinstance(obs, dict) or "observation" not in obs:
            raise ValueError(
                "Option intervention requires PointMaze dict observations with an `observation` key."
            )
        obs_value = np.asarray(obs["observation"], dtype=np.float32)
        if obs_value.ndim == 1:
            return obs_value
        if obs_value.ndim == 2 and obs_value.shape[0] == 1:
            return obs_value[0]
        raise ValueError(
            "Option intervention currently supports exactly one environment. "
            f"Received observation shape {obs_value.shape!r}."
        )

    def _maybe_select_option(self, learning_starts: int) -> OptionBankEntry | None:
        """Return the currently active option, optionally starting a new one."""
        if not self.option_bank:
            return None
        if self.num_timesteps < learning_starts and not self.option_use_during_warmup:
            self._reset_active_option()
            return None

        if self._active_option_index is None or self._active_option_steps_left <= 0:
            if self._option_rng.random() >= self._current_option_trigger_prob():
                self._reset_active_option()
                return None
            self._active_option_index = int(self._option_rng.integers(len(self.option_bank)))
            self._active_option_steps_left = self.option_max_steps
            entry = self.option_bank[self._active_option_index]
            self._option_total_starts += 1
            self._option_starts_by_name[entry.name] += 1

        return self.option_bank[self._active_option_index]

    def _current_option_trigger_prob(self) -> float:
        """Linearly anneal the option trigger probability over environment steps."""
        initial_prob, terminal_prob, anneal_steps = self.option_trigger_prob
        anneal_horizon = max(float(anneal_steps), 1.0)
        progress = min(max(float(self.num_timesteps), 0.0) / anneal_horizon, 1.0)
        return float(initial_prob + (terminal_prob - initial_prob) * progress)

    def _sample_action(
        self,
        learning_starts: int,
        action_noise: ActionNoise | None = None,
        n_envs: int = 1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Sample an action, optionally replacing it with a pretrained option action."""
        if n_envs != 1:
            return super()._sample_action(learning_starts, action_noise, n_envs)
        if not isinstance(self.action_space, spaces.Box):
            return super()._sample_action(learning_starts, action_noise, n_envs)

        option_entry = self._maybe_select_option(learning_starts)
        if option_entry is None:
            return super()._sample_action(learning_starts, action_noise, n_envs)

        option_obs = self._extract_single_option_obs()
        option_action, _ = option_entry.model.predict(option_obs, deterministic=self.option_deterministic)
        env_action = np.asarray(option_action, dtype=np.float32).reshape((n_envs, *self.action_space.shape))
        env_action = np.clip(env_action, self.action_space.low, self.action_space.high)
        buffer_action = self.policy.scale_action(env_action)

        self._active_option_steps_left -= 1
        self._option_total_steps += 1
        self._option_steps_by_name[option_entry.name] += 1
        if self._active_option_steps_left <= 0 or self._option_rng.random() < self.option_termination_prob:
            self._reset_active_option()
        return env_action, buffer_action

    def get_option_intervention_summary(self) -> dict[str, Any]:
        """Return cumulative option-intervention statistics."""
        return {
            "total_option_steps": int(self._option_total_steps),
            "total_option_starts": int(self._option_total_starts),
            "steps_by_option": dict(sorted(self._option_steps_by_name.items())),
            "starts_by_option": dict(sorted(self._option_starts_by_name.items())),
            "trigger_prob_schedule": [float(value) for value in self.option_trigger_prob],
            "current_trigger_prob": float(self._current_option_trigger_prob()),
            "option_termination_prob": float(self.option_termination_prob),
            "option_max_steps": int(self.option_max_steps),
            "option_deterministic": bool(self.option_deterministic),
            "option_use_during_warmup": bool(self.option_use_during_warmup),
        }

    def collect_rollouts(
        self,
        env: VecEnv,
        callback: BaseCallback,
        train_freq: TrainFreq,
        replay_buffer,
        action_noise: ActionNoise | None = None,
        learning_starts: int = 0,
        log_interval: int | None = None,
    ) -> RolloutReturn:
        """Collect rollouts while resetting active options at episode boundaries."""
        self.policy.set_training_mode(False)
        num_collected_steps, num_collected_episodes = 0, 0

        assert isinstance(env, VecEnv), "You must pass a VecEnv"
        assert train_freq.frequency > 0, "Should at least collect one step or episode."
        if env.num_envs > 1:
            raise ValueError("OptionInterventionSAC currently supports exactly one environment.")
        if env.num_envs > 1 and train_freq.unit != TrainFrequencyUnit.STEP:
            raise AssertionError("You must use only one env when doing episodic training.")

        if action_noise is not None and env.num_envs > 1 and not isinstance(action_noise, VectorizedActionNoise):
            action_noise = VectorizedActionNoise(action_noise, env.num_envs)

        if self.use_sde:
            self.actor.reset_noise(env.num_envs)

        callback.on_rollout_start()
        continue_training = True
        while should_collect_more_steps(train_freq, num_collected_steps, num_collected_episodes):
            if self.use_sde and self.sde_sample_freq > 0 and num_collected_steps % self.sde_sample_freq == 0:
                self.actor.reset_noise(env.num_envs)

            actions, buffer_actions = self._sample_action(learning_starts, action_noise, env.num_envs)
            new_obs, rewards, dones, infos = env.step(actions)

            self.num_timesteps += env.num_envs
            num_collected_steps += 1

            callback.update_locals(locals())
            if callback.on_step() is False:
                return RolloutReturn(num_collected_steps * env.num_envs, num_collected_episodes, continue_training=False)

            self._update_info_buffer(infos, dones)
            self._store_transition(replay_buffer, buffer_actions, new_obs, rewards, dones, infos)
            self._update_current_progress_remaining(self.num_timesteps, self._total_timesteps)
            self._on_step()

            for idx, done in enumerate(dones):
                if done:
                    self._reset_active_option()
                    num_collected_episodes += 1
                    self._episode_num += 1
                    if action_noise is not None:
                        kwargs = dict(indices=[idx]) if env.num_envs > 1 else {}
                        action_noise.reset(**kwargs)
                    if log_interval is not None and self._episode_num % log_interval == 0:
                        self._dump_logs()

        callback.on_rollout_end()
        return RolloutReturn(num_collected_steps * env.num_envs, num_collected_episodes, continue_training)
