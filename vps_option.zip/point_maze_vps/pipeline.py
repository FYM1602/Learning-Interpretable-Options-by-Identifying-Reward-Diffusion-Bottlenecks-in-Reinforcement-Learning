#!/usr/bin/env python
"""Unified PointMaze option pretraining entrypoint for VPS and DIAYN."""

from __future__ import annotations

import argparse
import os
import time
from types import SimpleNamespace

import torch

try:
    from .diayn_training import (
        DIAYNSkillSpec,
        evaluate_exported_skill,
        export_skill_model,
        plot_skill_occupancy,
        plot_skill_trajectories,
        prepare_gif_capture,
        save_diayn_run_summary,
        save_skill_eval_metrics,
        train_diayn_model,
    )
    from .offline_vps import fit_pointmaze_vps, save_vps_artifacts
    from .option_training import (
        can_enable_gif_capture,
        configure_mujoco_gl_for_gif,
        load_vps_model,
        maybe_start_virtual_display,
        option_spec_from_id,
        train_one_option,
    )
    from .maze_plotting import render_feature_grids
    from .random_walk_collector import collect_random_walk_transitions
    from .utils import (
        CUSTOM_POINTMAZE_ENV_ID,
        DEFAULT_CUSTOM_POINTMAZE_BACKEND,
        ensure_dir,
        resolve_pointmaze_env_selection,
        save_json,
        set_global_seed,
    )
except ImportError:  # pragma: no cover
    from diayn_training import (
        DIAYNSkillSpec,
        evaluate_exported_skill,
        export_skill_model,
        plot_skill_occupancy,
        plot_skill_trajectories,
        prepare_gif_capture,
        save_diayn_run_summary,
        save_skill_eval_metrics,
        train_diayn_model,
    )
    from offline_vps import fit_pointmaze_vps, save_vps_artifacts
    from option_training import (
        can_enable_gif_capture,
        configure_mujoco_gl_for_gif,
        load_vps_model,
        maybe_start_virtual_display,
        option_spec_from_id,
        train_one_option,
    )
    from maze_plotting import render_feature_grids
    from random_walk_collector import collect_random_walk_transitions
    from utils import (
        CUSTOM_POINTMAZE_ENV_ID,
        DEFAULT_CUSTOM_POINTMAZE_BACKEND,
        ensure_dir,
        resolve_pointmaze_env_selection,
        save_json,
        set_global_seed,
    )


def build_arg_parser() -> argparse.ArgumentParser:
    """Create a single CLI for VPS and DIAYN option pretraining."""
    parser = argparse.ArgumentParser(
        description=(
            "Pretrain PointMaze options using either VPS (random walk + value/VPS fitting) "
            "or DIAYN (joint skill discovery), then export all options to a local bank."
        )
    )
    parser.add_argument("--method", choices=("vps", "diayn"), required=True, help="Option pretraining method.")
    parser.add_argument(
        "--env_id",
        default=CUSTOM_POINTMAZE_ENV_ID,
        help=(
            "PointMaze environment selector. Use `custom` to load `--maze_json` "
            f"(default backend: `{DEFAULT_CUSTOM_POINTMAZE_BACKEND}`), or pass a "
            "registered env name such as `PointMaze_UMaze-v3`."
        ),
    )
    parser.add_argument(
        "--maze_json",
        default=os.path.join("maze_maps", "custom.json"),
        help="Path to a custom PointMaze `maze_map` JSON. Used only when `--env_id custom`.",
    )
    parser.add_argument("--seed", type=int, default=0, help="Random seed used across the full pretraining pipeline.")
    parser.add_argument("--device", default="auto", help="Torch device for pretraining and option export.")
    parser.add_argument(
        "--save_dir",
        default=None,
        help=(
            "Root directory for this method's outputs. Default: `pretrained_option_bank/<method>` "
            "next to this script."
        ),
    )
    parser.add_argument("--max_episode_steps", type=int, default=300, help="Fixed episode horizon for pretraining and export.")
    parser.add_argument("--num_options", type=int, default=8, help="Number of exported options/skills.")

    parser.add_argument("--option_timesteps", type=int, default=500000, help="Environment steps per exported option policy or DIAYN fairness budget.")
    parser.add_argument("--option_learning_rate", type=float, default=3e-4, help="SAC learning rate for option or DIAYN policy training.")
    parser.add_argument("--option_buffer_size", type=int, default=200_000, help="Replay buffer capacity for option or DIAYN policy training.")
    parser.add_argument("--option_learning_starts", type=int, default=1_000, help="Delay SAC learning until this many steps are collected.")
    parser.add_argument("--option_batch_size", type=int, default=256, help="SAC minibatch size.")
    parser.add_argument("--option_gamma", type=float, default=0.99, help="SAC discount factor.")
    parser.add_argument("--option_tau", type=float, default=0.005, help="SAC target-network update rate.")
    parser.add_argument("--option_gradient_steps", type=int, default=1, help="Gradient steps per rollout step.")
    parser.add_argument("--policy_hidden_dims", type=int, nargs="+", default=[256, 256], help="Hidden sizes for option/skill policy and critic MLPs.")
    parser.add_argument("--eval_episodes", type=int, default=5, help="Deterministic evaluation episodes per exported option.")

    parser.add_argument("--projection_mode", choices=("continuous", "cell"), default="continuous", help="Heatmap projection mode.")
    parser.add_argument("--bins", type=int, default=40, help="Number of spatial bins for saved heatmaps.")
    parser.add_argument("--plot_max_options", type=int, default=4, help="Maximum heatmaps per saved figure for VPS outputs.")
    parser.add_argument("--dpi", type=int, default=200, help="Saved figure DPI.")
    parser.add_argument(
        "--heatmap_save_freq",
        type=int,
        default=10,
        help="During VPS value/phi fitting, save intermediate heatmaps every N epochs. Set 0 to disable periodic snapshots.",
    )

    parser.add_argument("--gif_freq", type=int, default=0, help="Enable final rollout GIF capture when > 0.")
    parser.add_argument("--gif_fps", type=int, default=10, help="Frames per second for saved GIFs.")
    parser.add_argument("--gif_stop_on_done", action="store_true", help="End a GIF clip immediately when an episode ends.")
    parser.add_argument("--gif_max_steps", type=int, default=600, help="Maximum rollout steps captured per GIF.")
    parser.add_argument(
        "--option_eval_freq",
        type=int,
        default=100_000,
        help="Evaluate each VPS option every N SAC steps during training.",
    )
    parser.add_argument(
        "--rollout_plot_freq",
        type=int,
        default=100_000,
        help="Save a deterministic rollout trajectory plot on every option evaluation when > 0. Set 0 to disable.",
    )
    parser.add_argument(
        "--mujoco_gl",
        type=str,
        default="auto",
        choices=["auto", "egl", "osmesa", "glfw"],
        help="MuJoCo rendering backend to use for GIF capture.",
    )

    parser.add_argument("--reward_scale", type=float, default=1.0, help="Scale factor applied to the option or DIAYN intrinsic reward.")
    parser.add_argument(
        "--normalize_option_rewards",
        dest="normalize_option_rewards",
        action="store_true",
        help="Normalize VPS option rewards by the offline per-head std of delta-phi during SAC option training.",
    )
    parser.add_argument(
        "--no_normalize_option_rewards",
        dest="normalize_option_rewards",
        action="store_false",
        help="Disable VPS delta-phi normalization during SAC option training.",
    )
    parser.set_defaults(normalize_option_rewards=True)

    parser.add_argument("--buffer_size", type=int, default=500_000, help="Number of random-walk transitions to collect for VPS.")
    parser.add_argument("--vps_gamma", type=float, default=0.999, help="Discount factor for offline Value fitting in VPS.")
    parser.add_argument("--vps_batch_size", type=int, default=256, help="Offline minibatch size for VPS fitting.")
    parser.add_argument("--value_epochs", type=int, default=50, help="Epochs for random-reward Value fitting.")
    parser.add_argument("--vps_epochs", type=int, default=50, help="Epochs for VPS fitting.")
    parser.add_argument("--vps_learning_rate", type=float, default=1e-3, help="Learning rate for Value/VPS fitting.")
    parser.add_argument("--target_tau", type=float, default=0.02, help="Target-network Polyak coefficient for Value fitting.")
    parser.add_argument("--hidden_dims", type=int, nargs="+", default=[256, 256], help="Hidden sizes for PointMaze Value/VPS MLPs.")
    parser.add_argument(
        "--adapter_hidden_dim",
        type=int,
        default=256,
        help="Hidden size for each per-head adapter on top of the shared Value/VPS trunk.",
    )
    parser.add_argument("--rff_sigma", type=float, default=0.001, help="RFF frequency scale for random rewards.")
    parser.add_argument(
        "--value_n_step",
        type=int,
        default=5,
        help="Offline n-step TD horizon for Value fitting. Set to 1 to recover the previous one-step target.",
    )
    parser.add_argument(
        "--prob_vps",
        action="store_true",
        help="Fit the VPS stage as a Gaussian model over log(phi + eps) instead of direct point regression.",
    )
    parser.add_argument(
        "--prob_vps_log_eps",
        type=float,
        default=1e-6,
        help="Numerical epsilon used in log(phi + eps) targets when `--prob_vps` is enabled.",
    )
    parser.add_argument(
        "--prob_vps_min_logvar",
        type=float,
        default=-6.0,
        help="Minimum log-variance clamp for probabilistic VPS training.",
    )
    parser.add_argument(
        "--prob_vps_max_logvar",
        type=float,
        default=2.0,
        help="Maximum log-variance clamp for probabilistic VPS training.",
    )
    parser.add_argument(
        "--reward_normalization",
        choices=("std", "range", "quantile_range"),
        default="std",
        help="How to standardize each random reward head using the full replay buffer.",
    )
    parser.add_argument("--reward_quantile_low", type=float, default=0.05, help="Lower quantile for reward normalization.")
    parser.add_argument("--reward_quantile_high", type=float, default=0.95, help="Upper quantile for reward normalization.")
    parser.add_argument("--xy_rff", dest="xy_rff", action="store_true", help="Use only the (x, y) position as input to the RFF reward layer.")
    parser.add_argument("--no_xy_rff", dest="xy_rff", action="store_false", help="Use the full state instead of only (x, y) for the RFF reward layer.")
    parser.set_defaults(xy_rff=True)
    parser.add_argument("--freeze_vps_backbone", action="store_true", help="Freeze the VPS backbone after copying ValueNet parameters.")
    parser.add_argument("--smooth_vps", action="store_true", help="Add a smoothness regularizer to VPS training.")
    parser.add_argument("--smooth_vps_coef", type=float, default=0.1, help="Weight of the VPS smoothness regularizer.")
    parser.add_argument("--no_dual_sign", action="store_true", help="Train one option per VPS head instead of dual +/- options.")

    parser.add_argument(
        "--diayn_timesteps",
        type=int,
        default=None,
        help="Total DIAYN environment steps. Default: match `option_timesteps` for equal total pretraining budget.",
    )
    parser.add_argument("--disc_learning_rate", type=float, default=3e-4, help="Learning rate for the DIAYN discriminator.")
    parser.add_argument("--disc_hidden_dims", type=int, nargs="+", default=[256, 256], help="Hidden sizes for the DIAYN discriminator.")
    parser.add_argument("--disc_batch_size", type=int, default=256, help="Discriminator minibatch size.")
    parser.add_argument("--disc_update_freq", type=int, default=1, help="Update the DIAYN discriminator every N environment steps.")
    parser.add_argument("--disc_updates_per_step", type=int, default=1, help="Discriminator gradient steps per update event.")
    return parser


def choose_device(device_arg: str) -> torch.device:
    """Resolve an `auto` device flag."""
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_arg)


def resolve_maze_json_path(maze_json: str | None) -> str | None:
    """Resolve maze JSON paths, preferring the script directory for bundled defaults."""
    if maze_json is None or not str(maze_json).strip():
        return None
    candidate = str(maze_json)
    if os.path.isabs(candidate):
        return candidate
    if os.path.exists(candidate):
        return os.path.abspath(candidate)
    script_relative = os.path.join(os.path.dirname(os.path.abspath(__file__)), candidate)
    return os.path.abspath(script_relative)


def resolve_save_dir(args: argparse.Namespace) -> str:
    """Choose a timestamped output directory under `pretrained_option_bank`."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    run_name = f"{timestamp}__{str(args.method)}__{str(args.requested_env_id).replace('/', '_').replace(':', '_')}__seed{int(args.seed)}"
    if args.save_dir:
        candidate = str(args.save_dir)
        if os.path.isabs(candidate):
            return ensure_dir(os.path.join(candidate, run_name))
        if os.path.exists(candidate):
            return ensure_dir(os.path.join(os.path.abspath(candidate), run_name))
        return ensure_dir(os.path.join(os.path.abspath(os.path.join(os.getcwd(), candidate)), run_name))
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return ensure_dir(os.path.join(script_dir, "pretrained_option_bank", str(args.method), run_name))


def build_option_train_args(args: argparse.Namespace, checkpoint_path: str, options_save_dir: str, sign_enabled: bool) -> SimpleNamespace:
    """Build the subset of args expected by `train_one_option()`."""
    return SimpleNamespace(
        checkpoint_path=checkpoint_path,
        maze_json=args.maze_json,
        max_episode_steps=args.max_episode_steps,
        reward_scale=args.reward_scale,
        normalize_option_rewards=bool(args.normalize_option_rewards),
        learning_rate=args.option_learning_rate,
        buffer_size=args.option_buffer_size,
        learning_starts=args.option_learning_starts,
        batch_size=args.option_batch_size,
        gamma=args.option_gamma,
        tau=args.option_tau,
        gradient_steps=args.option_gradient_steps,
        seed=args.seed,
        policy_hidden_dims=list(args.policy_hidden_dims),
        eval_freq=max(int(args.option_eval_freq), 1),
        eval_episodes=args.eval_episodes,
        rollout_plot_freq=max(int(args.rollout_plot_freq), 0),
        gif_freq=args.gif_freq,
        gif_fps=args.gif_fps,
        gif_stop_on_done=args.gif_stop_on_done,
        gif_max_steps=args.gif_max_steps,
        mujoco_gl=args.mujoco_gl,
        total_timesteps=args.option_timesteps,
        save_dir=options_save_dir,
        sign=sign_enabled,
        option_ids=None,
    )


def run_vps_pretraining(args: argparse.Namespace, maze_map, device: torch.device, save_dir: str) -> None:
    """Run the full random-walk -> Value/VPS -> option export pipeline."""
    sign_enabled = not bool(args.no_dual_sign)
    divisor = 2 if sign_enabled else 1
    if int(args.num_options) <= 0:
        raise ValueError("`--num_options` must be positive.")
    if sign_enabled and int(args.num_options) % 2 != 0:
        raise ValueError("When dual-sign VPS options are enabled, `--num_options` must be even.")
    num_rewards = int(args.num_options) // divisor

    options_save_dir = ensure_dir(os.path.join(save_dir, "options"))
    value_heatmap_dir = ensure_dir(os.path.join(save_dir, "value_heatmaps"))
    vps_heatmap_dir = ensure_dir(os.path.join(save_dir, "vps_heatmaps"))
    value_heatmap_paths: list[str] = []
    vps_heatmap_paths: list[str] = []

    def should_save_periodic_heatmap(epoch_idx: int, total_epochs: int) -> bool:
        freq = int(args.heatmap_save_freq)
        return freq > 0 and (epoch_idx % freq == 0 or epoch_idx == total_epochs)

    def save_value_stage_outputs(value_features, _value_losses, epoch_idx: int) -> None:
        nonlocal value_heatmap_paths
        target_dir = value_heatmap_dir
        if should_save_periodic_heatmap(epoch_idx, int(args.value_epochs)):
            target_dir = ensure_dir(os.path.join(value_heatmap_dir, f"epoch_{epoch_idx:04d}"))
        else:
            return
        value_heatmap_paths = render_feature_grids(
            states=transitions.states,
            features=value_features,
            env_id=args.env_id,
            maze_map=maze_map,
            feature_name="Value",
            save_dir=target_dir,
            projection_mode=args.projection_mode,
            bins=args.bins,
            max_options_per_figure=args.plot_max_options,
            dpi=args.dpi,
        )

    def save_vps_stage_outputs(vps_features, _vps_losses, epoch_idx: int) -> None:
        nonlocal vps_heatmap_paths
        target_dir = vps_heatmap_dir
        if should_save_periodic_heatmap(epoch_idx, int(args.vps_epochs)):
            target_dir = ensure_dir(os.path.join(vps_heatmap_dir, f"epoch_{epoch_idx:04d}"))
        else:
            return
        vps_heatmap_paths = render_feature_grids(
            states=transitions.states,
            features=vps_features,
            env_id=args.env_id,
            maze_map=maze_map,
            feature_name="VPS",
            save_dir=target_dir,
            projection_mode=args.projection_mode,
            bins=args.bins,
            max_options_per_figure=args.plot_max_options,
            dpi=args.dpi,
        )

    print(f"[Pretrain:VPS] root={save_dir}")
    transitions = collect_random_walk_transitions(
        env_id=args.env_id,
        seed=args.seed,
        buffer_size=args.buffer_size,
        max_episode_steps=args.max_episode_steps,
        maze_map=maze_map,
    )
    outputs, checkpoint_path = fit_pointmaze_vps(
        transitions=transitions,
        num_rewards=num_rewards,
        gamma=args.vps_gamma,
        batch_size=args.vps_batch_size,
        value_epochs=args.value_epochs,
        vps_epochs=args.vps_epochs,
        learning_rate=args.vps_learning_rate,
        target_tau=args.target_tau,
        hidden_dims=tuple(int(v) for v in args.hidden_dims),
        adapter_hidden_dim=int(args.adapter_hidden_dim),
        rff_sigma=args.rff_sigma,
        value_n_step=int(args.value_n_step),
        freeze_vps_backbone=args.freeze_vps_backbone,
        prob_vps=args.prob_vps,
        prob_vps_log_eps=args.prob_vps_log_eps,
        prob_vps_min_logvar=args.prob_vps_min_logvar,
        prob_vps_max_logvar=args.prob_vps_max_logvar,
        xy_rff=args.xy_rff,
        reward_normalization=args.reward_normalization,
        reward_quantile_low=args.reward_quantile_low,
        reward_quantile_high=args.reward_quantile_high,
        smooth_vps=args.smooth_vps,
        smooth_vps_coef=args.smooth_vps_coef,
        value_snapshot_freq=args.heatmap_save_freq,
        vps_snapshot_freq=args.heatmap_save_freq,
        maze_map=maze_map,
        on_value_fit=save_value_stage_outputs,
        on_vps_fit=save_vps_stage_outputs,
        seed=args.seed,
        device=device,
        save_dir=save_dir,
    )
    artifact_path = save_vps_artifacts(save_dir=save_dir, env_id=args.env_id, transitions=transitions, outputs=outputs, maze_map=maze_map)
    if not value_heatmap_paths:
        save_value_stage_outputs(outputs.value_features, outputs.value_losses, int(args.value_epochs))
    if not vps_heatmap_paths:
        save_vps_stage_outputs(outputs.vps_features, outputs.vps_losses, int(args.vps_epochs))

    maybe_start_virtual_display(args)
    configure_mujoco_gl_for_gif(args)
    gif_enabled = bool(args.gif_freq > 0 and can_enable_gif_capture())
    vps_model, state_mean, state_std, num_heads, checkpoint_maze_map = load_vps_model(checkpoint_path, device=device)
    if maze_map is None:
        maze_map = checkpoint_maze_map

    total_options = int(num_heads) * divisor
    option_train_args = build_option_train_args(args, checkpoint_path=checkpoint_path, options_save_dir=options_save_dir, sign_enabled=sign_enabled)
    save_json(
        os.path.join(options_save_dir, "run_config.json"),
        {
            "args": vars(option_train_args),
            "method": "vps",
            "requested_env_id": args.requested_env_id,
            "resolved_env_id": args.env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": bool(args.using_custom_env),
            "num_heads": num_heads,
            "total_options": total_options,
            "adapter_hidden_dim": int(args.adapter_hidden_dim),
            "value_n_step": int(args.value_n_step),
            "prob_vps": bool(args.prob_vps),
            "device": str(device),
            "checkpoint_path": os.path.abspath(checkpoint_path),
        },
    )
    for option_id in range(total_options):
        option_spec = option_spec_from_id(option_id, num_heads=num_heads, sign_enabled=sign_enabled)
        train_one_option(
            args=option_train_args,
            env_id=args.env_id,
            maze_map=maze_map,
            save_dir=options_save_dir,
            option_spec=option_spec,
            vps_model=vps_model,
            state_mean=state_mean,
            state_std=state_std,
            device=device,
            gif_enabled=gif_enabled,
        )

    save_json(
        os.path.join(save_dir, "pipeline_summary.json"),
        {
            "method": "vps",
            "env_id": args.env_id,
            "requested_env_id": args.requested_env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": bool(args.using_custom_env),
            "seed": args.seed,
            "device": str(device),
            "buffer_size": int(args.buffer_size),
            "num_rewards": int(num_rewards),
            "total_options": int(total_options),
            "adapter_hidden_dim": int(args.adapter_hidden_dim),
            "value_n_step": int(args.value_n_step),
            "prob_vps": bool(args.prob_vps),
            "checkpoint_path": os.path.abspath(checkpoint_path),
            "artifact_path": os.path.abspath(artifact_path),
            "options_dir": os.path.abspath(options_save_dir),
            "value_heatmap_paths": [os.path.abspath(path) for path in value_heatmap_paths],
            "vps_heatmap_paths": [os.path.abspath(path) for path in vps_heatmap_paths],
            "heatmap_save_freq": int(args.heatmap_save_freq),
            "value_loss_final": float(outputs.value_losses[-1]) if outputs.value_losses.size else None,
            "vps_loss_final": float(outputs.vps_losses[-1]) if outputs.vps_losses.size else None,
        },
    )


def run_diayn_pretraining(args: argparse.Namespace, maze_map, device: torch.device, save_dir: str) -> None:
    """Run DIAYN pretraining and export one fixed-skill policy per option."""
    options_save_dir = ensure_dir(os.path.join(save_dir, "options"))
    occupancy_dir = ensure_dir(os.path.join(save_dir, "diayn_heatmaps"))
    rollout_dir = ensure_dir(os.path.join(save_dir, "diayn_rollouts"))
    total_timesteps = int(args.diayn_timesteps) if args.diayn_timesteps is not None else int(args.option_timesteps)

    print(f"[Pretrain:DIAYN] root={save_dir}")
    joint_model, discriminator, joint_model_path, discriminator_path = train_diayn_model(
        env_id=args.env_id,
        maze_map=maze_map,
        num_skills=int(args.num_options),
        max_episode_steps=int(args.max_episode_steps),
        seed=int(args.seed),
        device=device,
        total_timesteps=total_timesteps,
        learning_rate=float(args.option_learning_rate),
        buffer_size=int(args.option_buffer_size),
        learning_starts=int(args.option_learning_starts),
        batch_size=int(args.option_batch_size),
        gamma=float(args.option_gamma),
        tau=float(args.option_tau),
        gradient_steps=int(args.option_gradient_steps),
        policy_hidden_dims=tuple(int(v) for v in args.policy_hidden_dims),
        discriminator_hidden_dims=tuple(int(v) for v in args.disc_hidden_dims),
        discriminator_learning_rate=float(args.disc_learning_rate),
        discriminator_batch_size=int(args.disc_batch_size),
        discriminator_update_freq=int(args.disc_update_freq),
        discriminator_updates_per_step=int(args.disc_updates_per_step),
        reward_scale=float(args.reward_scale),
        save_dir=save_dir,
    )
    save_json(
        os.path.join(options_save_dir, "run_config.json"),
        {
            "args": vars(args),
            "method": "diayn",
            "requested_env_id": args.requested_env_id,
            "resolved_env_id": args.env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": bool(args.using_custom_env),
            "device": str(device),
            "num_options": int(args.num_options),
            "total_timesteps": total_timesteps,
            "joint_model_path": os.path.abspath(joint_model_path) + ".zip",
            "discriminator_path": os.path.abspath(discriminator_path),
        },
    )

    gif_enabled = prepare_gif_capture(args)
    exported_option_summaries: list[dict[str, object]] = []
    for option_id in range(int(args.num_options)):
        skill_spec = DIAYNSkillSpec(option_id=option_id, skill_idx=option_id)
        option_dir = ensure_dir(os.path.join(options_save_dir, f"option_{skill_spec.option_id:02d}_{skill_spec.name}"))
        gifs_dir = ensure_dir(os.path.join(option_dir, "gifs"))
        exported_model = export_skill_model(
            joint_model=joint_model,
            skill_spec=skill_spec,
            num_skills=int(args.num_options),
            env_id=args.env_id,
            maze_map=maze_map,
            max_episode_steps=int(args.max_episode_steps),
            seed=int(args.seed + option_id),
            device=device,
            policy_hidden_dims=tuple(int(v) for v in args.policy_hidden_dims),
        )
        policy_path = os.path.join(option_dir, "option_policy")
        exported_model.save(policy_path)
        gif_path = os.path.join(gifs_dir, f"{skill_spec.name}_final.gif") if gif_enabled else None
        eval_summary, trajectories = evaluate_exported_skill(
            model=exported_model,
            discriminator=discriminator,
            skill_spec=skill_spec,
            env_id=args.env_id,
            maze_map=maze_map,
            max_episode_steps=int(args.max_episode_steps),
            seed=int(args.seed + 10_000 + option_id),
            eval_episodes=int(args.eval_episodes),
            reward_scale=float(args.reward_scale),
            device=device,
            gif_enabled=gif_enabled,
            gif_path=gif_path,
            gif_max_steps=int(args.gif_max_steps),
            gif_fps=int(args.gif_fps),
            gif_stop_on_done=bool(args.gif_stop_on_done),
        )
        eval_metrics_path = save_skill_eval_metrics(os.path.join(option_dir, "eval_metrics.npz"), eval_summary)
        rollout_plot_path = plot_skill_trajectories(
            trajectories=trajectories,
            env_id=args.env_id,
            maze_map=maze_map,
            save_path=os.path.join(rollout_dir, f"{skill_spec.name}_rollouts.png"),
            title=f"DIAYN {skill_spec.name} Rollouts",
        )
        occupancy_plot_path = plot_skill_occupancy(
            trajectories=trajectories,
            env_id=args.env_id,
            maze_map=maze_map,
            projection_mode=args.projection_mode,
            bins=int(args.bins),
            save_path=os.path.join(occupancy_dir, f"{skill_spec.name}_occupancy.png"),
            title=f"DIAYN {skill_spec.name} Occupancy",
        )
        option_summary = {
            "method": "diayn",
            "env_id": args.env_id,
            "requested_env_id": args.requested_env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": bool(args.using_custom_env),
            "option_id": int(skill_spec.option_id),
            "skill_idx": int(skill_spec.skill_idx),
            "head_idx": int(skill_spec.head_idx),
            "sign": int(skill_spec.sign),
            "option_name": skill_spec.name,
            "reward_scale": float(args.reward_scale),
            "total_timesteps": total_timesteps,
            "joint_model_path": os.path.abspath(joint_model_path) + ".zip",
            "discriminator_path": os.path.abspath(discriminator_path),
            "policy_path": os.path.abspath(policy_path) + ".zip",
            "eval_metrics_path": os.path.abspath(eval_metrics_path),
            "rollout_plot_path": os.path.abspath(rollout_plot_path),
            "occupancy_plot_path": os.path.abspath(occupancy_plot_path),
            "gif_path": None if gif_path is None else os.path.abspath(gif_path),
            "mean_intrinsic_reward": float(eval_summary["mean_intrinsic_reward"]),
            "mean_log_q": float(eval_summary["mean_log_q"]),
            "mean_episode_length": float(eval_summary["mean_episode_length"]),
        }
        save_json(os.path.join(option_dir, "option_summary.json"), option_summary)
        exported_option_summaries.append(option_summary)

    save_diayn_run_summary(
        os.path.join(save_dir, "pipeline_summary.json"),
        {
            "method": "diayn",
            "env_id": args.env_id,
            "requested_env_id": args.requested_env_id,
            "maze_json": None if args.maze_json is None else os.path.abspath(args.maze_json),
            "has_custom_maze": bool(args.using_custom_env),
            "seed": int(args.seed),
            "device": str(device),
            "num_options": int(args.num_options),
            "reward_scale": float(args.reward_scale),
            "total_timesteps": total_timesteps,
            "joint_model_path": os.path.abspath(joint_model_path) + ".zip",
            "discriminator_path": os.path.abspath(discriminator_path),
            "training_metrics_path": os.path.abspath(os.path.join(save_dir, "diayn_training_metrics.npz")),
            "options_dir": os.path.abspath(options_save_dir),
            "diayn_heatmaps_dir": os.path.abspath(occupancy_dir),
            "diayn_rollouts_dir": os.path.abspath(rollout_dir),
            "exported_options": exported_option_summaries,
        },
    )


def main() -> None:
    """Dispatch to VPS or DIAYN pretraining."""
    args = build_arg_parser().parse_args()
    set_global_seed(args.seed)
    device = choose_device(args.device)
    args.requested_env_id = str(args.env_id)
    args.maze_json = resolve_maze_json_path(args.maze_json)
    args.env_id, args.maze_json, maze_map, args.using_custom_env = resolve_pointmaze_env_selection(args.env_id, args.maze_json)
    save_dir = resolve_save_dir(args)
    if args.method == "vps":
        run_vps_pretraining(args, maze_map=maze_map, device=device, save_dir=save_dir)
    else:
        run_diayn_pretraining(args, maze_map=maze_map, device=device, save_dir=save_dir)
    print(f"[Pretrain:{args.method.upper()}] Complete. Outputs written to {save_dir}")


if __name__ == "__main__":
    main()
