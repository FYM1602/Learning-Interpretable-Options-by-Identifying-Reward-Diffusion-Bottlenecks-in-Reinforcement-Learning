from __future__ import annotations

import numpy as np

try:
    from .utils import make_pointmaze_env
    from .vps_dataset import ReplayTransitions
except ImportError:  # pragma: no cover
    from utils import make_pointmaze_env
    from vps_dataset import ReplayTransitions


def collect_random_walk_transitions(
    env_id: str,
    seed: int,
    buffer_size: int,
    max_episode_steps: int,
    maze_map: list[list[int | str]] | None = None,
) -> ReplayTransitions:
    """Fill a transition buffer with uniformly random continuous actions."""
    env = make_pointmaze_env(
        env_id=env_id,
        seed=seed,
        max_episode_steps=max_episode_steps,
        extra_kwargs={"maze_map": maze_map} if maze_map is not None else None,
    )
    states: list[np.ndarray] = []
    next_states: list[np.ndarray] = []
    actions: list[np.ndarray] = []
    dones: list[float] = []
    achieved_goals: list[np.ndarray] = []
    desired_goals: list[np.ndarray] = []

    try:
        obs, _ = env.reset(seed=seed)
        episode_idx = 0
        while len(states) < int(buffer_size):
            action = env.action_space.sample()
            next_obs, _, terminated, truncated, _ = env.step(action)
            done = bool(terminated or truncated)

            states.append(np.asarray(obs["observation"], dtype=np.float32))
            next_states.append(np.asarray(next_obs["observation"], dtype=np.float32))
            actions.append(np.asarray(action, dtype=np.float32))
            dones.append(float(done))
            achieved_goals.append(np.asarray(obs["achieved_goal"], dtype=np.float32))
            desired_goals.append(np.asarray(obs["desired_goal"], dtype=np.float32))

            if len(states) % 10_000 == 0 or len(states) == int(buffer_size):
                print(f"[Collect] transitions={len(states)}/{buffer_size}")

            if done:
                episode_idx += 1
                obs, _ = env.reset(seed=seed + episode_idx)
            else:
                obs = next_obs
    finally:
        env.close()

    return ReplayTransitions(
        states=np.asarray(states, dtype=np.float32),
        next_states=np.asarray(next_states, dtype=np.float32),
        actions=np.asarray(actions, dtype=np.float32),
        dones=np.asarray(dones, dtype=np.float32).reshape(-1, 1),
        achieved_goals=np.asarray(achieved_goals, dtype=np.float32),
        desired_goals=np.asarray(desired_goals, dtype=np.float32),
    )
